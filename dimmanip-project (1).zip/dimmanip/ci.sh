#!/usr/bin/env bash
# Builds the mod on GitHub Actions. Called by the workflow after the project zip is unpacked.
set -euo pipefail
cd "$(dirname "$0")"
SUM=a4b4158601f8636cdeeab09bd76afb640030bb5b144aafe261a5e8af027dc612
URLS="https://services.gradle.org/distributions/gradle-8.8-bin.zip
https://downloads.gradle.org/distributions/gradle-8.8-bin.zip
https://mirrors.cloud.tencent.com/gradle/gradle-8.8-bin.zip
https://mirrors.huaweicloud.com/gradle/gradle-8.8-bin.zip"
got=""
for round in 1 2 3; do
  for u in $URLS; do
    echo "Trying $u"
    if curl -fsSL --connect-timeout 20 --max-time 300 -o /tmp/gradle.zip "$u" \
       && echo "$SUM  /tmp/gradle.zip" | sha256sum -c -; then
      got="$u"; break 2
    fi
  done
  echo "All sources failed (round $round of 3), waiting 60 seconds"
  sleep 60
done
[ -n "$got" ] || { echo "Could not download Gradle"; exit 1; }
echo "Got Gradle from $got"
unzip -q -o /tmp/gradle.zip -d "$HOME"
"$HOME/gradle-8.8/bin/gradle" build --no-daemon --console=plain --stacktrace
unzip -l build/libs/*.jar | grep "META-INF/mods.toml"
mkdir -p "$GITHUB_WORKSPACE/out"
cp build/libs/*.jar "$GITHUB_WORKSPACE/out/"
ls -l "$GITHUB_WORKSPACE/out"
