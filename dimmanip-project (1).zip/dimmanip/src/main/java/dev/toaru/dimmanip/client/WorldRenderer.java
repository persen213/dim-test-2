package dev.toaru.dimmanip.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.toaru.dimmanip.DimManip;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * One render hook for everything the add-on draws in the world : its own
 * buffers for translucent, glowing and through-walls geometry, then the text
 * labels facing the camera.
 */
@Mod.EventBusSubscriber(modid = DimManip.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class WorldRenderer {
    private WorldRenderer() { }

    private static MultiBufferSource.BufferSource buffers;

    private static MultiBufferSource.BufferSource buffers() {
        if (buffers == null) {
            Map<RenderType, BufferBuilder> fixed = new HashMap<>();
            fixed.put(EvRenderTypes.SOLID, new BufferBuilder(1 << 20));
            fixed.put(EvRenderTypes.CRYSTAL, new BufferBuilder(1 << 20));
            fixed.put(EvRenderTypes.GLOW, new BufferBuilder(1 << 20));
            fixed.put(EvRenderTypes.XRAY, new BufferBuilder(1 << 16));
            buffers = MultiBufferSource.immediateWithBuffers(fixed, new BufferBuilder(256));
        }
        return buffers;
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        if (ClientFx.ACTIVE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        float partial = mc.isPaused() ? 0f : event.getPartialTick();
        long now = mc.level.getGameTime();
        double time = now + partial;
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        PoseStack stack = event.getPoseStack();
        Matrix4f pose = stack.last().pose();
        MultiBufferSource.BufferSource src = buffers();

        try {
            TerrainFx.draw(stack, cam, now, partial);
        } catch (RuntimeException ex) {
            // A drawing problem must never crash the game.
        }
        Fxu.LABELS.clear();
        int q = dev.toaru.dimmanip.ClientCfg.quality();
        Geo.detail = q >= 2 ? 1.0 : q == 1 ? 0.65 : 0.4;
        Geo crystal = new Geo(src.getBuffer(EvRenderTypes.CRYSTAL), pose, cam);
        Geo glow = new Geo(src.getBuffer(EvRenderTypes.GLOW), pose, cam);
        Geo xray = new Geo(src.getBuffer(EvRenderTypes.XRAY), pose, cam);
        Geo solid = new Geo(src.getBuffer(EvRenderTypes.SOLID), pose, cam);
        SkinArm.buffers = t -> src.getBuffer(EvRenderTypes.skin(t));
        SkinArm.pose = pose;
        SkinArm.camera = cam;
        Limb.skin = SkinArm::draw;
        try {
            FxRenderer.draw(crystal, glow, solid, xray, cam, now, partial, time);
        } finally {
            Limb.skin = null;
            SkinArm.buffers = null;
            SkinArm.pose = null;
            SkinArm.camera = null;
        }
        // Arms in players' skins (not one of the fixed buffers: drawn as soon as its turn ends).
        src.endLastBatch();
        src.endBatch(EvRenderTypes.SOLID);
        src.endBatch(EvRenderTypes.CRYSTAL);
        src.endBatch(EvRenderTypes.GLOW);
        src.endBatch(EvRenderTypes.XRAY);

        if (Fxu.LABELS.isEmpty()) return;
        Font font = mc.font;
        MultiBufferSource.BufferSource text = mc.renderBuffers().bufferSource();
        for (Fxu.Label l : Fxu.LABELS) {
            stack.pushPose();
            stack.translate(l.pos().x - cam.x, l.pos().y - cam.y, l.pos().z - cam.z);
            stack.mulPose(camera.rotation());
            float s = 0.025f * l.scale();
            stack.scale(-s, -s, s);
            float w = font.width(l.text());
            font.drawInBatch(l.text(), -w / 2f, 0f, l.argb(), false, stack.last().pose(), text, Font.DisplayMode.SEE_THROUGH, 0x50000000, 0xF000F0);
            stack.popPose();
        }
        text.endBatch();
        Fxu.LABELS.clear();
    }
}
