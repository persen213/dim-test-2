package dev.toaru.dimmanip.client;

import static dev.toaru.dimmanip.client.Fxu.*;

import net.minecraft.world.phys.Vec3;

/**
 * The big effect pieces the dragons' powers are made of: breath that billows out of a real mouth, beams with a core,
 * a spiral and lightning crawling round them, blasts with a fireball, a shock dome, rings, flying debris and a smoke
 * column, a storm cloud, a dome of darkness, ice spikes bursting from the ground. All of it plain geometry (no particles):
 * glows on the additive buffer, smoke, ice and rock on the see-through one.
 */
final class Vfx {
    private Vfx() { }

    static final Vec3 UP = new Vec3(0, 1, 0);
    /** Downward pull on flying debris, blocks per tick squared. */
    private static final double G = 0.05;

    private static Vec3 side(Vec3 d) {
        Vec3 s = d.cross(UP);
        return s.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : s.normalize();
    }

    /**
     * A soft band from {@code a} to {@code b} that always turns its face to the camera: full colour along its middle,
     * fading to nothing at both edges, so it reads as a round glowing shaft from every side (not a flat plank).
     */
    static void band(Geo g, Vec3 a, Vec3 b, double w, int rgb, float alpha) {
        if (alpha < 0.005f || w <= 0) return;
        Vec3 d = b.subtract(a);
        if (d.lengthSqr() < 1e-8) return;
        Vec3 mid = a.add(d.scale(0.5));
        Vec3 view = g.cam().subtract(mid);
        Vec3 sv = d.cross(view);
        if (sv.lengthSqr() < 1e-8) sv = Geo.basis(d)[0];
        sv = sv.normalize().scale(w);
        int c = argb(alpha, rgb), z = argb(0f, rgb);
        g.gquad(a.subtract(sv), z, a, c, b, c, b.subtract(sv), z);
        g.gquad(a, c, a.add(sv), z, b.add(sv), z, b, c);
    }

    // ------------------------------------------------------------------ gathering power
    /** Power drawn into a point: streaks rushing inward and a swelling core ({@code k} 0..1 how far along). */
    static void gather(Geo glow, Vec3 o, double R, int rgb, double k, double time, long seed) {
        if (k <= 0) return;
        for (int i = 0; i < 22; i++) {
            long h = seed * 17 + i;
            Vec3 d = new Vec3(hash(h) - 0.5, hash(h + 1) - 0.5, hash(h + 2) - 0.5);
            if (d.lengthSqr() < 1e-4) continue;
            d = d.normalize();
            double far = R * (1 - ((k * 1.6 + hash(h + 3)) % 1.0));
            col(glow, rgb, 0.65f * (float) k).ribbon(o.add(d.scale(far + R * 0.35)), o.add(d.scale(far)), 0.03 + R * 0.012);
        }
        double pulse = 1 + 0.15 * Math.sin(time * 1.7 + seed);
        glow.softFacing(o, R * 0.25 * k * pulse, 16, argb(0.95f * (float) k, 0xFFFFFF), argb(0f, rgb));
        glow.softFacing(o, R * 0.7 * k * pulse, 16, argb(0.45f * (float) k, rgb), argb(0f, rgb));
        col(glow, rgb, 0.5f * (float) k).ring(o, new Vec3(Math.sin(time * 0.1), 1, Math.cos(time * 0.13)).normalize(), R * (0.6 - 0.3 * k), 0.03, 32, time * 0.2, true);
    }

    // ------------------------------------------------------------------ breath
    /**
     * Breath pouring out of a mouth at {@code o} along {@code d}: a white-hot jet at the lips, billows swelling as they
     * travel, tongues licking out, shock rings riding down the cone. {@code frost}: frost cloud and spinning ice shards
     * instead of fire, and ice spikes bursting out of the ground under it. Colours: hot core, body, edge, smoke.
     */
    static void breath(Geo glow, Geo crystal, Vec3 o, Vec3 d, double range, double half, int core, int body, int edge, int smoke,
                       boolean frost, float k, double age, double time, long seed) {
        if (k < 0.01f) return;
        d = d.normalize();
        Vec3[] uv = Geo.basis(d);
        double spread = Math.tan(half);
        // The mouth burns.
        double flick = 1 + 0.2 * Math.sin(time * 2.3 + seed) + 0.1 * Math.sin(time * 5.1);
        glow.softFacing(o, 0.9 * flick, 18, argb((frost ? 0.6f : 0.95f) * k, 0xFFFFFF), argb(0f, core));
        glow.softFacing(o, 2.2 * flick, 18, argb((frost ? 0.25f : 0.45f) * k, body), argb(0f, body));
        // The jet: tapered layers.
        int seg = 8;
        double jet = range * 0.45;
        for (int i = 0; i < seg; i++) {
            double t0 = i / (double) seg, t1 = (i + 1) / (double) seg;
            Vec3 a = o.add(d.scale(jet * t0)), b = o.add(d.scale(jet * t1));
            double w = 0.12 + spread * jet * t1 * 0.35;
            band(glow, a, b, w * 0.5, core, 0.9f * k * (float) (1 - t0 * 0.7));
            band(glow, a, b, w * 1.3, body, 0.55f * k * (float) (1 - t0 * 0.5));
        }
        // Billows.
        for (int i = 0; i < 46; i++) {
            long h = seed * 31 + i;
            double t = (hash(h) + age * 0.075) % 1.0;
            double a = hash(h + 1) * Math.PI * 2, off = spread * Math.sqrt(hash(h + 2)) * t * range;
            Vec3 c = o.add(d.scale(0.4 + range * t)).add(uv[0].scale(Math.cos(a) * off)).add(uv[1].scale(Math.sin(a) * off));
            c = c.add(0, frost ? -0.6 * t * t : 0.5 * t * t, 0);
            double r = 0.35 + t * (spread * range * 0.55 + 0.6);
            float fa = k * (float) ((1 - t) * Math.min(1, t * 6));
            int colr = t < 0.25 ? mix(core, body, t / 0.25) : mix(body, edge, (t - 0.25) / 0.75);
            glow.softFacing(c, r, 14, argb((frost ? 0.16f : 0.42f) * fa, colr), argb(0f, edge));
            if (t > 0.45) crystal.softFacing(c.add(0, 0.3 * t, 0), r * 1.2, 12, argb((frost ? 0.22f : 0.3f) * fa, smoke), argb(0f, smoke));
        }
        if (!frost) {
            // Tongues of flame licking out along the cone.
            for (int i = 0; i < 20; i++) {
                long h = seed * 7 + i;
                double t = (hash(h) + age * 0.11) % 1.0;
                double a = hash(h + 1) * Math.PI * 2, off = spread * hash(h + 2) * t * range * 0.8;
                Vec3 b = o.add(d.scale(0.3 + range * 0.75 * t)).add(uv[0].scale(Math.cos(a) * off)).add(uv[1].scale(Math.sin(a) * off));
                Vec3 tip = b.add(d.scale(0.8 + 1.6 * t)).add(0, 0.4 * Math.sin(time * 0.7 + i), 0).add(uv[0].scale(0.3 * Math.sin(time * 0.9 + i * 2)));
                float fa = k * (float) (1 - t);
                col(glow, t < 0.3 ? core : body, 0.7f * fa).kite(b, tip, uv[1], 0.18 + 0.4 * t);
                col(glow, body, 0.5f * fa).kite(b, tip, uv[0], 0.18 + 0.4 * t);
            }
        } else {
            // Ice shards whirling down the cone.
            for (int i = 0; i < 26; i++) {
                long h = seed * 11 + i;
                double t = (hash(h) + age * 0.09) % 1.0;
                double a = hash(h + 1) * Math.PI * 2 + time * 0.05, off = spread * Math.sqrt(hash(h + 2)) * t * range;
                Vec3 c = o.add(d.scale(0.5 + range * t)).add(uv[0].scale(Math.cos(a) * off)).add(uv[1].scale(Math.sin(a) * off));
                Vec3 ax = d.add(uv[0].scale(Math.sin(time * 0.3 + i))).normalize();
                col(crystal, 0xE8F8FF, 0.85f * k * (float) (1 - t * 0.6)).crystal(c, ax, 0.07 + 0.12 * t, 0.25 + 0.45 * t, i + time * 0.2);
            }
        }
        // Shock rings riding down the cone.
        for (int i = 0; i < 3; i++) {
            double t = (age * 0.06 + i / 3.0) % 1.0;
            Vec3 c = o.add(d.scale(range * t));
            col(glow, i % 2 == 0 ? core : body, 0.5f * k * (float) (1 - t)).ring(c, d, 0.4 + spread * range * t, 0.05 + 0.08 * (1 - t), 40, time * 0.1, i == 1);
        }
    }

    /** Ice spikes bursting from the ground along a fan, growing in a wave outwards and staying a while. */
    static void iceField(Geo crystal, Geo glow, Vec3 o, Vec3 d, double range, double half, double age, double dur, long seed) {
        Vec3 flat = new Vec3(d.x, 0, d.z);
        if (flat.lengthSqr() < 1e-4) return;
        flat = flat.normalize();
        Vec3 s = side(flat);
        float fade = (float) smooth((dur - age) / 8.0);
        for (int i = 0; i < 34; i++) {
            long h = seed * 23 + i;
            double t = 0.15 + 0.85 * Math.sqrt(hash(h));
            double sidew = (hash(h + 1) * 2 - 1) * Math.tan(half) * t * range;
            Vec3 p = o.add(flat.scale(t * range)).add(s.scale(sidew));
            double gy = ground(p, 8);
            double born = t * 10;
            double g = easeOutBack(Math.max(0, Math.min(1, (age - born) / 4.0)));
            if (g <= 0) continue;
            double len = (0.8 + 1.8 * hash(h + 2)) * (0.6 + 0.6 * t) * g;
            Vec3 ax = flat.scale(0.5 + 0.4 * hash(h + 3)).add(s.scale((hash(h + 4) - 0.5) * 0.8)).add(0, 1.4, 0).normalize();
            Vec3 base = new Vec3(p.x, gy, p.z);
            col(crystal, mix(0xBFE8FF, 0xF4FCFF, hash(h + 5)), 0.82f * fade).crystal(base.add(ax.scale(len * 0.5)), ax, 0.12 + 0.18 * hash(h + 6) * g, len * 0.6, i);
            if (age - born < 6) glow.softFacing(base.add(0, 0.3, 0), 0.9, 10, argb(0.4f * fade * (float) (1 - (age - born) / 6), 0xDFF6FF), argb(0f, 0xBFE8FF));
        }
        crystal.softDisc(o.add(flat.scale(range * 0.55)).add(0, 0.04 - (o.y - ground(o.add(flat.scale(range * 0.55)), 8)), 0), UP, range * 0.6, 32, argb(0.35f * fade, 0xE8F6FF), argb(0f, 0xE8F6FF));
    }

    // ------------------------------------------------------------------ beams
    /**
     * A beam from {@code a} to {@code b}: a blinding core inside layers of colour, a double spiral turning round it,
     * lightning crawling over it, a muzzle flash at the mouth and a burning point where it lands.
     */
    static void beam(Geo glow, Geo crystal, Vec3 a, Vec3 b, double w, int c0, int c1, float k, double age, double time, long seed, boolean holy) {
        if (k < 0.01f) return;
        Vec3 d = b.subtract(a);
        double L = d.length();
        if (L < 0.2) return;
        Vec3 u = d.scale(1 / L);
        Vec3[] uv = Geo.basis(u);
        double wob = 1 + 0.12 * Math.sin(time * 1.9 + seed);
        // Layers.
        band(glow, a, b, w * 2.6 * wob, c1, 0.35f * k);
        band(glow, a, b, w * 1.3 * wob, c0, 0.75f * k);
        band(glow, a, b, w * 0.45, 0xFFFFFF, k);
        // Bloom along it.
        int n = Math.max(3, Math.min(14, (int) (L / 3)));
        for (int i = 0; i <= n; i++) glow.softFacing(a.add(d.scale(i / (double) n)), w * 3.0, 12, argb(0.12f * k, c0), argb(0f, c1));
        // The spiral.
        int sp = Math.max(16, Math.min(90, (int) (L * 3)));
        for (int strand = 0; strand < 2; strand++) {
            Vec3 prev = null;
            for (int i = 0; i <= sp; i++) {
                double t = i / (double) sp;
                double ang = t * L * 1.3 - time * 0.6 + strand * Math.PI;
                double rad = w * (1.5 + 0.3 * Math.sin(t * 20 + time));
                Vec3 p = a.add(d.scale(t)).add(uv[0].scale(Math.cos(ang) * rad)).add(uv[1].scale(Math.sin(ang) * rad));
                if (prev != null) col(glow, strand == 0 ? c0 : 0xFFFFFF, 0.6f * k).ribbon(prev, p, 0.04 + w * 0.05);
                prev = p;
            }
        }
        if (!holy) {
            // Lightning crawling over it, jumping every couple of ticks.
            long tick = (long) Math.floor(time / 2);
            for (int i = 0; i < 4; i++) {
                long h = seed * 13 + tick * 7 + i;
                double t0 = hash(h), t1 = Math.min(1, t0 + 0.1 + 0.2 * hash(h + 1));
                double ang = hash(h + 2) * Math.PI * 2, out = w * (2 + 3 * hash(h + 3));
                Vec3 p0 = a.add(d.scale(t0)), p1 = a.add(d.scale(t1)).add(uv[0].scale(Math.cos(ang) * out)).add(uv[1].scale(Math.sin(ang) * out));
                FxRenderer.bolt(glow, p0, p1, h, k, c0);
            }
        } else {
            // A broad column of soft light round it, and halos riding down.
            band(glow, a, b, w * 6, 0xFFF8E0, 0.22f * k);
            for (int i = 0; i < 4; i++) {
                double t = (age * 0.05 + i / 4.0) % 1.0;
                col(glow, 0xFFE9A8, 0.55f * k * (float) (1 - t * 0.5)).ring(a.add(d.scale(t)), u, w * (2.5 + 1.5 * Math.sin(t * Math.PI)), 0.06, 40, time * 0.05, false);
            }
        }
        // Muzzle flash: rings bursting from the mouth.
        for (int i = 0; i < 2; i++) {
            double t = (age * 0.12 + i * 0.5) % 1.0;
            col(glow, c0, 0.7f * k * (float) (1 - t)).ring(a.add(u.scale(0.3 + t * 1.5)), u, w * (1 + 4 * t), 0.06, 32, 0, false);
        }
        glow.softFacing(a, w * 3.5, 18, argb(0.85f * k, 0xFFFFFF), argb(0f, c0));
        // Where it lands.
        double fl = 1 + 0.3 * Math.sin(time * 3.1);
        glow.softFacing(b, w * 4 * fl, 18, argb(0.9f * k, 0xFFFFFF), argb(0f, c0));
        glow.softFacing(b, w * 9 * fl, 18, argb(0.3f * k, c1), argb(0f, c1));
    }

    // ------------------------------------------------------------------ blasts
    /**
     * A blast of size {@code R} at {@code o}: blinding flash, a fireball in layers, a shock dome, rings and a dust wave
     * racing over the ground, debris flung out and falling back, a pillar of light and a column of smoke, a scorch.
     */
    static void blast(Geo glow, Geo crystal, Vec3 o, double R, int c0, int c1, int c2, double age, double dur, long seed, double time) {
        float after = 1 - (float) smooth((age - dur * 0.6) / Math.max(1, dur * 0.4));
        Vec3 mid = o.add(0, R * 0.35, 0);
        if (age < 5) {
            float f = 1 - (float) age / 5f;
            glow.softFacing(mid, R * (1.2 + age * 0.5), 24, argb(0.85f * f, 0xFFFFFF), argb(0f, c0));
            glow.softFacing(mid, R * (3 + age), 24, argb(0.5f * f, c1), argb(0f, c1));
        }
        // Fireball.
        if (age < 18) {
            double k = age / 18.0;
            for (int i = 0; i < 3; i++) {
                double r = R * (0.5 + 0.35 * i) * easeOut(Math.min(1, age / (5.0 + i * 2)));
                float a = (float) ((1 - k) * (0.3 - 0.07 * i));
                // Soft round layers (a glow facing the camera) instead of hard balls.
                glow.softFacing(mid.add(0, R * 0.25 * k * i, 0), r * 1.3, 24, argb(a, i == 0 ? 0xFFFFFF : i == 1 ? c0 : c1), argb(0f, c1));
            }
        }
        // Shock dome.
        if (age < 12) {
            double k = age / 12.0;
            col(glow, c0, 0.08f * (float) (1 - k)).sphere(o, R * 2.2 * easeOut(k), 10, 20);
            col(glow, c0, 0.35f * (float) (1 - k)).ring(o.add(0, 0.2, 0), UP, R * 2.2 * easeOut(k), 0.05 + 0.04 * R * (1 - k), 64, 0, false);
        }
        // Rings and dust wave over the ground.
        for (int w = 0; w < 3; w++) {
            double k = (age - w * 3) / 16.0;
            if (k <= 0 || k >= 1) continue;
            float fk = (float) (1 - k);
            double rr = R * (0.5 + 3.4 * easeOut(k));
            col(glow, w == 0 ? 0xFFFFFF : c0, 0.55f * fk).ring(o.add(0, 0.1 + w * 0.25, 0), UP, rr, 0.06 + R * 0.025 * fk, 64, 0, false);
            for (int j = 0; j < 18; j++) {
                double ang = j * Math.PI * 2 / 18 + w;
                Vec3 p = o.add(Math.cos(ang) * rr, 0.3 + 0.4 * fk, Math.sin(ang) * rr);
                crystal.softFacing(p, 0.5 + R * 0.3 * k, 8, argb(0.3f * fk, 0x6E6258), argb(0f, 0x6E6258));
            }
        }
        // Pillar of light.
        if (age < 16) {
            double k = age / 16.0, h = 10 + R * 5;
            band(glow, o, o.add(0, h * easeOut(k * 3), 0), R * 0.9 * (1 - k), c1, 0.5f * (float) (1 - k));
            band(glow, o, o.add(0, h * easeOut(k * 3), 0), R * 0.3 * (1 - k), 0xFFFFFF, 0.9f * (float) (1 - k));
        }
        // Debris: chunks flung out, spinning, falling back and lying where they land.
        for (int i = 0; i < 26; i++) {
            long h = seed * 19 + i;
            double ang = hash(h) * Math.PI * 2, el = 0.3 + 0.9 * hash(h + 1), sp = R * (0.18 + 0.25 * hash(h + 2));
            Vec3 v = new Vec3(Math.cos(ang) * Math.cos(el), Math.sin(el), Math.sin(ang) * Math.cos(el)).scale(sp);
            double t = Math.max(0, age - 1);
            Vec3 p = o.add(v.scale(t)).add(0, -0.5 * G * t * t + 0.3, 0);
            double gy = ground(new Vec3(p.x, o.y + 2, p.z), 8);
            boolean landed = p.y < gy;
            if (landed) p = new Vec3(p.x, gy + 0.1, p.z);
            double sz = 0.12 + 0.28 * hash(h + 3) * Math.max(1, R * 0.5);
            Vec3 ax = landed ? new Vec3(Math.cos(ang), 0.3, Math.sin(ang)).normalize() : new Vec3(Math.sin(t * 0.4 + i), Math.cos(t * 0.3), Math.sin(t * 0.5 + i * 2)).normalize();
            float a = after;
            col(crystal, mix(0x2E2925, 0x5A4E44, hash(h + 4)), 0.95f * a).crystal(p, ax, sz, sz * 1.3, i);
            if (!landed && t < 14) glow.softFacing(p, sz * 2.2, 8, argb(0.45f * (float) (1 - t / 14), c0), argb(0f, c0));
        }
        // Smoke column.
        for (int i = 0; i < 12; i++) {
            long h = seed * 29 + i;
            double t = age - 4 - i * 1.5;
            if (t <= 0) continue;
            double rise = t * 0.12 * (1 + R * 0.15);
            double r = R * (0.4 + 0.05 * t) + 0.5;
            float a = (float) (Math.min(1, t / 6) * (1 - smooth((age - dur * 0.5) / (dur * 0.5)))) * 0.35f;
            Vec3 p = o.add((hash(h) - 0.5) * R, rise + R * 0.3, (hash(h + 1) - 0.5) * R);
            crystal.softFacing(p, r, 14, argb(a, 0x2A2624), argb(0f, 0x2A2624));
        }
        // Scorch.
        double g = easeOut(age / 6.0);
        crystal.softDisc(o.add(0, 0.04, 0), UP, R * 1.6 * g, 32, argb(0.6f * after, 0x120E0C), argb(0f, 0x120E0C));
        glow.softDisc(o.add(0, 0.06, 0), UP, R * 1.1 * g, 32, argb(0.3f * after * (float) (1 - smooth(age / dur)), c0), argb(0f, c0));
    }

    // ------------------------------------------------------------------ storm, darkness
    /** A churning storm cloud with flickers of lightning inside, sheets of rain, splashes and a sick mist on the ground. */
    static void storm(Geo glow, Geo crystal, Vec3 o, double R, double top, int cloud, int rain, int mist, float k, double age, double time, long seed) {
        if (k < 0.01f) return;
        Vec3 c = o.add(0, top, 0);
        for (int i = 0; i < 26; i++) {
            long h = seed * 3 + i;
            double a = hash(h) * Math.PI * 2 + time * 0.01 * (1 + hash(h + 1)), d = Math.sqrt(hash(h + 2)) * R * 1.1;
            Vec3 p = c.add(Math.cos(a) * d, (hash(h + 3) - 0.5) * 1.6, Math.sin(a) * d);
            crystal.softFacing(p, R * (0.35 + 0.25 * hash(h + 4)), 14, argb(0.55f * k, mix(cloud, 0x000000, hash(h + 5) * 0.5)), argb(0f, cloud));
        }
        // Lightning in the cloud.
        long tick = (long) Math.floor(time / 3);
        if (hash(tick * 7 + seed) < 0.45) {
            double a = hash(tick + seed) * Math.PI * 2, d = hash(tick * 3 + seed) * R * 0.8;
            Vec3 p = c.add(Math.cos(a) * d, -0.3, Math.sin(a) * d);
            glow.softFacing(p, R * 0.7, 16, argb(0.5f * k, 0xE0FFE0), argb(0f, rain));
            if (hash(tick * 11 + seed) < 0.4) FxRenderer.bolt(glow, p, new Vec3(p.x + (hash(tick) - 0.5) * 3, ground(p, 30), p.z + (hash(tick + 9) - 0.5) * 3), tick, k, 0xC8FFB0);
        }
        for (int i = 0; i < 140; i++) {
            long h = seed * 13 + i;
            double a = hash(h) * Math.PI * 2, d = Math.sqrt(hash(h + 1)) * R;
            double y = top - ((hash(h + 2) * top + age * 1.9) % top);
            Vec3 p = o.add(Math.cos(a) * d, y, Math.sin(a) * d);
            col(glow, rain, 0.5f * k).ribbon(p, p.add(0.15, 0.9, 0.05), 0.025);
        }
        for (int i = 0; i < 14; i++) {
            long h = seed * 41 + i;
            double t = (hash(h) + age * 0.08) % 1.0;
            double a = hash(h + 1) * Math.PI * 2, d = Math.sqrt(hash(h + 2)) * R;
            Vec3 p = new Vec3(o.x + Math.cos(a) * d, 0, o.z + Math.sin(a) * d);
            p = new Vec3(p.x, ground(new Vec3(p.x, o.y + 1, p.z), 6) + 0.06, p.z);
            col(glow, rain, 0.5f * k * (float) (1 - t)).ring(p, UP, 0.1 + 0.6 * t, 0.03, 16, 0, false);
        }
        crystal.softDisc(o.add(0, 0.25, 0), UP, R * 1.1, 36, argb(0.3f * k, mist), argb(0f, mist));
        glow.softDisc(o.add(0, 0.1, 0), UP, R, 36, argb(0.15f * k, rain), argb(0f, rain));
    }

    /**
     * Dread: a dome of darkness swelling over the ground, shadow tendrils curling inward along it, cracks of violet light
     * running out across the ground, and slow pulses of fear.
     */
    static void darkness(Geo glow, Geo crystal, Vec3 o, double R, float k, double age, double time, long seed) {
        if (k < 0.01f) return;
        double g = easeOut(Math.min(1, age / 14.0));
        col(crystal, 0x050208, 0.22f * k).sphere(o, R * 1.15 * g, 12, 24);
        crystal.softDisc(o.add(0, 0.05, 0), UP, R * 1.3 * g, 40, argb(0.75f * k, 0x000000), argb(0f, 0x000000));
        for (int i = 0; i < 12; i++) {
            long h = seed * 5 + i;
            double a0 = hash(h) * Math.PI * 2 + time * 0.015;
            Vec3 prev = null;
            for (int j = 0; j <= 16; j++) {
                double t = j / 16.0;
                double rr = R * 1.15 * g * (1 - t * 0.85);
                double el = t * 1.2;
                double a = a0 + t * 1.8 + Math.sin(time * 0.05 + i) * 0.3;
                Vec3 p = o.add(Math.cos(a) * rr * Math.cos(el), rr * Math.sin(el) * 0.9, Math.sin(a) * rr * Math.cos(el));
                if (prev != null) col(crystal, 0x000000, 0.75f * k * (float) (1 - t * 0.5)).ribbon(prev, p, 0.12 * (1 - t) + 0.02);
                prev = p;
            }
        }
        for (int i = 0; i < 10; i++) {
            long h = seed * 9 + i;
            double a = hash(h) * Math.PI * 2;
            Vec3 prev = o.add(0, 0.08, 0);
            double reach = R * 1.2 * g * (0.6 + 0.4 * hash(h + 1));
            for (int j = 1; j <= 6; j++) {
                double t = j / 6.0;
                Vec3 p = o.add(Math.cos(a + (hash(h + j) - 0.5) * 0.4) * reach * t, 0.08, Math.sin(a + (hash(h + j) - 0.5) * 0.4) * reach * t);
                col(glow, 0x8C3CFF, 0.6f * k * (float) (1 - t * 0.6)).ribbon(prev, p, 0.06);
                prev = p;
            }
        }
        for (int w = 0; w < 3; w++) {
            double t = (age * 0.03 + w / 3.0) % 1.0;
            col(glow, 0x6A1EC8, 0.4f * k * (float) (1 - t)).ring(o.add(0, 0.15, 0), UP, R * 1.3 * t, 0.1, 64, 0, false);
        }
    }

    /** A feather, quill and vane, tumbling. */
    static void feather(Geo crystal, Geo glow, Vec3 p, Vec3 dir, Vec3 side, double len, int rgb, float a) {
        Vec3 tip = p.add(dir.scale(len));
        col(crystal, rgb, 0.92f * a).kite(p, tip, side, len * 0.22);
        col(crystal, mix(rgb, 0xC8B890, 0.5), 0.95f * a).ribbon(p.subtract(dir.scale(len * 0.15)), tip, len * 0.015);
        glow.softFacing(p.add(dir.scale(len * 0.4)), len * 0.6, 8, argb(0.18f * a, 0xFFF2C8), argb(0f, 0xFFF2C8));
    }

    /** A tomb of faceted ice round a body: a clear block, spikes out of it, frost light; it cracks as it ends. */
    static void iceTomb(Geo crystal, Geo glow, Vec3 c, double w, double h, float k, double age, double dur, long seed) {
        double g = easeOutBack(Math.min(1, age / 4.0));
        double crack = smooth((age - (dur - 8)) / 8.0);
        col(crystal, 0xCFEFFF, 0.42f * k).cuboid(c, w * 0.75 * g, h * 0.62 * g, w * 0.75 * g, seed * 0.7);
        for (int i = 0; i < 14; i++) {
            long hh = seed * 3 + i;
            double a = hash(hh) * Math.PI * 2;
            Vec3 ax = new Vec3(Math.cos(a), 0.4 + hash(hh + 1), Math.sin(a)).normalize();
            Vec3 p = c.add(Math.cos(a) * w * 0.5, (hash(hh + 2) - 0.5) * h * 1.1, Math.sin(a) * w * 0.5).add(ax.scale(crack * 0.6));
            col(crystal, mix(0xBFE8FF, 0xFFFFFF, hash(hh + 3)), 0.85f * k).crystal(p.add(ax.scale(w * 0.3 * g)), ax, w * 0.18 * g, h * 0.45 * g * (0.6 + 0.6 * hash(hh + 4)), i);
        }
        glow.softFacing(c, Math.max(w, h) * 1.6, 14, argb(0.25f * k, 0xBFE8FF), argb(0f, 0xBFE8FF));
    }
}
