package dev.toaru.dimmanip;

import io.github.pinchan4273.reacademycraft.api.mc.AbilityActor;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/**
 * Effects that outlive the instant activation (projectiles in flight, fields, toggles, the puppet's control). Ticked
 * once per server tick; each ends by itself, and all of a player's effects are removed when they log out, die or change
 * dimension, and everything when the server stops. Effects may be added or ended at any time, also from inside another
 * effect's tick (ending only marks them; the lists are tidied after the tick).
 */
public final class Timed {
    private Timed() { }

    public abstract static class Effect {
        public final ServerPlayer owner;
        public final AbilityActor actor;
        public final ServerLevel level;
        public final long started;
        public long end;
        boolean dead;

        protected Effect(ServerPlayer owner, AbilityActor actor, int ticks) {
            this.owner = owner; this.actor = actor; this.level = owner.serverLevel();
            this.started = level.getGameTime(); this.end = started + ticks;
        }

        public long age() { return level.getGameTime() - started; }
        public boolean over() { return level.getGameTime() >= end; }
        public boolean ended() { return dead; }
        /** Called every server tick; return false to end it (end() is then called). */
        protected abstract boolean tick();
        /** Called once when it ends for any reason (natural end, owner gone, server stopping). */
        protected void end(boolean natural) { }
        /** False for effects that go on while their owner is elsewhere (Pocket Universe takes him to another dimension). */
        protected boolean ownerBound() { return true; }
    }

    private static final List<Effect> ALL = new ArrayList<>();
    private static final List<Effect> ADDED = new ArrayList<>();

    public static <T extends Effect> T add(T e) { ADDED.add(e); return e; }

    public static boolean any() { return !ALL.isEmpty() || !ADDED.isEmpty(); }

    @SuppressWarnings("unchecked")
    public static <T extends Effect> List<T> of(Class<T> type) {
        List<T> out = new ArrayList<>();
        for (Effect e : ALL) if (!e.dead && type.isInstance(e)) out.add((T) e);
        for (Effect e : ADDED) if (!e.dead && type.isInstance(e)) out.add((T) e);
        return out;
    }

    public static <T extends Effect> T ownedBy(Class<T> type, UUID owner) {
        for (T e : of(type)) if (e.owner.getUUID().equals(owner)) return e;
        return null;
    }

    private static boolean ownerOk(Effect e) { return e.owner.isAlive() && (!e.ownerBound() || (!e.owner.isRemoved() && e.owner.level() == e.level)); }

    public static void tick() {
        if (!ADDED.isEmpty()) { ALL.addAll(ADDED); ADDED.clear(); }
        for (Effect e : new ArrayList<>(ALL)) {
            if (e.dead) continue;
            boolean keep;
            try {
                keep = ownerOk(e) && e.tick();
            } catch (RuntimeException ex) {
                DimManip.LOGGER.error("Dimension Manipulation: an effect failed and was removed", ex);
                keep = false;
            }
            if (!keep && !e.dead) { e.dead = true; safeEnd(e, ownerOk(e)); }
        }
        ALL.removeIf(x -> x.dead);
        ADDED.removeIf(x -> x.dead);
    }

    /** Ends every effect of this player (logout, death, dimension change). */
    public static void removeOwner(UUID owner) { remove(e -> e.owner.getUUID().equals(owner), false); }

    public static void remove(Predicate<Effect> which, boolean natural) {
        List<Effect> hit = new ArrayList<>();
        for (Effect e : ALL) if (!e.dead && which.test(e)) hit.add(e);
        for (Effect e : ADDED) if (!e.dead && which.test(e)) hit.add(e);
        for (Effect e : hit) { if (e.dead) continue; e.dead = true; safeEnd(e, natural); }
    }

    /** Ends one effect now (its end() runs with natural = {@code natural}). */
    public static void stop(Effect e, boolean natural) { remove(x -> x == e, natural); }

    public static void clear() { remove(e -> true, false); ALL.clear(); ADDED.clear(); }

    private static void safeEnd(Effect e, boolean natural) {
        try { e.end(natural); } catch (RuntimeException ex) { DimManip.LOGGER.error("Dimension Manipulation: an effect failed to end", ex); }
    }
}
