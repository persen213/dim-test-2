package dev.toaru.dimmanip.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** The player's right arm drawn in his own skin (both layers), for {@link Limb}. Only used inside the world renderer. */
final class SkinArm {
    private SkinArm() { }

    static @Nullable Function<ResourceLocation, VertexConsumer> buffers;
    static @Nullable Matrix4f pose;
    static @Nullable Vec3 camera;

    /** Where each limb's unwrapped box sits on the skin: {x, y, overlay x, overlay y}. */
    private static final int[][] AT = {{40, 16, 40, 32}, {32, 48, 48, 48}, {0, 16, 0, 32}, {16, 48, 0, 48}};

    static boolean draw(Entity owner, int part, Vec3 top, Vec3 d, Vec3 f, double scale, int from, int len) {
        if (buffers == null || pose == null || camera == null || !(owner instanceof AbstractClientPlayer p)) return false;
        if (part < 0 || part >= AT.length || from < 0 || len < 1 || from + len > 12) return false;
        ResourceLocation tex = p.getSkinTextureLocation();
        if (tex == null) return false;
        VertexConsumer out = buffers.apply(tex);
        if (out == null) return false;
        int w = part < 2 && "slim".equals(p.getModelName()) ? 3 : 4;
        float light = Fxu.light(top);
        int[] at = AT[part];
        layer(out, top, d, f, scale, w, at[0], at[1], from, len, light);
        // The sleeve or trouser layer, a touch larger (clear pixels of it are not drawn).
        layer(out, top.subtract(d.scale(0.25 * Limb.PX * scale)), d, f, scale * 1.045, w, at[2], at[3], from, len, light);
        return true;
    }

    private static void layer(VertexConsumer out, Vec3 top, Vec3 d, Vec3 f, double scale, int w, int ox, int oy, int from, int len, float light) {
        double px = Limb.PX * scale, hs = w * px / 2, hf = 2 * px;
        Vec3 s = d.cross(f);
        Vec3 dl = d.scale(len * px);
        Vec3 of = top.add(s.scale(hs)).add(f.scale(hf)), nf = top.subtract(s.scale(hs)).add(f.scale(hf));
        Vec3 nb = top.subtract(s.scale(hs)).subtract(f.scale(hf)), ob = top.add(s.scale(hs)).subtract(f.scale(hf));
        int v0 = oy + 4 + from, v1 = v0 + len;
        // Unwrapped round the limb: the side toward his right, front, the other side, back; the caps above them.
        quad(out, ob, of, of.add(dl), ob.add(dl), ox, v0, ox + 4, v1, s, light);
        quad(out, of, nf, nf.add(dl), of.add(dl), ox + 4, v0, ox + 4 + w, v1, f, light);
        quad(out, nf, nb, nb.add(dl), nf.add(dl), ox + 4 + w, v0, ox + 8 + w, v1, s.scale(-1), light);
        quad(out, nb, ob, ob.add(dl), nb.add(dl), ox + 8 + w, v0, ox + 8 + 2 * w, v1, f.scale(-1), light);
        quad(out, ob, nb, nf, of, ox + 4, oy, ox + 4 + w, oy + 4, d.scale(-1), light);
        quad(out, ob.add(dl), nb.add(dl), nf.add(dl), of.add(dl), ox + 4 + w, oy, ox + 4 + 2 * w, oy + 4, d, light);
    }

    private static void quad(VertexConsumer out, Vec3 p1, Vec3 p2, Vec3 p3, Vec3 p4, int u0, int v0, int u1, int v1, Vec3 n, float light) {
        int c = Math.max(0, Math.min(255, Math.round(255 * light * Fxu.facing(n))));
        float a = u0 / 64f, b = v0 / 64f, e = u1 / 64f, g = v1 / 64f;
        vert(out, p1, c, a, b); vert(out, p2, c, e, b); vert(out, p3, c, e, g); vert(out, p4, c, a, g);
    }

    private static void vert(VertexConsumer out, Vec3 p, int c, float u, float v) {
        out.vertex(pose, (float) (p.x - camera.x), (float) (p.y - camera.y), (float) (p.z - camera.z)).color(c, c, c, 255).uv(u, v).endVertex();
    }
}
