package dev.toaru.dimmanip.client;

import static dev.toaru.dimmanip.client.Fxu.*;

import dev.toaru.dimmanip.Space;
import dev.toaru.dimmanip.Space.Rect;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Dimension Manipulation's look: coordinate grids, registration marks, outlines and surfaces that sit slightly out of
 * place - the space itself being redrawn, never runes or spell circles. White lines, violet depth, a cold cyan accent.
 */
final class FxDim {
    private FxDim() { }

    static final Vec3 UP = FxRenderer.UP;
    static final int WHITE = 0xE6DCCB, DIM = 0x4A2A5A, CYAN = 0x9A2A34, VOID = 0x020103, BONE = 0xE6DCCB, BLOOD = 0x8E1424;
    /** One colour per door, so you can read which door leads where. */
    static final int[] DOORS = {0xC9B9A2, 0xB0202E, 0x6A9A9A, 0xC08A2A, 0x7A5AA0, 0x9A6A4A, 0x5A8A5A, 0xA8A8B0};

    static void draw(ClientFx.Effect e, @Nullable Entity src, Geo crystal, Geo glow, Geo solid, Geo xray, double age, double time, float pt) {
        switch (e.type) {
            case SENSE -> sense(e, src, xray, age, time, pt);
            case SHIFT -> shift(e, crystal, glow, age, time);
            case ATLAS -> atlas(e, crystal, glow, age, time);
            case REND -> rend(e, crystal, glow, age, time);
            case SKY_RIP -> skyRip(e, crystal, glow, age, time);
            case HORIZON -> horizon(e, crystal, glow, age, time);
            case REGRESS -> regress(e, crystal, glow, age, time);
            case INVERT -> invert(e, crystal, glow, age, time);
            case SHATTER -> shatter(e, crystal, glow, age, time);
            case INCEPTION -> inception(e, crystal, glow, age, time);
            case ECHO -> echo(e, crystal, glow, age, time);
            case POCKET -> pocket(e, crystal, glow, age, time);
            case PSY -> PsyTunnel.draw(e, solid, glow, age, time);
            case PERSPECTIVE -> perspective(e, src, crystal, glow, age, time, pt);
            case CAST -> cast(e, src, crystal, glow, age, time, pt);
            case TESS -> tess(e, crystal, glow, age, time);
            case GRAVITY -> gravity(e, src, crystal, glow, age, time, pt);
            case KALEIDO -> kaleido(e, crystal, glow, age, time);
            default -> { }
        }
    }

    // ================================================================== shared pieces
    /** The rectangle a SURFACE / DOOR effect describes. */
    static Rect rect(ClientFx.Effect e) {
        Vec3 n = e.aux.lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : e.aux.normalize();
        Vec3 up = switch (e.c) {
            case 2 -> new Vec3(0, 0, -1);
            case 3 -> new Vec3(0, 0, 1);
            case 4 -> new Vec3(-1, 0, 0);
            case 5 -> new Vec3(1, 0, 0);
            default -> UP;
        };
        return Rect.of(e.pos, n, up, Math.max(0.3, e.power / 2), Math.max(0.3, e.b / 20.0));
    }

    static Vec3 corner(Rect r, double sx, double sy, double s, double lift) {
        return r.world(new Vec3(sx * r.hw() * s, sy * r.hh() * s, lift));
    }

    /** A rectangle's outline (scale s of its size, lifted off the surface a little). */
    static void outline(Geo g, Rect r, double s, double lift, double w, int rgb, float a) {
        Vec3 p0 = corner(r, -1, -1, s, lift), p1 = corner(r, 1, -1, s, lift), p2 = corner(r, 1, 1, s, lift), p3 = corner(r, -1, 1, s, lift);
        col(g, rgb, a).ribbon(p0, p1, w).ribbon(p1, p2, w).ribbon(p2, p3, w).ribbon(p3, p0, w);
    }

    /** Registration marks: an L at each corner, like the crop marks of a technical drawing. */
    static void marks(Geo g, Rect r, double s, double len, double lift, int rgb, float a) {
        for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) {
            Vec3 c = corner(r, sx, sy, s, lift);
            col(g, rgb, a).ribbon(c, c.add(r.u().scale(-sx * len)), 0.025).ribbon(c, c.add(r.v().scale(-sy * len)), 0.025);
        }
    }

    /** A grid of lines across a rectangle, slid by {@code offset} (in cells) so it doesn't line up with the world. */
    static void grid(Geo g, Rect r, double cell, double offU, double offV, double lift, double w, int rgb, float a) {
        int nu = (int) Math.ceil(r.hw() * 2 / cell), nv = (int) Math.ceil(r.hh() * 2 / cell);
        for (int i = 0; i <= nu; i++) {
            double x = -r.hw() + ((i * cell + offU * cell) % (r.hw() * 2 + 1e-9));
            col(g, rgb, a).ribbon(r.world(new Vec3(x, -r.hh(), lift)), r.world(new Vec3(x, r.hh(), lift)), w);
        }
        for (int j = 0; j <= nv; j++) {
            double y = -r.hh() + ((j * cell + offV * cell) % (r.hh() * 2 + 1e-9));
            col(g, rgb, a).ribbon(r.world(new Vec3(-r.hw(), y, lift)), r.world(new Vec3(r.hw(), y, lift)), w);
        }
    }

    static void quad(Geo g, Rect r, double s, double lift, int argb) {
        g.gquad(corner(r, -1, -1, s, lift), argb, corner(r, 1, -1, s, lift), argb, corner(r, 1, 1, s, lift), argb, corner(r, -1, 1, s, lift), argb);
    }

    /** A cube's frame built of solid lit bars (centre, half-size, turned by yaw and tilt). */
    static void cube(Geo g, Vec3 c, double s, double yaw, double tilt, int rgb, float a, double w) {
        Vec3[] p = new Vec3[8];
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? -s : s, y = (i & 2) == 0 ? -s : s, z = (i & 4) == 0 ? -s : s;
            double y2 = y * Math.cos(tilt) - z * Math.sin(tilt), z2 = y * Math.sin(tilt) + z * Math.cos(tilt);
            p[i] = c.add(x * Math.cos(yaw) - z2 * Math.sin(yaw), y2, x * Math.sin(yaw) + z2 * Math.cos(yaw));
        }
        int[][] ed = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        double bw = Math.max(0.05, w * 2.4);
        for (int[] d : ed) Solid.bar(g, p[d[0]], p[d[1]], bw, 0, rgb, a, 0);
    }


    // ================================================================== the trippy toolkit
    /** A colour round the spectrum (h 0..1), bright and slightly pastel, like light on oil. */
    /** The colours of what lies behind reality, round a loop (h 0..1): bruise violet, dried blood, crimson, bone. */
    static final int[] COSMOS = {0x2E1A48, 0x4A0C16, 0x8E1424, 0xC9B9A2};
    static final double GOLD = 0.75;

    static int hue(double h) {
        h = (h - Math.floor(h)) * COSMOS.length;
        int i = (int) Math.floor(h) % COSMOS.length;
        return mix(COSMOS[i], COSMOS[(i + 1) % COSMOS.length], h - Math.floor(h));
    }

    /** The sheen at a point and moment: hue flowing slowly through space and time. */
    static double sheen(Vec3 p, double time) { return time * 0.004 + (p.x + p.y * 0.7 + p.z * 1.3) * 0.035; }

    /**
     * A line seen through a bad lens: a magenta ghost and a cyan ghost split to either side, and an iridescent core.
     * {@code split} is how far apart the ghosts sit (it breathes a little).
     */
    static void trip(Geo g, Vec3 a, Vec3 b, double w, float alpha, double h, double split) {
        Vec3 d = b.subtract(a), toCam = g.cam().subtract(a);
        Vec3 side = d.cross(toCam);
        side = side.lengthSqr() < 1e-9 ? new Vec3(0, 0, 0) : side.normalize().scale(split);
        col(g, 0xB01020, alpha * 0.3f).ribbon(a.add(side), b.add(side), w);
        col(g, 0x204A50, alpha * 0.25f).ribbon(a.subtract(side), b.subtract(side), w);
        col(g, hue(h), alpha).ribbon(a, b, w * 0.8);
    }

    static void trip(Geo g, Vec3 a, Vec3 b, double w, float alpha, double time) {
        trip(g, a, b, w, alpha, sheen(a, time), 0.02 + 0.012 * Math.sin(time * 0.13));
    }

    /** A rectangle turned by {@code twist} in its own plane, at scale s and depth lift. */
    static Vec3[] twisted(Rect r, double s, double lift, double twist) {
        Vec3[] out = new Vec3[4];
        double[][] cs = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        double c = Math.cos(twist), sn = Math.sin(twist);
        for (int i = 0; i < 4; i++) {
            double x = cs[i][0] * r.hw() * s, y = cs[i][1] * r.hh() * s;
            out[i] = r.world(new Vec3(x * c - y * sn, x * sn + y * c, lift));
        }
        return out;
    }

    /** A black sun: a disc of nothing with a pale, slowly writhing corona and a red rim. */
    static void eclipse(Geo crystal, Geo glow, Vec3 c, double R, double time, float a) {
        Vec3 cam = glow.cam();
        Vec3 n = cam.subtract(c);
        n = n.lengthSqr() < 1e-6 ? UP : n.normalize();
        glow.softFacing(c, R * 2.4, 24, argb(0.22f * a, 0x8A7A6A), argb(0f, 0x100808));
        Vec3[] uv = Geo.basis(n);
        for (int i = 0; i < 36; i++) {
            double ang = i * Math.PI / 18 + Math.sin(time * 0.01 + i) * 0.05, len = R * (0.25 + 0.5 * (0.5 + 0.5 * Math.sin(time * 0.03 + i * 2.3)));
            Vec3 d = uv[0].scale(Math.cos(ang)).add(uv[1].scale(Math.sin(ang)));
            Vfx.band(glow, c.add(d.scale(R * 1.02)), c.add(d.scale(R + len)), 0.08 * R, 0xB8A890, 0.18f * a);
        }
        col(glow, BLOOD, 0.8f * a).ring(c, n, R * 1.01, R * 0.02, 64, 0, false);
        col(crystal, 0x000000, 0.97f * a).disc(c.add(n.scale(0.05)), n, R, 48);
    }


    // ================================================================== Spatial Registration (passive)
    /** A creature the esper has registered: its box drawn through walls, in the colour of where it stands in space. */
    static void sense(ClientFx.Effect e, @Nullable Entity src, Geo xray, double age, double time, float pt) {
        if (src == null || !src.isAlive()) return;
        float k = env(age, e.duration, 4, 6);
        Vec3 feet = src.getPosition(pt);
        double hw = src.getBbWidth() / 2 + 0.06, h = src.getBbHeight() + 0.06;
        Geo.nearFade = 0;
        int c = BONE;
        col(xray, c, 0.5f * k).wireBox(feet.add(-hw, 0, -hw), feet.add(hw, h, hw), 0.022);
        col(xray, BLOOD, 0.45f * k).ring(feet.add(0, 0.02, 0), UP, hw + 0.25, 0.012, 4, Math.PI / 4 + time * 0.01, false);
    }

    // ================================================================== the rift: reality torn open
    /**
     * Reality torn open across a rectangle: first a bright crack, then the cloth of the world pulled apart along it -
     * glowing gold-white edges with colour fringes, the torn cloth curling back, threads stretched across the gap and
     * snapping - and behind it deep space: a nebula, a turning galaxy, stars, falling away into depth.
     * {@code open} 0..1 is how far it has opened; {@code tint} shifts the nebula's colours.
     */
    static void rift(Geo crystal, Geo glow, Rect r, double open, double time, long seed, float a, double tint) {
        if (open <= 0.001 || a <= 0.01f) return;
        double len = smooth(open * 3.5), wid = smooth((open - 0.12) / 0.88);
        int m = (int) Math.max(10, Math.round(18 * Geo.detail));
        Vec3[] L = new Vec3[m + 1], R = new Vec3[m + 1], C = new Vec3[m + 1];
        double[] half = new double[m + 1];
        for (int j = 0; j <= m; j++) {
            double t = j / (double) m, y = (t * 2 - 1) * r.hh() * len;
            double prof = Math.pow(Math.max(0, Math.sin(Math.PI * t)), 0.7);
            double h = r.hw() * wid * prof;
            double jl = (hash(seed * 7 + j) - 0.5) * 0.35 * r.hw() * wid * prof + 0.02 * Math.sin(time * 0.21 + j);
            double jr = (hash(seed * 11 + j) - 0.5) * 0.35 * r.hw() * wid * prof + 0.02 * Math.sin(time * 0.19 + j * 1.3);
            double cx = (hash(seed * 13 + j / 3) - 0.5) * 0.12 * r.hw();
            L[j] = r.world(new Vec3(cx - h + jl, y, 0.02));
            R[j] = r.world(new Vec3(cx + h + jr, y, 0.02));
            C[j] = r.world(new Vec3(cx + (jl + jr) / 2, y, 0.02));
            half[j] = h;
        }
        // The void, and the nebula glowing in it (coloured per corner so it stays inside the tear).
        for (int j = 0; j < m; j++) {
            int v0 = argb(0.92f * a, VOID);
            crystal.gquad(L[j], v0, C[j], v0, C[j + 1], v0, L[j + 1], v0);
            crystal.gquad(C[j], v0, R[j], v0, R[j + 1], v0, C[j + 1], v0);
            int cl = neb(r, L[j], time, tint, a * 0.4f), cc = neb(r, C[j], time, tint, a * 0.75f), cr = neb(r, R[j], time, tint, a * 0.4f);
            int cl1 = neb(r, L[j + 1], time, tint, a * 0.4f), cc1 = neb(r, C[j + 1], time, tint, a * 0.75f), cr1 = neb(r, R[j + 1], time, tint, a * 0.4f);
            glow.gquad(L[j], cl, C[j], cc, C[j + 1], cc1, L[j + 1], cl1);
            glow.gquad(C[j], cc, R[j], cr, R[j + 1], cr1, C[j + 1], cc1);
        }
        double rad = Math.min(r.hw() * wid, r.hh() * len) * 0.85;
        // The abyss behind it: dim red motes drifting deep down, and now and then something in the dark opening its eyes.
        if (wid > 0.2) {
            for (int i = 0; i < 18; i++) {
                double y = (hash(seed * 3 + i) * 2 - 1) * r.hh() * len * 0.9, hx = rowHalf(half, r, y, len, m) * 0.85;
                Vec3 lp = new Vec3((hash(seed * 5 + i) * 2 - 1) * hx, y + Math.sin(time * 0.01 + i) * 0.05, -0.2 - 2.5 * hash(seed * 9 + i));
                float tw = (float) (0.3 + 0.7 * Math.abs(Math.sin(time * 0.05 + i * 1.7)));
                glow.softFacing(r.world(lp), 0.015 + 0.015 * tw, 6, argb(0.5f * a * tw * (float) wid, BLOOD), argb(0f, VOID));
            }
            for (int i = 0; i < 3; i++) {
                // Each pair of eyes opens for a while, blinks, and closes again; never all at once.
                double cycle = 160 + 70 * hash(seed * 29 + i), ph = ((time + hash(seed * 31 + i) * cycle) % cycle) / cycle;
                double open1 = smooth((ph - 0.15) / 0.08) * smooth((0.75 - ph) / 0.1);
                double blink = Math.abs(((time * 0.7 + i * 40) % 90) - 45) < 2 ? 0.1 : 1;
                double o2 = open1 * blink * wid;
                if (o2 < 0.03) continue;
                double y = (hash(seed * 37 + i) - 0.5) * r.hh() * len, hx = rowHalf(half, r, y, len, m) * 0.6;
                double x = (hash(seed * 41 + i) - 0.5) * 2 * hx, depth = -0.6 - 1.5 * hash(seed * 43 + i), gap = 0.11 + 0.06 * hash(seed * 47 + i);
                for (int sd = -1; sd <= 1; sd += 2) {
                    Vec3 eye = r.world(new Vec3(x + sd * gap, y, depth));
                    glow.softFacing(eye, 0.05 * o2, 8, argb(0.9f * a * (float) o2, 0xE8E0C8), argb(0f, BLOOD));
                    glow.softFacing(eye, 0.14 * o2, 8, argb(0.25f * a * (float) o2, BLOOD), argb(0f, VOID));
                }
            }
            // Depth: the edge of the tear repeated, smaller and further, falling away.
            for (int d = 1; d <= 3; d++) {
                double sc = 1 - 0.22 * d;
                for (int j = 0; j < m; j++) {
                    Vec3 a0 = r.world(r.local(L[j]).multiply(sc, sc, 0).add(0, 0, -0.45 * d)), a1 = r.world(r.local(L[j + 1]).multiply(sc, sc, 0).add(0, 0, -0.45 * d));
                    Vec3 b0 = r.world(r.local(R[j]).multiply(sc, sc, 0).add(0, 0, -0.45 * d)), b1 = r.world(r.local(R[j + 1]).multiply(sc, sc, 0).add(0, 0, -0.45 * d));
                    col(glow, BLOOD, a * 0.25f / d).ribbon(a0, a1, 0.012).ribbon(b0, b1, 0.012);
                }
            }
        }
        // Threads of the cloth stretched over the gap, snapping one by one as it widens.
        for (int i = 0; i < 6; i++) {
            int j = 2 + (int) (hash(seed * 17 + i) * (m - 4));
            double snapAt = 0.25 + 0.6 * hash(seed * 19 + i);
            if (wid < snapAt) {
                Vec3 mid = L[j].add(R[j]).scale(0.5).add(r.n().scale(-0.05 * wid));
                col(crystal, 0x1A1416, a * 0.85f).ribbon(L[j], mid, 0.012).ribbon(mid, R[j], 0.012);
            } else {
                double after = Math.min(1, (wid - snapAt) * 4);
                for (int sd = -1; sd <= 1; sd += 2) {
                    Vec3 from = sd < 0 ? L[j] : R[j];
                    Vec3 tip = from.add(r.u().scale(-sd * 0.12 * (1 - after * 0.5))).add(r.v().scale(-0.15 * after)).add(r.n().scale(0.06));
                    col(crystal, 0x1A1416, a * 0.8f * (float) (1 - after * 0.6)).ribbon(from, tip, 0.01);
                }
            }
        }
        // The torn edges: a gold-white core, colour fringes, light pooling along them.
        for (int j = 0; j < m; j++) {
            for (Vec3[] e : new Vec3[][] {L, R}) {
                // A raw edge: a dark burnt lip, a thin pale line of light, and a dull red glow seeping from inside.
                col(crystal, 0x0E0A0C, a * 0.9f).ribbon(e[j], e[j + 1], 0.06);
                trip(glow, e[j], e[j + 1], 0.016, a * 0.45f, GOLD, 0.012);
                col(glow, BONE, a * 0.55f).ribbon(e[j], e[j + 1], 0.006);
                if (j % 3 == 1) glow.softFacing(e[j], 0.14 + 0.05 * Math.sin(time * 0.15 + j), 8, argb(0.3f * a, BLOOD), argb(0f, VOID));
            }
            // The cloth peeling back from the tear, catching the light.
            if (j % 2 == 0 && wid > 0.05) for (int sd = -1; sd <= 1; sd += 2) {
                Vec3 e0 = sd < 0 ? L[j] : R[j], e1 = sd < 0 ? L[j + 1] : R[j + 1];
                double curl = (0.08 + 0.14 * hash(seed * 23 + j + sd)) * wid;
                Vec3 apex = e0.add(e1).scale(0.5).add(r.u().scale(sd * curl)).add(r.n().scale(curl * 0.9));
                crystal.gquad(e0, argb(0.75f * a, 0x2A2224), e1, argb(0.75f * a, 0x2A2224), apex, argb(0.5f * a, 0x4A4044), apex, argb(0.5f * a, 0x4A4044));
            }
        }
        // The world darkens round it, as if the light were being drawn in.
        crystal.softDisc(r.world(new Vec3(0, 0, 0.015)), r.n(), Math.max(r.hw(), r.hh()) * (1.2 + 0.8 * wid), 24, argb(0.45f * a * (float) Math.max(0.3, wid), 0x000000), argb(0f, 0x000000));
        glow.softFacing(r.world(new Vec3(0, 0, 0.3)), Math.max(r.hw(), r.hh()) * (0.5 + 0.5 * wid), 14, argb(0.07f * a * (float) wid, BLOOD), argb(0f, VOID));
        // Black tendrils feeling their way out over the edges.
        if (wid > 0.3) for (int i = 0; i < 6; i++) {
            int j = 2 + (int) (hash(seed * 53 + i) * (m - 4));
            int sd = i % 2 == 0 ? -1 : 1;
            Vec3 from = sd < 0 ? L[j] : R[j];
            double reach = (0.3 + 0.6 * hash(seed * 59 + i)) * wid * (0.7 + 0.3 * Math.sin(time * 0.04 + i));
            Vec3 prev = from;
            for (int s2 = 1; s2 <= 7; s2++) {
                double t = s2 / 7.0;
                Vec3 q = from.add(r.u().scale(sd * reach * t)).add(r.v().scale(Math.sin(time * 0.09 + i + t * 4) * 0.15 * t)).add(r.n().scale(0.08 * t + Math.sin(time * 0.07 + t * 5 + i) * 0.05));
                col(crystal, 0x050304, a * 0.9f * (float) (1 - t * 0.5)).ribbon(prev, q, 0.035 * (1 - t) + 0.006);
                prev = q;
            }
        }
    }

    /** The tear's half-width at height y (local). */
    static double rowHalf(double[] half, Rect r, double y, double len, int m) {
        double t = (y / Math.max(1e-6, r.hh() * len) + 1) / 2;
        int j = (int) Math.max(0, Math.min(m, Math.round(t * m)));
        return half[j];
    }

    /** The nebula's colour at a point of a tear: slow clouds of the cosmic colours. */
    static int neb(Rect r, Vec3 p, double time, double tint, float a) {
        Vec3 l = r.local(p);
        double x = l.x / Math.max(0.1, r.hw()), y = l.y / Math.max(0.1, r.hh());
        double h = tint + 0.18 * Math.sin(x * 2.3 + time * 0.02) + 0.14 * Math.sin(y * 3.1 - time * 0.015);
        double k = 0.15 + 0.35 * (0.5 + 0.5 * Math.sin(x * 4.1 + y * 2.7 + time * 0.02)) * (1 - 0.6 * Math.min(1, Math.abs(y)));
        return argb(a * (float) k * 0.6f, hue(h * 0.5 + 0.2));
    }

    /** How open a tear is over an effect's life: it splits open, holds, and stitches shut at the end. */
    static double opening(double age, double dur, double in, double out) {
        return smooth(age / in) * smooth((dur - age) / out);
    }


    /**
     * On the victim's own screen only: false copies of the creatures round them, standing where they aren't, and a faint
     * refraction where the esper really is (their real body is drawn at the decoy spot by ClientEvents).
     */
    static void perspective(ClientFx.Effect e, @Nullable Entity caster, Geo crystal, Geo glow, double age, double time, float pt) {
        var mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        float k = env(age, e.duration, 5, 8) * Math.max(0.2f, e.power);
        Geo.nearFade = 0.5;
        if (caster != null) {
            Vec3 real = caster.getPosition(pt);
            col(crystal, 0xD8E8FF, 0.06f * k).humanoid(real, -caster.getYRot(), 1.0);
            col(glow, WHITE, 0.08f * k).ring(real.add(0, 1.0, 0), UP, 0.45, 0.01, 24, time * 0.1, true);
        }
        for (Entity o : mc.level.getEntities(mc.player, new AABB(mc.player.position(), mc.player.position()).inflate(16), x -> x instanceof LivingEntity && x.isAlive())) {
            if (o == caster) continue;
            // Every creature seen several times over, each copy a different colour and in the wrong place.
            for (int i = 0; i < 3; i++) {
                double ang = hash(o.getId() * 7L + i) * Math.PI * 2 + time * 0.015 * (i + 1), d = 1.2 + 2.8 * hash(o.getId() * 3L + i);
                Vec3 at = o.getPosition(pt).add(Math.cos(ang) * d, 0.2 * Math.sin(time * 0.05 + i), Math.sin(ang) * d);
                col(crystal, 0x050304, 0.3f * k).humanoid(at, -o.getYRot() + 40 * (i - 1), o.getBbHeight() / 1.8 * (0.7 + 0.6 * hash(o.getId() + i)));
            }
        }
        // Figures that aren't there: tall black shapes standing just at the edge of sight, never moving.
        Vec3 eye = mc.player.getEyePosition(pt);
        for (int i = 0; i < 5; i++) {
            double ang = hash(e.key * 11 + i) * Math.PI * 2, d = 7 + 5 * hash(e.key * 13 + i);
            Vec3 at = mc.player.getPosition(pt).add(Math.cos(ang) * d, 0, Math.sin(ang) * d);
            Vec3 face = eye.subtract(at);
            double yaw = Math.toDegrees(Math.atan2(-face.x, face.z));
            col(crystal, 0x020102, 0.55f * k).humanoid(at, -yaw, 1.25 + 0.3 * hash(e.key * 17 + i));
            Vec3 head = at.add(0, 2.25 + 0.5 * hash(e.key * 17 + i), 0);
            Vec3 side = new Vec3(face.z, 0, -face.x).normalize().scale(0.07);
            for (int sd = -1; sd <= 1; sd += 2) glow.softFacing(head.add(side.scale(sd)).add(face.normalize().scale(0.2)), 0.03, 6, argb(0.7f * k, 0xE8E0C8), argb(0f, BLOOD));
        }
        // Edges of the world doubled: faint horizon lines drifting at the wrong heights.
        Vec3 me = mc.player.getPosition(pt);
        for (int i = 0; i < 3; i++) {
            double y = me.y + 0.5 + i * 1.3 + Math.sin(time * 0.05 + i) * 0.4;
            col(glow, BLOOD, 0.08f * k).ring(new Vec3(me.x, y, me.z), UP, 6 + i * 3, 0.012, 48, 0, false);
        }
    }


    /** Where they vanished: a great tear opens and swallows them, then folds itself up into a floating cube of deep space. */
    static void pocket(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        float k = env(age, e.duration, 1, 8);
        double s = Math.max(0.4, e.power) * 0.5;
        Vec3 c = e.pos.add(0, Math.sin(time * 0.05) * 0.15, 0);
        Vec3 cam = glow.cam();
        Vec3 face = new Vec3(cam.x - c.x, 0, cam.z - c.z);
        face = face.lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : face.normalize();
        if (age < 18) {
            // The tear: opens wide, then is pulled closed into a point.
            double open = age < 10 ? age / 10 : 1 - (age - 10) / 8;
            double size = age < 10 ? 1 : 1 - 0.7 * (age - 10) / 8;
            rift(crystal, glow, Rect.of(c, face, UP, 1.2 * size, 1.7 * size), open, time, e.key, k, 0.1);
            if (age > 10) glow.softFacing(c, 2.5 * (1 - (age - 10) / 8), 16, argb(0.5f, 0xFFF4E0), argb(0f, VOID));
        }
        double grow = smooth((age - 12) / 10) * smooth((e.duration - age) / 6.0);
        if (grow <= 0) return;
        // A shell of dark glass in twenty faces that breathe apart; inside it another, lit in the colours of the tunnel,
        // and round that the tunnel itself in miniature - rings within rings going down to a burning point.
        double r = Math.max(0.9, e.power) * grow, yaw = time * 0.02;
        Solid.shell(crystal, c, r, yaw, 0.4, 0.1 + 0.08 * Math.sin(time * 0.08), 0x1A1420, 0x2E1A48, 0.75f * k, 0.8);
        Solid.shell(glow, c, r * 0.6, -yaw * 1.7, 1.1, 0.25 + 0.15 * Math.sin(time * 0.11), PsyTunnel.pal(time * 0.004), PsyTunnel.pal(time * 0.004 + 0.4), 0.4f * k, 0.3);
        Vec3 ax = new Vec3(Math.cos(yaw * 2), 0.3, Math.sin(yaw * 2)).normalize();
        for (int i = 0; i < 6; i++) {
            double f = i / 6.0, ph = (f + time * 0.01) % 1.0;
            Solid.band(glow, c.add(ax.scale((ph - 0.5) * r * 0.9)), ax, r * 0.5 * (1 - 0.8 * Math.abs(ph - 0.5) * 2 * 0.6) * (1 - ph * 0.5), 0.05, 0.05, 10, time * 0.05 + i, 0.3, PsyTunnel.pal(f + time * 0.004), PsyTunnel.pal(f + 0.5), 0.8f * k * (float) Math.sin(Math.PI * ph), 0);
        }
        glow.softFacing(c, r * 0.35, 12, argb(0.8f * k, 0xFFB050), argb(0f, 0xFF3010));
        // Splinters of the space that was cut out, circling it.
        for (int i = 0; i < 8; i++) {
            double an = time * 0.03 + i * Math.PI / 4, rr = r * (1.7 + 0.25 * Math.sin(time * 0.05 + i));
            Solid.octa(crystal, c.add(Math.cos(an) * rr, 0.5 * Math.sin(an * 2 + i), Math.sin(an) * rr), 0.14, 2.2, time * 0.06 + i, 0.5, i % 2 == 0 ? BONE : 0x8E1424, 0.9f * k, 0.4);
        }
        Solid.band(crystal, c, new Vec3(0.2 * Math.sin(time * 0.02), 1, 0.2 * Math.cos(time * 0.02)), r * 1.35, 0.1, 0.06, 28, -time * 0.03, 0.3, 0x241A2E, BONE, 0.9f * k, 0);
        crystal.softDisc(new Vec3(c.x, FxRenderer.ground(c.x, c.y - 1, c.z) + 0.04, c.z), UP, 5.5 * grow, 28, argb(0.75f * k, 0x000000), argb(0f, 0x000000));
    }

    // ================================================================== the moves' overlays (the bent terrain itself is TerrainFx)
    /** A patch of the ground made dark, as if the land there had been lifted away and only the abyss is left under it. */
    static void hole(Geo crystal, Geo glow, Vec3 a, Vec3 b, Vec3 c, Vec3 d, float alpha, double time, long seed) {
        int v = argb(0.93f * alpha, VOID);
        crystal.gquad(a, v, b, v, c, v, d, v);
        int r0 = argb(0.18f * alpha, BLOOD), r1 = argb(0.05f * alpha, BLOOD);
        glow.gquad(a, r1, b, r0, c, r1, d, r0);
        for (int i = 0; i < 3; i++) {
            double u = hash(seed * 3 + i), w = hash(seed * 7 + i);
            Vec3 p = a.add(b.subtract(a).scale(u)).add(d.subtract(a).scale(w)).add(0, 0.02, 0);
            float tw = (float) (0.3 + 0.7 * Math.abs(Math.sin(time * 0.05 + i + seed)));
            glow.softFacing(p, 0.03, 6, argb(0.6f * alpha * tw, BLOOD), argb(0f, VOID));
        }
    }

    /** Round the esper as a move is cast: space winding tight about them - turning rings climbing the body, the ground going dark. */
    static void cast(ClientFx.Effect e, @Nullable Entity src, Geo crystal, Geo glow, double age, double time, float pt) {
        if (src == null) return;
        // Never in your own eyes: only when you are seen from outside.
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        if (src == mc.player && mc.options.getCameraType().isFirstPerson()) return;
        float k = env(age, e.duration, 3, 6);
        Vec3 at = src.getPosition(pt);
        double big = e.b == 6 ? 2.2 : 1;
        crystal.softDisc(at.add(0, 0.04, 0), UP, 1.6 * big, 28, argb(0.6f * k, 0x000000), argb(0f, 0x000000));
        col(glow, BLOOD, 0.6f * k).ring(at.add(0, 0.07, 0), UP, 1.1 * big, 0.04, 48, time * 0.05, true);
        for (int i = 0; i < 3; i++) {
            double ph = (age * 0.035 + i / 3.0) % 1.0, y = 0.2 + 2.0 * ph * big;
            Vec3 n = new Vec3(0.25 * Math.sin(time * 0.06 + i * 2), 1, 0.25 * Math.cos(time * 0.05 + i * 2)).normalize();
            col(glow, i == 1 ? BLOOD : BONE, 0.55f * k * (float) Math.sin(Math.PI * ph)).ring(at.add(0, y, 0), n, (0.75 - 0.3 * ph) * big, 0.02, 40, time * 0.1 * (i % 2 == 0 ? 1 : -1), i == 1);
        }
        Solid.band(crystal, at.add(0, 0.15, 0), UP, 1.25 * big, 0.14, 0.1, 14, -time * 0.06, 0.3, 0x1A1420, 0x8E1424, 0.9f * k, 0);
        if (e.b == 6) for (int i = 0; i < 6; i++) { double an = time * 0.05 + i * Math.PI / 3; Solid.octa(crystal, at.add(Math.cos(an) * 2.4, 1.2 + 0.5 * Math.sin(an * 2), Math.sin(an) * 2.4), 0.2, 2, an, 0.3, i % 2 == 0 ? BONE : 0x8E1424, 0.9f * k, 0.4); }
    }

    /**
     * Tesseract: a cage of dark metal and glass; inside it a four-dimensional cube built of solid bars turns through
     * itself, its inner cube swelling out to become the outer one; two machined rings gimbal round the prisoner. (The floor
     * tiled across its walls and ceiling is TerrainFx.)
     */
    static void tess(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double h = Math.max(1, e.power);
        float k = env(age, e.duration, 5, 6);
        if (k <= 0.01f) return;
        Vec3 c = e.pos.add(0, h * 0.5, 0);
        double shrink = 1 - 0.85 * smooth((age - (e.duration - 6)) / 6.0);
        double w = h * easeOut(Math.min(1, age / 8.0)) * shrink;
        // The cage: heavy corner posts and beams, a pane of dark glass in each wall, a crystal on every corner.
        cube(crystal, c, w, 0, 0, 0x1A1420, k, 0.07);
        cube(glow, c, w * 1.01, 0, 0, BONE, 0.35f * k, 0.012);
        for (int f = 0; f < 4; f++) {
            double a0 = f * Math.PI / 2 + Math.PI / 4, a1 = a0 + Math.PI / 2, r2 = w * Math.sqrt(2) * 0.97;
            Vec3 p0 = c.add(Math.cos(a0) * r2, -w, Math.sin(a0) * r2), p1 = c.add(Math.cos(a1) * r2, -w, Math.sin(a1) * r2);
            Solid.face(crystal, p0, p1, p1.add(0, 2 * w, 0), p0.add(0, 2 * w, 0), 0x2E1A48, 0.5f * k, 1);
            for (int y = -1; y <= 1; y += 2) Solid.octa(crystal, c.add(Math.cos(a0) * r2 * 1.03, y * w, Math.sin(a0) * r2 * 1.03), 0.22, 1.6, time * 0.05 + f, 0.2, BONE, 0.9f * k, 0.3);
        }
        // The turning tesseract.
        double t1 = time * 0.035, t2 = time * 0.023;
        Vec3[] v = new Vec3[16];
        for (int i = 0; i < 16; i++) {
            double x = (i & 1) == 0 ? -1 : 1, y = (i & 2) == 0 ? -1 : 1, z = (i & 4) == 0 ? -1 : 1, q = (i & 8) == 0 ? -1 : 1;
            double x2 = x * Math.cos(t1) - q * Math.sin(t1), q2 = x * Math.sin(t1) + q * Math.cos(t1);
            double z2 = z * Math.cos(t2) - q2 * Math.sin(t2), q3 = z * Math.sin(t2) + q2 * Math.cos(t2);
            double pr = 1.25 / (2.4 - q3);
            v[i] = c.add(x2 * pr * w * 0.85, y * pr * w * 0.85, z2 * pr * w * 0.85);
        }
        for (int i = 0; i < 16; i++) for (int b = 0; b < 4; b++) {
            int j = i ^ (1 << b);
            if (j < i) continue;
            Solid.bar(glow, v[i], v[j], b == 3 ? 0.05 : 0.07, time * 0.02, b == 3 ? BLOOD : BONE, (b == 3 ? 0.7f : 0.6f) * k, 0);
        }
        for (int i = 0; i < 16; i++) Solid.octa(glow, v[i], 0.11, 1, time * 0.1 + i, 0.4, BONE, 0.9f * k, 0);
        // Two rings gimballing round whoever is inside.
        Vec3 n1 = new Vec3(Math.sin(time * 0.03), 0.4, Math.cos(time * 0.03)), n2 = new Vec3(Math.cos(time * 0.021), -0.6, Math.sin(time * 0.021));
        Solid.band(crystal, c, n1, w * 0.72, 0.16, 0.08, 20, time * 0.04, 0.25, 0x241A2E, 0x8E1424, 0.95f * k, 0);
        Solid.band(crystal, c, n2, w * 0.55, 0.12, 0.08, 14, -time * 0.05, 0.25, 0x241A2E, 0xC9B9A2, 0.95f * k, 0);
        crystal.softDisc(e.pos.add(0, -h * 0.5 + 0.05, 0), UP, w * 1.7, 28, argb(0.6f * k, 0x000000), argb(0f, 0x000000));
        glow.softFacing(c, 0.3 + 0.08 * Math.sin(time * 0.2), 12, argb(0.6f * k, BONE), argb(0f, BLOOD));
    }

    /**
     * Gravity Well: a great gimbal hanging over the area - three machined rings, the innermost always square to the new
     * "down" - with a long crystal plumb through its middle pointing the way things now fall, and shards streaming that
     * way. (The plates of ground lifting and tipping toward it are TerrainFx.)
     */
    static void gravity(ClientFx.Effect e, @Nullable Entity src, Geo crystal, Geo glow, double age, double time, float pt) {
        double R = Math.max(2, e.power);
        float k = env(age, e.duration, 6, 8);
        if (k <= 0.01f) return;
        Vec3 dir = src != null ? src.getViewVector(pt) : new Vec3(0, -1, 0);
        dir = dir.lengthSqr() < 1e-6 ? new Vec3(0, -1, 0) : dir.normalize();
        Vec3 c = e.pos.add(0, 5.5, 0);
        double grow = easeOut(Math.min(1, age / 10.0));
        crystal.softDisc(e.pos.add(0, 0.05, 0), UP, R * 1.15, 40, argb(0.5f * k, 0x000000), argb(0f, 0x000000));
        // The boundary: a low wall of blocks of dark glass round the area, turning slowly.
        Solid.band(crystal, e.pos.add(0, 0.3, 0), UP, R, 0.35, 0.6, 36, time * 0.006, 0.3, 0x1A1420, 0x4A0C16, 0.85f * k, 0.3);
        // The gimbal.
        Vec3[] q = Solid.square(dir);
        Vec3 n2 = q[0].scale(Math.cos(time * 0.025)).add(q[1].scale(Math.sin(time * 0.025)));
        Vec3 n3 = dir.scale(Math.cos(time * 0.017)).add(n2.cross(dir).scale(Math.sin(time * 0.017)));
        Solid.band(crystal, c, dir, 3.0 * grow, 0.4, 0.2, 24, time * 0.05, 0.2, 0x241A2E, 0xC9B9A2, 0.95f * k, 0);
        Solid.band(crystal, c, n2, 4.1 * grow, 0.34, 0.18, 30, -time * 0.03, 0.2, 0x241A2E, 0x8E1424, 0.95f * k, 0);
        Solid.band(crystal, c, n3, 5.2 * grow, 0.3, 0.16, 36, time * 0.02, 0.2, 0x1A1420, 0x2E1A48, 0.95f * k, 0);
        // The plumb: a long crystal through the middle, its point the way things fall.
        Solid.spike(crystal, c.subtract(dir.scale(1.4 * grow)), c.add(dir.scale(3.4 * grow)), 0.7, time * 0.04, 0x8E1424, 0.9f * k, 0.5);
        Solid.spike(glow, c.subtract(dir.scale(1.0 * grow)), c.add(dir.scale(3.0 * grow)), 0.3, -time * 0.04, BONE, 0.7f * k, 0);
        // Shards and rubble falling that way through the whole area.
        Vec3 side = q[0], up2 = q[1];
        for (int i = 0; i < 46; i++) {
            double ang = hash(e.key + i) * Math.PI * 2, rr = R * Math.sqrt(hash(e.key * 3 + i)), ph = (time * (0.02 + 0.025 * hash(e.key * 5 + i)) + hash(e.key * 7 + i)) % 1.0;
            Vec3 p = e.pos.add(0, 3, 0).add(side.scale(Math.cos(ang) * rr)).add(up2.scale(Math.sin(ang) * rr)).add(dir.scale((ph - 0.5) * R * 1.8));
            float a = (float) Math.sin(Math.PI * ph) * k;
            if (i % 3 == 0) {
                double sz = 0.08 + 0.14 * hash(e.key * 11 + i);
                col(crystal, shade(0x6A5A48, light(p)), a).cuboid(p, sz, sz, sz, time * 0.08 + i);
            } else Solid.spike(i % 2 == 0 ? crystal : glow, p, p.add(dir.scale(0.8 + 1.8 * ph)), 0.09, i, i % 5 == 0 ? BLOOD : BONE, 0.7f * a, 0.5);
        }
    }

    /**
     * Kaleidoscope: six thick panes of glass standing out from the middle, light sliding up them, a crystal on each; a
     * six-sided lens turning overhead; splinters of mirror hanging in the air, six of each. (The ground rippling in the
     * same six-fold pattern, and the five other espers, are TerrainFx.)
     */
    static void kaleido(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double R = Math.max(2, e.power), H = 11;
        float k = env(age, e.duration, 6, 5);
        if (k <= 0.01f) return;
        Vec3 o = e.pos.add(0, 0.06, 0);
        double rise = easeOut(Math.min(1, age / 8.0));
        crystal.softDisc(o, UP, R * 1.1, 40, argb(0.4f * k, 0x000000), argb(0f, 0x000000));
        for (int i = 0; i < 6; i++) {
            double ang = i * Math.PI / 3 + Math.PI / 6;
            Vec3 d = new Vec3(Math.cos(ang), 0, Math.sin(ang));
            Vec3 b0 = o.add(d.scale(0.5)), b1 = o.add(d.scale(R)), t0 = b0.add(0, H * rise, 0), t1 = b1.add(0, H * rise * 0.8, 0);
            Solid.slab(crystal, b0, b1, t1, t0, 0.14, mix(0xBFD0E0, hue(0.2 + i / 6.0), 0.35), 0.3f * k, 1);
            // A band of light sliding up the glass.
            double band = (time * 0.012 + i * 0.17) % 1.0, bw = 0.07;
            Vec3 m0 = b0.add(0, H * rise * band, 0), m1 = b1.add(0, H * rise * 0.8 * band, 0), m2 = b1.add(0, H * rise * 0.8 * Math.min(1, band + bw), 0), m3 = b0.add(0, H * rise * Math.min(1, band + bw), 0);
            int lit = argb(0.18f * k, 0xE6F0FF), off = argb(0f, 0xE6F0FF);
            glow.gquad(m0, off, m1, off, m2, lit, m3, lit);
            // A foot of dark metal under each pane, and a crystal standing on its outer end.
            Solid.bar(crystal, b0, b1, 0.3, 0, 0x1A1420, 0.95f * k, 0);
            Solid.octa(crystal, t1.add(0, 0.5, 0), 0.4, 1.8, time * 0.04 + i, 0.15, mix(0xE6F0FF, hue(0.2 + i / 6.0), 0.5), 0.85f * k, 0.6);
        }
        // The lens overhead: three six-sided rings, turning against each other.
        Vec3 top = o.add(0, H * rise * 0.9, 0);
        Solid.band(crystal, top, UP, R * 0.55, 0.5, 0.18, 6, time * 0.01, 0.06, 0x241A2E, 0xC9B9A2, 0.9f * k, 0.2);
        Solid.band(crystal, top.add(0, 0.6, 0), UP, R * 0.34, 0.4, 0.16, 6, -time * 0.02 + 0.5, 0.06, 0x8E1424, 0x241A2E, 0.9f * k, 0.2);
        Solid.band(crystal, top.add(0, 1.1, 0), UP, R * 0.16, 0.3, 0.14, 6, time * 0.04, 0.06, 0xC9B9A2, 0xE6F0FF, 0.9f * k, 0.4);
        // The edge of it on the ground: twelve blocks of glass.
        Solid.band(crystal, o.add(0, 0.2, 0), UP, R, 0.4, 0.4, 12, Math.PI / 6, 0.12, 0x241A2E, 0xBFD0E0, 0.7f * k, 0.5);
        // Splinters of mirror, six of each.
        for (int i = 0; i < 12; i++) {
            double a0 = hash(e.key + i) * Math.PI / 3, rr = R * (0.25 + 0.7 * hash(e.key * 3 + i)), yy = 1 + (H - 3) * hash(e.key * 5 + i) + 0.5 * Math.sin(time * 0.03 + i);
            double spin = time * 0.07 + i * 1.9, sz = 0.25 + 0.35 * hash(e.key * 7 + i);
            float gl = (float) Math.pow(Math.abs(Math.sin(spin * 0.6)), 6);
            for (int j = 0; j < 6; j++) {
                double a = (j % 2 == 0 ? a0 : -a0) + j * Math.PI / 3 + Math.PI / 6 + time * 0.004;
                Vec3 m = o.add(Math.cos(a) * rr, yy * rise, Math.sin(a) * rr);
                Solid.octa(crystal, m, sz, 0.35, spin + j, 1.2, mix(0xE6F0FF, hue(0.2 + j / 6.0), 0.4), (0.45f + 0.5f * gl) * k, 0.7);
                if (gl > 0.6f) glow.softFacing(m, sz * 0.7, 8, argb(0.45f * gl * k, 0xFFFFFF), argb(0f, BLOOD));
            }
        }
    }

    /** A spire of lit crystal standing on a point (an accent, never the main thing). */
    static void shaft(Geo g, Vec3 base, double h, double r, int rgb, float a) {
        if (a <= 0.01f || h <= 0.01) return;
        Solid.spike(g, base, base.add(0, Math.min(h, 6) * 0.6, 0), Math.min(0.5, r * 0.35), h, rgb, Math.min(1f, a * 1.3f), 0.6);
    }

    /** Shards thrown out flat along the ground from a point. */
    static void burst(Geo g, Vec3 c, int n, double r0, double r1, int rgb, float a, long seed) {
        if (a <= 0.01f) return;
        for (int i = 0; i < n; i++) {
            double ang = (i + hash(seed + i)) * Math.PI * 2 / n, len = r1 * (0.6 + 0.4 * hash(seed * 3 + i));
            Vec3 d = new Vec3(Math.cos(ang), 0.06 + 0.1 * hash(seed * 7 + i), Math.sin(ang));
            Solid.spike(g, c.add(d.scale(r0)), c.add(d.scale(len)), 0.1 + 0.12 * hash(seed * 5 + i), i, rgb, a * (float) (0.5 + 0.5 * hash(seed * 5 + i)), 0.4);
        }
    }

    /** The passive's dodge: where the esper was, a dark afterimage that splits like torn paper, and a seam of light. */
    static void shift(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double k = age / Math.max(1, e.duration);
        float a = (float) (1 - k);
        for (int i = 0; i < 3; i++) {
            Vec3 off = e.aux.subtract(e.pos).scale(i * 0.33 * Math.min(1, k * 3));
            col(crystal, i == 0 ? 0x050304 : 0x2A1418, (0.5f - 0.13f * i) * a).humanoid(e.pos.add(off), e.power, 1.0);
        }
        Vec3 c = e.pos.add(0, 1, 0);
        Vec3 face = glow.cam().subtract(c);
        face = new Vec3(face.x, 0, face.z).lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : new Vec3(face.x, 0, face.z).normalize();
        rift(crystal, glow, Rect.of(c, face, UP, 0.35, 1.0), Math.sin(Math.PI * Math.min(1, k * 1.3)) * 0.5, time, e.key, a, 0.2);
    }

    /** Atlas Fold: the land folding away leaves the abyss under it; light creases run along every fold. */
    static void atlas(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double fold = Math.max(1, e.b);
        double k = age < fold ? smooth(age / fold) : 1 - smooth((age - fold) / 12);
        if (k <= 0.01) return;
        Vec3 from = e.pos, d = e.aux.subtract(e.pos);
        Vec3 u = new Vec3(d.x, 0, d.z).normalize(), w = new Vec3(-u.z, 0, u.x);
        double L = new Vec3(d.x, 0, d.z).length();
        // The ground left behind, where the folded strip has pulled away from.
        int n = Math.max(2, (int) (L / 2));
        for (int i = 0; i < n; i++) {
            double s0 = L * i / n, s1 = L * (i + 1) / n;
            if (s1 < L * (1 - 0.85 * k)) continue;
            Vec3 p0 = from.add(u.scale(s0)), p1 = from.add(u.scale(s1));
            double y0 = FxRenderer.ground(p0.x, p0.y, p0.z) + 0.03, y1 = FxRenderer.ground(p1.x, p1.y, p1.z) + 0.03;
            hole(crystal, glow, new Vec3(p0.x, y0, p0.z).add(w.scale(-2.5)), new Vec3(p0.x, y0, p0.z).add(w.scale(2.5)),
                    new Vec3(p1.x, y1, p1.z).add(w.scale(2.5)), new Vec3(p1.x, y1, p1.z).add(w.scale(-2.5)), (float) k, time, e.key + i);
        }
        // Creases of light across the strip where the land is folding, and a seam down each edge.
        int creases = Math.max(3, (int) (L / 3));
        for (int i = 1; i < creases; i++) {
            Vec3 p = from.add(u.scale(L * i / creases));
            p = new Vec3(p.x, FxRenderer.ground(p.x, p.y, p.z) + 0.08 + 1.2 * k * Math.abs(Math.sin(i * 1.7)), p.z);
            trip(glow, p.add(w.scale(-2.6)), p.add(w.scale(2.6)), 0.03, 0.8f * (float) k, GOLD, 0.03);
        }
        if (age >= fold) {
            float fa = (float) (1 - smooth((age - fold) / 12));
            Solid.band(crystal, e.aux.add(0, 0.3, 0), UP, 1.2 + 3.5 * (1 - fa), 0.35, 0.5 * fa + 0.05, 16, fa * 3, 0.3, 0x1A1420, 0xC9B9A2, fa, 0.3);
            burst(glow, e.aux.add(0, 0.1, 0), 18, 0.4, 2.5 + 4 * (1 - fa), BONE, 0.7f * fa, e.key);
        }
        // Where it touches down: the far side torn open to let him through.
        Vec3 to = e.aux.add(0, 1, 0);
        Vec3 face = new Vec3(-u.x, 0, -u.z);
        double open = age < fold ? smooth(age / fold) : 1 - smooth((age - fold) / 8);
        rift(crystal, glow, Rect.of(to, face, UP, 0.8, 1.3), open, time, e.key, 1f, 0.1);
        rift(crystal, glow, Rect.of(from.add(0, 1, 0), u, UP, 0.8, 1.3), open, time, e.key + 1, 1f, 0.1);
    }

    /** Rend: a tear in the ground along the whole line, the abyss and its eyes between the two halves. */
    static void rend(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double open = opening(age, e.duration, Math.max(1, e.b), 12);
        Vec3 d = e.aux.subtract(e.pos);
        Vec3 u = new Vec3(d.x, 0, d.z).normalize();
        double L = new Vec3(d.x, 0, d.z).length();
        Vec3 mid = e.pos.add(d.scale(0.5));
        double y = FxRenderer.ground(mid.x, mid.y, mid.z) + 0.05;
        rift(crystal, glow, Rect.of(new Vec3(mid.x, y, mid.z), UP, u, 1.8, L / 2), open, time, e.key, 1f, 0.15);
        // The two ends of the cut are one place: the same broken arch stands at each, its stones hanging out of true,
        // turning the same way at the same moment so you can see they are one thing.
        Vec3 wv = new Vec3(-u.z, 0, u.x);
        if (open > 0.2) {
            for (int end = 0; end < 2; end++) {
                Vec3 base = e.pos.add(u.scale(end == 0 ? 0.8 : L - 0.8));
                base = new Vec3(base.x, y, base.z);
                Vec3 faceDir = end == 0 ? u : u.scale(-1);
                rift(crystal, glow, Rect.of(base.add(0, 1.6, 0), faceDir, UP, 1.0, 1.5), open, time, e.key + 5, 1f, 0.1);
                int stones = 11;
                for (int i = 0; i < stones; i++) {
                    double f = i / (double) (stones - 1), an = Math.PI * f;
                    Vec3 at = base.add(wv.scale(Math.cos(an) * 1.9)).add(0, 0.3 + Math.sin(an) * 3.2 * open, 0);
                    double wob = 0.12 * Math.sin(time * 0.05 + i * 1.3), tw = 0.25 * Math.sin(time * 0.03 + i);
                    Vec3 tang = wv.scale(-Math.sin(an)).add(0, Math.cos(an), 0).normalize();
                    Vec3 outv = wv.scale(Math.cos(an)).add(0, Math.sin(an), 0).normalize();
                    Vec3 x = tang.scale(0.42), yv = outv.scale(0.3).add(faceDir.scale(tw * 0.3)), z = faceDir.scale(0.32).subtract(outv.scale(tw * 0.3));
                    Solid.box(crystal, at.add(outv.scale(wob)), x, yv, z, i % 3 == 1 ? 0x4A0C16 : 0x1A1420, (float) open, 0.15);
                }
                Solid.octa(crystal, base.add(0, 4.6 * open + 0.2 * Math.sin(time * 0.06), 0), 0.35, 2, time * 0.05, 0.1, BONE, (float) open, 0.5);
            }
        }
        // Along the cut, blades of dark glass stand up out of it one after another, leaning away from each other.
        int blades = Math.max(4, (int) (L / 2.5));
        for (int i = 1; i < blades; i++) {
            double f = i / (double) blades, up = smooth((open * 1.4 - f * 0.4) / 1.0);
            if (up <= 0.02) continue;
            Vec3 p = e.pos.add(u.scale(L * f));
            p = new Vec3(p.x, y, p.z);
            double hgt = (2.2 + 2.6 * hash(e.key * 13 + i)) * up, lean = (i % 2 == 0 ? 1 : -1) * (0.5 + 0.4 * Math.sin(time * 0.04 + i));
            Vec3 tip = p.add(wv.scale(lean)).add(u.scale(0.5 * Math.sin(i * 2.1))).add(0, hgt, 0);
            Vec3 half = u.scale(0.55);
            Solid.slab(crystal, p.subtract(half), p.add(half), tip.add(half.scale(0.25)), tip.subtract(half.scale(0.25)), 0.1, i % 3 == 0 ? 0x8E1424 : 0x2E1A48, 0.55f * (float) up, 0.9);
        }
        if (age < Math.max(1, e.b)) {
            Vec3 head = e.pos.add(u.scale(L * smooth(age / Math.max(1, e.b))));
            glow.softFacing(new Vec3(head.x, y + 0.3, head.z), 1.6, 14, argb(0.9f, BONE), argb(0f, BLOOD));
        }
        // Dust and stone falling into it from the edges.
        for (int i = 0; i < 16 && open > 0.2; i++) {
            double s = hash(e.key + i) * L, ph = (time * 0.03 + hash(e.key * 3 + i)) % 1.0;
            Vec3 p = e.pos.add(u.scale(s)).add(new Vec3(-u.z, 0, u.x).scale((i % 2 == 0 ? 1 : -1) * 1.5 * open)).add(0, -ph * 3, 0);
            col(crystal, shade(0x6A5A48, light(p.add(0, 3, 0))), (float) (1 - ph)).cuboid(p, 0.06, 0.06, 0.06, time * 0.1 + i);
        }
    }

    /** The second tear, in the sky: whoever fell into Rend is dropped out of it. */
    static void skyRip(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        Vec3 face = glow.cam().subtract(e.pos);
        face = new Vec3(face.x, 0, face.z).lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : new Vec3(face.x, 0, face.z).normalize();
        rift(crystal, glow, Rect.of(e.pos, face, new Vec3(0.3, 1, 0), 0.9, 1.4), opening(age, e.duration, 4, 16), time, e.key, 1f, 0.1);
    }

    /** Event Horizon: a black sphere swallowing the light, a burning ring spinning round it, the ground going dark. */
    static void horizon(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double R = Math.max(2, e.power), pull = Math.max(1, e.b);
        Vec3 c = e.pos.add(0, 1, 0);
        if (age < pull) {
            double k = smooth(age / pull);
            crystal.softDisc(e.pos.add(0, 0.04, 0), UP, R * (0.6 + 0.6 * k), 40, argb(0.85f * (float) k, 0x000000), argb(0f, 0x000000));
            double hr = 0.3 + 1.1 * k;
            // The accretion disc: bands of bone and blood, fastest at the inside, tilted a little.
            Vec3 tilt = new Vec3(0.18, 1, 0.1).normalize();
            for (int i = 0; i < 9; i++) {
                double rr = hr * (1.3 + i * 0.35), sp = time * (0.25 / (1 + i * 0.4));
                col(glow, i % 3 == 0 ? BONE : hue(0.25 + i * 0.03), (0.55f - i * 0.05f) * (float) k).ring(c, tilt, rr, 0.03 + 0.02 * (9 - i) / 9.0, 64, sp, i % 2 == 1);
            }
            // Light bent round the edge of the hole.
            Vec3 face = glow.cam().subtract(c);
            face = face.lengthSqr() < 1e-6 ? UP : face.normalize();
            col(glow, BONE, 0.7f * (float) k).ring(c, face, hr * 1.08, 0.04, 64, 0, false);
            glow.softFacing(c, hr * 2.4, 20, argb(0.18f * (float) k, BLOOD), argb(0f, VOID));
            col(crystal, 0x000000, 0.99f).sphere(c, hr, 14, 20);
            // A second disc crossing the first, and a jet of pale light straight up out of the pole.
            Vec3 tilt2 = new Vec3(-0.5, 0.8, 0.35).normalize();
            for (int i = 0; i < 5; i++) col(glow, i % 2 == 0 ? BLOOD : BONE, (0.4f - i * 0.06f) * (float) k).ring(c, tilt2, hr * (1.6 + i * 0.5), 0.02, 64, -time * 0.12 / (1 + i * 0.5), true);
            // Two solid rings of the disc, and shards of the world circling in, each one stretched toward the hole.
            Solid.band(crystal, c, tilt, hr * 2.1, 0.5, 0.06, 40, time * 0.2, 0.15, 0x241A2E, 0x8E1424, 0.9f * (float) k, 0.2);
            Solid.band(crystal, c, tilt2, hr * 2.9, 0.35, 0.05, 48, -time * 0.13, 0.2, 0x1A1420, 0xC9B9A2, 0.85f * (float) k, 0.2);
            for (int i = 0; i < 14; i++) {
                double ph = (time * 0.03 + hash(e.key * 9 + i)) % 1.0, an = hash(e.key * 11 + i) * Math.PI * 2 + ph * 5, rr = hr + (R - hr) * (1 - ph) * (1 - ph);
                Vec3 p = c.add(Math.cos(an) * rr, (hash(e.key * 13 + i) - 0.5) * 3 * (1 - ph), Math.sin(an) * rr);
                Vec3 in = c.subtract(p).normalize();
                Solid.spike(crystal, p, p.add(in.scale(0.6 + 2.2 * ph)), 0.3 * (1 - ph) + 0.06, i, i % 3 == 0 ? 0x8E1424 : 0x3A2A30, (float) (k * Math.sin(Math.PI * ph)), 0.3);
            }
            Solid.band(crystal, e.pos.add(0, 0.25, 0), UP, R, 0.3, 0.5, 30, -time * 0.01, 0.35, 0x1A1420, 0x4A0C16, 0.8f * (float) k, 0.3);
            // Streaks of the world being drawn in.
            for (int i = 0; i < 40; i++) {
                double ang = hash(e.key + i) * Math.PI * 2 + time * 0.08, ph = (time * 0.05 + hash(e.key * 3 + i)) % 1.0;
                double r0 = R * (1 - ph) + hr;
                Vec3 p0 = c.add(Math.cos(ang) * r0, -0.8 * (1 - ph), Math.sin(ang) * r0), p1 = c.add(Math.cos(ang + 0.4) * (r0 * 0.7 + hr), -0.5 * (1 - ph), Math.sin(ang + 0.4) * (r0 * 0.7 + hr));
                col(glow, BONE, 0.45f * (float) (ph * k)).ribbon(p0, p1, 0.02);
            }
            return;
        }
        // The rebound.
        double t = (age - pull) / Math.max(1, e.duration - pull);
        float a = (float) (1 - t);
        glow.softFacing(c, R * (0.3 + 0.9 * t), 24, argb(0.6f * a, BONE), argb(0f, BLOOD));
        col(glow, BONE, 0.8f * a).ring(e.pos.add(0, 0.1, 0), UP, R * (0.3 + 1.4 * easeOut(t)), 0.05 * a + 0.02, 72, 0, false);
        col(crystal, 0x000000, 0.9f * a).sphere(c, 1.4 * (1 - t), 12, 16);
        col(glow, BLOOD, 0.6f * a).ring(e.pos.add(0, 0.15, 0), UP, R * (0.2 + 2.0 * easeOut(t)), 0.1 * a + 0.02, 72, 0, false);
        Solid.band(crystal, e.pos.add(0, 0.4, 0), UP, R * (0.3 + 1.5 * easeOut(t)), 0.5, 0.7 * a + 0.05, 28, t * 2, 0.3, 0x1A1420, 0x8E1424, a, 0.3);
        burst(glow, e.pos.add(0, 0.12, 0), 28, 0.5, R * (0.5 + 1.2 * easeOut(t)), BONE, 0.8f * a, e.key);
    }

    /** Infinite Regress: thin shells marking each nested world, closing in round the victim as it falls through them. */
    static void regress(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double total = Math.max(1, e.b), z = Math.min(3.2, age / total * 3), R = Math.max(1, e.power);
        float k = env(age, e.duration, 3, 6);
        for (int L = 0; L < 6; L++) {
            double sc = Math.pow(0.6, L + 1 - z);
            if (sc > 1.1 || sc < 0.04) continue;
            double rr = R * sc, yaw = (L - z) * 0.7 + time * 0.004;
            float f = (float) Math.min(1, (1.1 - sc) * 4) * k;
            for (int i = 0; i < 3; i++) {
                Vec3 n = new Vec3(Math.cos(yaw + i * 2.1), 0.6 * Math.sin(yaw * 1.3 + i), Math.sin(yaw + i * 2.1)).normalize();
                col(glow, i == 0 ? BONE : BLOOD, 0.5f * f).ring(e.pos, n, rr, 0.015 + 0.02 * sc, 48, 0, false);
            }
        }
        // Each nested world has its own frame, turning against the one outside it; lines of sight all run to one point.
        for (int L = 0; L < 6; L++) {
            double sc = Math.pow(0.6, L + 1 - z);
            if (sc > 1.1 || sc < 0.04) continue;
            float f = (float) Math.min(1, (1.1 - sc) * 4) * k;
            double turn = (L % 2 == 0 ? 1 : -1) * (time * 0.02 + z * 0.9) + L;
            cube(glow, e.pos, R * sc * 0.62, turn, turn * 0.6, L % 2 == 0 ? BONE : BLOOD, 0.7f * f, 0.02 + 0.03 * sc);
        }
        for (int i = 0; i < 16; i++) {
            double ang = i * Math.PI / 8 + time * 0.01, el = (hash(e.key + i) - 0.5) * 1.6, ph = (time * 0.04 + hash(e.key * 3 + i)) % 1.0;
            Vec3 d = new Vec3(Math.cos(ang) * Math.cos(el), Math.sin(el), Math.sin(ang) * Math.cos(el));
            col(glow, BONE, 0.4f * k * (float) ph).ribbon(e.pos.add(d.scale(R * (1 - ph))), e.pos.add(d.scale(R * (1 - ph) * 0.6)), 0.015);
        }
        crystal.softFacing(e.pos, R * 0.9, 20, argb(0f, 0x000000), argb(0.35f * k, 0x000000));
        glow.softFacing(e.pos, 0.3, 10, argb(0.6f * k, BONE), argb(0f, BLOOD));
    }

    /** Inversion: the hanging ground's ragged rim, roots and tendrils dangling from it, its shadow on the land below. */
    static void invert(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double R = Math.max(2, e.power), H = e.aux.x;
        double k = opening(age, e.duration, 10, 10);
        if (k <= 0.01) return;
        double y = e.pos.y + H + H * 0.6 * (1 - k);
        crystal.softDisc(e.pos.add(0, 0.05, 0), UP, R * 1.1, 40, argb(0.55f * (float) k, 0x000000), argb(0f, 0x000000));
        for (int i = 0; i < 40; i++) {
            double ang = i * Math.PI * 2 / 40, r0 = R * (0.92 + 0.12 * hash(e.key + i)), r1 = R * (0.92 + 0.12 * hash(e.key + i + 1));
            double ang2 = (i + 1) * Math.PI * 2 / 40;
            Vec3 p0 = new Vec3(e.pos.x + Math.cos(ang) * r0, y, e.pos.z + Math.sin(ang) * r0), p1 = new Vec3(e.pos.x + Math.cos(ang2) * r1, y, e.pos.z + Math.sin(ang2) * r1);
            col(crystal, 0x0E0A0C, (float) k).ribbon(p0, p1, 0.12);
            trip(glow, p0, p1, 0.02, 0.5f * (float) k, GOLD, 0.015);
        }
        // Taut threads of light tie the land below to the land above; rubble drifts up between them.
        col(glow, BLOOD, 0.5f * (float) k).ring(e.pos.add(0, 0.08, 0), UP, R, 0.05, 96, time * 0.015, true);
        col(glow, BONE, 0.35f * (float) k).ring(e.pos.add(0, 0.08, 0), UP, R * 0.97, 0.02, 96, 0, false);
        for (int i = 0; i < 12; i++) {
            double ang = i * Math.PI / 6 + 0.2;
            Vec3 g0 = new Vec3(e.pos.x + Math.cos(ang) * R, e.pos.y + 0.1, e.pos.z + Math.sin(ang) * R);
            trip(glow, g0, new Vec3(g0.x, y, g0.z), 0.02, 0.55f * (float) k, GOLD, 0.02);
        }
        for (int i = 0; i < 28; i++) {
            double ang = hash(e.key * 17 + i) * Math.PI * 2, rr = R * Math.sqrt(hash(e.key * 19 + i)) * 0.9, ph = (time * 0.012 + hash(e.key * 23 + i)) % 1.0;
            Vec3 q = new Vec3(e.pos.x + Math.cos(ang) * rr, e.pos.y + 0.3 + ph * (H - 1.2), e.pos.z + Math.sin(ang) * rr);
            double sz = 0.05 + 0.1 * hash(e.key * 29 + i);
            col(crystal, shade(0x6A5A48, light(q)), (float) (k * Math.sin(Math.PI * ph))).cuboid(q, sz, sz, sz, time * 0.05 + i);
        }
        shaft(glow, e.pos, H, R * 0.5, BLOOD, 0.12f * (float) k);
        // Roots and tendrils hanging down from the upside-down ground, swaying.
        for (int i = 0; i < 26; i++) {
            double ang = hash(e.key * 5 + i) * Math.PI * 2, rr = R * Math.sqrt(hash(e.key * 7 + i)) * 0.95;
            Vec3 top = new Vec3(e.pos.x + Math.cos(ang) * rr, y - 0.9, e.pos.z + Math.sin(ang) * rr);
            double len = (0.6 + 2.2 * hash(e.key * 11 + i)) * k;
            Vec3 prev = top;
            for (int s2 = 1; s2 <= 6; s2++) {
                double t = s2 / 6.0;
                Vec3 q = top.add(Math.sin(time * 0.05 + i + t * 3) * 0.2 * t, -len * t, Math.cos(time * 0.04 + i + t * 3) * 0.2 * t);
                col(crystal, i % 3 == 0 ? 0x050304 : 0x3A2A1E, (float) k).ribbon(prev, q, 0.04 * (1 - t) + 0.008);
                prev = q;
            }
        }
    }

    /** Shatter: cracks of light racing out through the ground; then, while the pieces are in the sky, the abyss under them. */
    static void shatter(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double R = Math.max(2, e.power), crack = Math.max(1, e.b), air = Math.max(1, e.c);
        Vec3 o = e.pos;
        int seed = e.a;
        if (age < crack + 2) {
            double reach = R * smooth(age / crack);
            for (int i = 0; i < 20; i++) {
                double ang = hash(seed + i) * Math.PI * 2;
                Vec3 q = o.add(0, 0.05, 0);
                for (int s2 = 1; s2 <= 6; s2++) {
                    double rr = reach * s2 / 6, aa = ang + (hash(seed * 3L + i * 7 + s2) - 0.5) * 0.6;
                    Vec3 nx = new Vec3(o.x + Math.cos(aa) * rr, 0, o.z + Math.sin(aa) * rr);
                    nx = new Vec3(nx.x, FxRenderer.ground(nx.x, o.y, nx.z) + 0.05, nx.z);
                    col(crystal, 0x050304, 0.9f).ribbon(q, nx, 0.09);
                    trip(glow, q, nx, 0.025, 0.85f, GOLD, 0.02);
                    // Side cracks splitting off, and light leaking up out of the break.
                    if (hash(seed * 11L + i * 5 + s2) > 0.5) {
                        double ba = aa + (hash(seed * 13L + i + s2) > 0.5 ? 0.9 : -0.9), bl = reach * 0.22;
                        Vec3 br = new Vec3(nx.x + Math.cos(ba) * bl, 0, nx.z + Math.sin(ba) * bl);
                        br = new Vec3(br.x, FxRenderer.ground(br.x, o.y, br.z) + 0.05, br.z);
                        col(crystal, 0x050304, 0.9f).ribbon(nx, br, 0.05);
                        trip(glow, nx, br, 0.015, 0.7f, GOLD, 0.015);
                    }
                    if (s2 % 2 == 0) Solid.spike(crystal, nx.add(0, -0.3, 0), nx.add((hash(seed * 17L + i + s2) - 0.5) * 1.2, 0.8 + 2.0 * hash(seed * 19L + i * 3 + s2) * reach / R, (hash(seed * 23L + i + s2) - 0.5) * 1.2), 0.45, i + s2, s2 % 4 == 0 ? 0x8E1424 : 0x241A2E, 0.9f, 0.5);
                    q = nx;
                }
            }
            glow.softFacing(o.add(0, 0.3, 0), 0.5 + 1.5 * reach / R, 14, argb(0.3f, BLOOD), argb(0f, VOID));
            return;
        }
        double t = (age - crack) / air;
        if (t <= 1.05) {
            // The holes the pieces left.
            float a = (float) Math.min(1, t * 6) * (float) smooth((1.05 - t) * 8);
            int n = (int) Math.ceil(R / 3);
            for (int cx = -n; cx <= n; cx++) for (int cz = -n; cz <= n; cz++) {
                double x0 = Math.floor(o.x) + cx * 3 - 1, z0 = Math.floor(o.z) + cz * 3 - 1;
                if ((cx * 3) * (cx * 3) + (cz * 3) * (cz * 3) > R * R) continue;
                double y = FxRenderer.ground(x0 + 1.5, o.y, z0 + 1.5) + 0.04;
                hole(crystal, glow, new Vec3(x0, y, z0), new Vec3(x0 + 3, y, z0), new Vec3(x0 + 3, y, z0 + 3), new Vec3(x0, y, z0 + 3), a, time, seed + cx * 31L + cz);
            }
            // Splinters of the broken air, turning as they hang: each one catches the light for a moment.
            for (int i = 0; i < 36; i++) {
                double ang = hash(seed * 31L + i) * Math.PI * 2, rr = R * Math.sqrt(hash(seed * 37L + i));
                double hgt = (1.5 + 6 * hash(seed * 41L + i)) * Math.sin(Math.PI * Math.min(1, t)), spin = time * 0.09 + i * 2.3;
                Vec3 m = new Vec3(o.x + Math.cos(ang) * rr, o.y + 0.5 + hgt, o.z + Math.sin(ang) * rr);
                double sz = 0.25 + 0.45 * hash(seed * 43L + i);
                Vec3 ax = new Vec3(Math.cos(spin), Math.sin(spin * 0.7), Math.sin(spin)).scale(sz), bx = new Vec3(-Math.sin(spin), 0.4, Math.cos(spin)).scale(sz * 0.6);
                float gl = (float) Math.pow(Math.abs(Math.sin(spin * 0.8)), 6);
                int c0 = argb((0.18f + 0.6f * gl) * a, BONE), c1 = argb(0.1f * a, 0x6E7C8C);
                crystal.gquad(m.subtract(ax), c1, m.add(bx), c0, m.add(ax), c1, m.add(ax), c1);
                if (gl > 0.5f) glow.softFacing(m, sz * 0.8, 8, argb(0.5f * gl * a, BONE), argb(0f, BLOOD));
            }
            return;
        }
        // The crash.
        double c2 = (age - crack - air) / 20;
        float a = (float) Math.max(0, 1 - c2);
        col(crystal, shade(0xBDB0A0, light(o.add(0, 1, 0))), 0.5f * a).ring(o.add(0, 0.3, 0), UP, R * (0.6 + 0.8 * easeOut(c2)), 0.6 * a + 0.05, 64, 0, false);
        crystal.softDisc(o.add(0, 0.5, 0), UP, R * 1.4 * easeOut(c2), 40, argb(0f, 0xBDB0A0), argb(0.35f * a, 0xBDB0A0));
        col(glow, BONE, 0.7f * a).ring(o.add(0, 0.12, 0), UP, R * (0.4 + 1.6 * easeOut(c2)), 0.12 * a + 0.02, 72, 0, false);
        burst(glow, o.add(0, 0.12, 0), 30, 0.5, R * (0.6 + 1.0 * easeOut(c2)), BONE, 0.8f * a, seed);
        Solid.band(crystal, o.add(0, 0.35, 0), UP, R * (0.5 + 0.9 * easeOut(c2)), 0.6, 0.6 * a + 0.05, 24, c2, 0.35, 0x3A2A30, 0x6A5A48, a, 0.1);
    }

    /** Inception: the abyss where the land has lifted away, burning seams along the hinges, and a black sun in the fold. */
    static void inception(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double R = Math.max(8, e.power), d0 = Space.HINGE, fold = Math.max(1, e.b), slam = Math.max(fold + 1, e.c);
        double k = Space.foldK(age, fold, slam);
        if (k <= 0.01) return;
        Vec3 o = e.pos;
        Vec3 u = e.a == 1 ? new Vec3(0, 0, 1) : new Vec3(1, 0, 0), w = new Vec3(-u.z, 0, u.x);
        double ahead = Math.signum(e.aux.x) == 0 ? 1 : Math.signum(e.aux.x);
        float a = (float) Math.min(1, k * 2);
        double y = o.y + 0.04;
        for (int sg = -1; sg <= 1; sg += 2) {
            // The ground that lifted, gone to black.
            int strips = 10;
            for (int i = 0; i < strips; i++) {
                double l0 = -R + 2 * R * i / strips, l1 = -R + 2 * R * (i + 1) / strips;
                double lim = Math.sqrt(Math.max(0, R * R - Math.max(l0 * l0, l1 * l1)));
                if (lim <= d0) continue;
                Vec3 p0 = o.add(u.scale(sg * d0)).add(w.scale(l0)), p1 = o.add(u.scale(sg * d0)).add(w.scale(l1));
                Vec3 p2 = o.add(u.scale(sg * lim)).add(w.scale(l1)), p3 = o.add(u.scale(sg * lim)).add(w.scale(l0));
                hole(crystal, glow, new Vec3(p0.x, y, p0.z), new Vec3(p1.x, y, p1.z), new Vec3(p2.x, y, p2.z), new Vec3(p3.x, y, p3.z), a, time, e.key + i * 7 + sg);
            }
            // The hinge: a burning seam where the world bends.
            Vec3 h0 = o.add(u.scale(sg * d0)).add(w.scale(-R)), h1 = o.add(u.scale(sg * d0)).add(w.scale(R));
            h0 = new Vec3(h0.x, y + 0.05, h0.z); h1 = new Vec3(h1.x, y + 0.05, h1.z);
            rift(crystal, glow, Rect.of(h0.add(h1).scale(0.5), UP, w, 0.8, R), Math.min(1, k), time, e.key + sg, 1f, 0.2);
        }
        // Round the esper, at the middle of it all: a great gimbal of three machined rings, turning on three axes.
        float ka = (float) Math.min(1, k);
        Vec3 hub = o.add(0, 3.2, 0);
        double conv = age >= slam ? 1 - 0.8 * smooth((age - slam) / 14.0) : 1;
        Vec3 g1 = new Vec3(Math.sin(time * 0.02), 0.5, Math.cos(time * 0.02)), g2 = new Vec3(Math.cos(time * 0.013), -0.7, Math.sin(time * 0.013)), g3 = new Vec3(0.2 * Math.sin(time * 0.01), 1, 0.2 * Math.cos(time * 0.01));
        Solid.band(crystal, hub, g1, 3.4 * ka * conv, 0.3, 0.16, 28, time * 0.03, 0.2, 0x241A2E, 0xC9B9A2, 0.95f * ka, 0);
        Solid.band(crystal, hub, g2, 4.6 * ka * conv, 0.26, 0.14, 36, -time * 0.02, 0.2, 0x241A2E, 0x8E1424, 0.95f * ka, 0);
        Solid.band(crystal, hub, g3, 5.8 * ka * conv, 0.22, 0.12, 44, time * 0.012, 0.2, 0x1A1420, 0x2E1A48, 0.95f * ka, 0);
        // The measured ground: three rings of dark glass blocks laid out from him to the edge, each turning its own way,
        // spreading outward as the fold begins and drawing back in as it shuts.
        double spread = easeOut(Math.min(1, age / Math.max(1, fold))) * conv;
        for (int i = 0; i < 3; i++) {
            double rr = R * (0.36 + 0.32 * i) * spread;
            Solid.band(crystal, o.add(0, 0.25, 0), UP, rr, 0.5 - 0.08 * i, 0.4, 24 + 16 * i, time * 0.008 * (i % 2 == 0 ? 1 : -1), 0.3, 0x1A1420, i == 1 ? 0x4A0C16 : 0x2E1A48, 0.85f * ka, 0.3);
        }
        // Crystals standing in the air all round the battlefield, each turning on its own.
        for (int i = 0; i < 16; i++) {
            double an = i * Math.PI / 8 + time * 0.004, rr = R * (0.55 + 0.3 * hash(e.key * 3 + i)) * conv, hy = 5 + 9 * hash(e.key * 5 + i);
            Solid.octa(crystal, o.add(Math.cos(an) * rr, hy * ka + 0.6 * Math.sin(time * 0.04 + i), Math.sin(an) * rr), 0.5 + 0.5 * hash(e.key * 7 + i), 2.2, time * 0.03 + i, 0.3 * Math.sin(time * 0.02 + i), i % 4 == 0 ? 0x8E1424 : i % 4 == 2 ? 0xC9B9A2 : 0x241A2E, 0.9f * ka, 0.5);
        }
        // The slam: the rings rush in, and shards of the broken fold are thrown out along the ground.
        if (age >= slam) {
            double st = Math.min(1, (age - slam) / 40);
            float sa = (float) (1 - st);
            Solid.band(crystal, o.add(0, 0.5, 0), UP, R * (0.1 + 1.4 * easeOut(st)), 0.8, 1.0 * sa + 0.05, 40, st * 2, 0.3, 0x1A1420, 0x8E1424, sa, 0.3);
            burst(crystal, o.add(0, 0.15, 0), 40, 1, R * (0.4 + 1.0 * easeOut(st)), BONE, 0.9f * sa, e.key);
            glow.softFacing(hub, 6 + 14 * st, 24, argb(0.7f * sa, BONE), argb(0f, BLOOD));
        }
        // Low over the wall at your back, under the hanging land, a black sun.
        if (k > 0.6 && k <= 1.2) eclipse(crystal, glow, o.add(u.scale(-ahead * (R * 0.55))).add(0, 9, 0), 2.8, time, (float) Math.min(1, (k - 0.6) * 3));
    }

    /** An echo of the esper's hit, coming down out of the folded sky. */
    static void echo(ClientFx.Effect e, Geo crystal, Geo glow, double age, double time) {
        double k = age / Math.max(1, e.duration);
        float a = (float) (1 - k);
        Vec3 tip = e.pos.add(e.aux.subtract(e.pos).scale(Math.min(1, k * 3)));
        col(crystal, 0x050304, 0.8f * a).ribbon(e.pos, tip, 0.12 * a + 0.02);
        trip(glow, e.pos, tip, 0.03, 0.9f * a, GOLD, 0.02);
        if (k > 0.3) glow.softFacing(e.aux, 0.8 * a, 12, argb(0.6f * a, BONE), argb(0f, BLOOD));
        Vec3 face = glow.cam().subtract(e.pos);
        face = face.lengthSqr() < 1e-6 ? UP : face.normalize();
        rift(crystal, glow, Rect.of(e.pos, face, e.aux.subtract(e.pos), 0.3, 0.7), Math.sin(Math.PI * k), time, e.key, a, 0.2);
    }
}
