package dev.toaru.dimmanip.client;

import static dev.toaru.dimmanip.client.Fxu.*;

import net.minecraft.world.phys.Vec3;

/**
 * The inside of Pocket Universe: an endless, impossible tunnel. Every surface is quilted with puffed-out diamond tiles
 * whose colours drift through lime, gold, orange, magenta, pink and purple; arches and pillars repeat forever both ways
 * toward a burning core; ornamented eggs and little cubes hang in the air; the whole tunnel slowly twists and breathes.
 * Everything repeats exactly every tunnel-length, so the server can carry you from one end to the other unseen. The
 * walls you actually touch are invisible barriers just inside what is drawn.
 */
final class PsyTunnel {
    private PsyTunnel() { }

    static final int[] PALETTE = {0xB4E02A, 0xD8A020, 0xE8661E, 0xE03CC0, 0xFF6AA8, 0x6A2AA0};

    static int pal(double t) {
        t = (t - Math.floor(t)) * PALETTE.length;
        int i = (int) Math.floor(t) % PALETTE.length;
        return mix(PALETTE[i], PALETTE[(i + 1) % PALETTE.length], t - Math.floor(t));
    }

    /** One tunnel: where its room floor is, its period, and the moment. */
    record T(Vec3 o, double period, double time, Vec3 cam) {
        double yc() { return o.y + 2.2; }

        /** A point on the tunnel wall at length x (relative to o) and angle th round it. */
        Vec3 wall(double x, double th, double scale) {
            double w = 2 * Math.PI / period;
            double twist = 0.55 * Math.sin(w * x + time * 0.008);
            double r = (1 + 0.07 * Math.sin(3 * th + 2 * w * x + time * 0.03) + 0.04 * Math.sin(time * 0.05 + w * x)) * scale;
            double a = th + twist;
            // Wide enough that nobody walks through what they see; the bottom is pressed flat into a floor at your feet.
            return new Vec3(o.x + x, Math.max(o.y - 0.17, yc() + 4.6 * r * Math.sin(a)), o.z + 6.6 * r * Math.cos(a));
        }

        Vec3 axis(double x) { return new Vec3(o.x + x, yc(), o.z); }

        /** Deeper down the tunnel everything glows toward the burning core. */
        int fog(int rgb, double x) {
            double dist = Math.abs(o.x + x - cam.x);
            double f = smooth((dist - 12) / 26);
            return mix(rgb, 0xFF5A1E, 0.75 * f);
        }
    }

    /** A puffed tile: four corners, its middle pushed toward the viewer, each of its four faces lit on its own. */
    static void pillow(Geo g, T t, Vec3 a, Vec3 b, Vec3 c, Vec3 d, Vec3 toward, double puff, int rgb, int star) {
        Vec3 mid = a.add(b).add(c).add(d).scale(0.25);
        Vec3 in = toward.subtract(mid);
        in = in.lengthSqr() < 1e-6 ? new Vec3(0, 1, 0) : in.normalize();
        Vec3 m = mid.add(in.scale(puff));
        Vec3[] q = {a, b, c, d};
        Vec3 view = t.cam.subtract(mid).normalize();
        for (int k = 0; k < 4; k++) {
            Vec3 p0 = q[k], p1 = q[(k + 1) % 4];
            Vec3 n = p1.subtract(p0).cross(m.subtract(p0));
            n = n.lengthSqr() < 1e-9 ? in : n.normalize();
            if (n.dot(in) < 0) n = n.scale(-1);
            float lit = (float) (0.35 + 0.65 * Math.max(0, n.dot(view)));
            int edge = argb(1f, shade(rgb, lit * 0.8f)), top = argb(1f, shade(star, Math.min(1f, lit * 1.15f)));
            g.gquad(p0, edge, p1, edge, m, top, m, top);
        }
    }

    static void draw(ClientFx.Effect e, Geo solid, Geo glow, double age, double time) {
        double period = Math.max(10, e.power * 2);
        Vec3 cam = solid.cam();
        T t = new T(e.pos, period, time, cam);
        float k = env(age, e.duration, 6, 12);
        if (k <= 0.01f) return;
        Geo.nearFade = 0;
        int q = dev.toaru.dimmanip.ClientCfg.quality();
        double dx = q >= 2 ? 0.6 : q == 1 ? 0.75 : 1.0;
        int nth = q >= 2 ? 28 : q == 1 ? 22 : 16;
        double cx = cam.x - e.pos.x, reach = q >= 2 ? 38 : 28;
        int i0 = (int) Math.floor((cx - reach) / dx), i1 = (int) Math.ceil((cx + reach) / dx);
        double w = 2 * Math.PI / period;
        // The quilted walls.
        for (int i = i0; i < i1; i++) {
            double x0 = i * dx, x1 = x0 + dx;
            for (int j = 0; j < nth; j++) {
                double th0 = j * Math.PI * 2 / nth, th1 = (j + 1) * Math.PI * 2 / nth;
                Vec3 a = t.wall(x0, th0, 1), b = t.wall(x1, th0, 1), c = t.wall(x1, th1, 1), d = t.wall(x0, th1, 1);
                int d1 = Math.floorMod(i + j, 4), d2 = Math.floorMod(i - j, 4);
                double ph = 2 * x0 / period + (double) j / nth + time * 0.004 + 0.15 * Math.sin(w * x0 * 3 + j);
                int base = pal(ph), rgb, star;
                if (d1 == 0 || d2 == 0) { rgb = shade(pal(ph + 0.5), 0.45f); star = shade(pal(ph + 0.45), 0.7f); }
                else if (d1 == 2 && d2 == 2) { rgb = base; star = mix(base, 0xFFFFFF, 0.55); }
                else { rgb = base; star = mix(base, pal(ph + 0.2), 0.5); }
                // A wave of light runs down the tunnel, and the whole quilt ripples as it passes.
                double wave = Math.pow(0.5 + 0.5 * Math.sin(w * x0 * 2 - time * 0.09), 10);
                rgb = mix(rgb, 0xFFF2C0, 0.45 * wave); star = mix(star, 0xFFFFFF, 0.7 * wave);
                pillow(solid, t, a, b, c, d, t.axis((x0 + x1) / 2), 0.16 + 0.22 * wave, t.fog(rgb, x0), t.fog(star, x0));
            }
        }
        // Arches, every fifth of the tunnel: a raised band all the way round, and a pillar either side.
        int arches = 5;
        double gap = period / arches;
        int a0 = (int) Math.floor((cx - reach) / gap), a1 = (int) Math.ceil((cx + reach) / gap);
        for (int n = a0; n <= a1; n++) {
            double xa = n * gap;
            int segs = nth;
            for (int j = 0; j < segs; j++) {
                double th0 = j * Math.PI * 2 / segs, th1 = (j + 1) * Math.PI * 2 / segs;
                int rib = pal(2 * xa / period + 0.35 + time * 0.003), gold = pal(2 * xa / period + 0.15 + j * 0.02);
                for (int side = -1; side <= 1; side += 2) {
                    Vec3 s0 = t.wall(xa + side * 0.45, th0, 1), s1 = t.wall(xa + side * 0.45, th1, 1);
                    Vec3 r0 = t.wall(xa, th0, 0.86), r1 = t.wall(xa, th1, 0.86);
                    pillow(solid, t, s0, r0, r1, s1, t.axis(xa), 0.05, t.fog(j % 2 == 0 ? gold : rib, xa), t.fog(mix(gold, 0xFFFFFF, 0.4), xa));
                }
                // A thread of light along the lip of every arch.
                float pulse = (float) (0.45 + 0.35 * Math.sin(time * 0.07 + n * 1.3));
                col(glow, pal(2 * xa / period + 0.6 + time * 0.005), pulse * k).ribbon(t.wall(xa, th0, 0.85), t.wall(xa, th1, 0.85), 0.05);
            }
            for (int side = -1; side <= 1; side += 2) {
                double z = side * 5.0;
                for (int row = 0; row < 7; row++) for (int sgm = 0; sgm < 8; sgm++) {
                    double y0 = e.pos.y - 0.5 + row * 0.85, y1 = y0 + 0.85;
                    double b0 = sgm * Math.PI * 2 / 8, b1 = (sgm + 1) * Math.PI * 2 / 8, pr = 0.42 + 0.06 * Math.sin(row * 0.9 + time * 0.03);
                    Vec3 c0 = new Vec3(e.pos.x + xa + Math.cos(b0) * pr, y0, e.pos.z + z + Math.sin(b0) * pr);
                    Vec3 c1 = new Vec3(e.pos.x + xa + Math.cos(b1) * pr, y0, e.pos.z + z + Math.sin(b1) * pr);
                    Vec3 c2 = new Vec3(e.pos.x + xa + Math.cos(b1) * pr, y1, e.pos.z + z + Math.sin(b1) * pr);
                    Vec3 c3 = new Vec3(e.pos.x + xa + Math.cos(b0) * pr, y1, e.pos.z + z + Math.sin(b0) * pr);
                    int col = (row + sgm) % 2 == 0 ? pal(0.5 + row * 0.05 + time * 0.003) : pal(0.62 + time * 0.003);
                    Vec3 out = new Vec3(e.pos.x + xa + Math.cos((b0 + b1) / 2) * 3, (y0 + y1) / 2, e.pos.z + z + Math.sin((b0 + b1) / 2) * 3);
                    pillow(solid, t, c0, c1, c2, c3, out, 0.08, t.fog(col, xa), t.fog(mix(col, 0xFFFFFF, 0.45), xa));
                }
            }
        }
        // Eggs and cubes hanging in the air between the arches.
        for (int n = a0; n <= a1; n++) {
            double xe = n * gap + gap / 2;
            int sd = Math.floorMod(n, 2) == 0 ? 1 : -1;
            Vec3 c = new Vec3(e.pos.x + xe, t.yc() + 1.5 + 0.5 * Math.sin(time * 0.02 + n), e.pos.z + sd * 2.3);
            egg(solid, t, c, 0.55, 0.85, time * 0.02 * sd + n, xe);
            glow.softFacing(c, 1.5, 14, argb(0.3f * k, pal(0.15 + time * 0.004 + n * 0.2)), argb(0f, 0xFF3010));
            // A second, smaller egg low on the other side, turning the other way.
            Vec3 c2 = new Vec3(e.pos.x + xe - gap * 0.25, e.pos.y + 0.9 + 0.25 * Math.sin(time * 0.03 + n * 2), e.pos.z - sd * 4.2);
            egg(solid, t, c2, 0.32, 0.5, -time * 0.03 * sd + n, xe);
            for (int m = 0; m < 3; m++) {
                double ang = time * 0.04 + m * 2.1 + n;
                Vec3 p = c.add(Math.cos(ang) * 1.1, Math.sin(ang * 1.3) * 0.6, Math.sin(ang) * 1.1);
                int col = pal(0.1 + m * 0.3 + time * 0.003);
                col(solid, t.fog(col, xe), 1f).cuboid(p, 0.16, 0.16, 0.16, ang);
            }
        }
        // The burning core at both ends of sight.
        for (int sd = -1; sd <= 1; sd += 2) {
            Vec3 core = t.axis(cx + sd * (reach - 2));
            glow.softFacing(core, 4.5, 24, argb(0.75f * k, 0xFFB050), argb(0f, 0xFF3010));
            glow.softFacing(core, 1.4, 16, argb(0.9f * k, 0xFFF0C0), argb(0f, 0xFF8030));
        }
    }

    /** An ornamented egg: a quilted ellipsoid, slowly turning. */
    static void egg(Geo g, T t, Vec3 c, double rx, double ry, double spin, double x) {
        int lat = 7, lon = 12;
        for (int i = 0; i < lat; i++) for (int j = 0; j < lon; j++) {
            double p0 = -Math.PI / 2 + Math.PI * i / lat, p1 = -Math.PI / 2 + Math.PI * (i + 1) / lat;
            double l0 = spin + Math.PI * 2 * j / lon, l1 = spin + Math.PI * 2 * (j + 1) / lon;
            Vec3 a = c.add(Math.cos(p0) * Math.cos(l0) * rx, Math.sin(p0) * ry, Math.cos(p0) * Math.sin(l0) * rx);
            Vec3 b = c.add(Math.cos(p0) * Math.cos(l1) * rx, Math.sin(p0) * ry, Math.cos(p0) * Math.sin(l1) * rx);
            Vec3 d = c.add(Math.cos(p1) * Math.cos(l0) * rx, Math.sin(p1) * ry, Math.cos(p1) * Math.sin(l0) * rx);
            Vec3 e = c.add(Math.cos(p1) * Math.cos(l1) * rx, Math.sin(p1) * ry, Math.cos(p1) * Math.sin(l1) * rx);
            Vec3 mid = a.add(b).add(d).add(e).scale(0.25);
            Vec3 out = mid.add(mid.subtract(c).normalize().scale(2));
            int col = (i + j) % 2 == 0 ? pal(0.15 + 0.02 * i) : pal(0.62);
            pillow(g, t, a, b, e, d, out, 0.05, t.fog(col, x), t.fog(mix(col, 0xFFFFFF, 0.5), x));
        }
    }
}
