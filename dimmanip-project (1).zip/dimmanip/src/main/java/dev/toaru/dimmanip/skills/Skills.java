package dev.toaru.dimmanip.skills;

import io.github.pinchan4273.reacademycraft.api.mc.SkillBehavior;
import javax.annotation.Nullable;

/** Which code runs each move (by its skill name). */
public final class Skills {
    private Skills() { }

    public static @Nullable SkillBehavior behavior(String name) {
        return switch (name) {
            case "atlas_fold" -> new Kit.AtlasFold();
            case "severance" -> new Kit.Severance();
            case "tesseract" -> new Kit.Tesseract();
            case "infinite_regress" -> new Kit.InfiniteRegress();
            case "gravity_well" -> new Kit.GravityWell();
            case "kaleidoscope" -> new Kit.Kaleidoscope();
            case "pocket_universe" -> new Pocket.PocketUniverse();
            case "inception" -> new Kit.Inception();
            default -> null;
        };
    }
}
