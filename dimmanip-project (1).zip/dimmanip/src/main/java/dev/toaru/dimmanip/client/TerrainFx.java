package dev.toaru.dimmanip.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.toaru.dimmanip.Space;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * The real world, bent. Each move that reshapes the land takes a picture of the real blocks round it (once, when it
 * starts) and draws those blocks - with their own textures and lighting - folded, torn apart, drained into a point,
 * nested inside themselves, hung upside down overhead, flung into the sky or folded over the whole battlefield. The real
 * blocks are never touched; the overlays in FxDim cover the places the land has "lifted away" from.
 */
final class TerrainFx {
    private TerrainFx() { }

    static final double HINGE = dev.toaru.dimmanip.Space.HINGE;

    record Copy(BlockPos pos, BlockState state, int light, Vec3 c, int tag) { }

    private static final Map<Long, List<Copy>> TAKEN = new HashMap<>();

    static int cap() { int q = dev.toaru.dimmanip.ClientCfg.quality(); return q >= 2 ? 3200 : q == 1 ? 1700 : 800; }

    /** The top {@code layers} solid blocks of the column at x, z, looking near height y. */
    static void column(ClientLevel level, int x, int z, int y, int layers, List<Copy> out, int tag) {
        int found = 0;
        for (int dy = 6; dy >= -8 && found < layers; dy--) {
            BlockPos p = new BlockPos(x, y + dy, z);
            BlockState s = level.getBlockState(p);
            if (s.isAir() || s.getRenderShape() != RenderShape.MODEL) { if (found > 0) break; continue; }
            out.add(new Copy(p, s, LevelRenderer.getLightColor(level, p.above()), Vec3.atCenterOf(p), tag));
            found++;
        }
    }

    static List<Copy> thin(List<Copy> all) {
        int cap = cap();
        if (all.size() <= cap) return all;
        List<Copy> out = new ArrayList<>(cap);
        double step = all.size() / (double) cap;
        for (double i = 0; i < all.size(); i += step) out.add(all.get((int) i));
        return out;
    }

    static List<Copy> take(ClientLevel level, ClientFx.Effect e) {
        List<Copy> out = new ArrayList<>();
        int layers = dev.toaru.dimmanip.ClientCfg.quality() >= 1 ? 2 : 1;
        BlockPos c = BlockPos.containing(e.pos.x, e.pos.y - 0.5, e.pos.z);
        switch (e.type) {
            case ATLAS, REND -> {
                Vec3 d = e.aux.subtract(e.pos);
                Vec3 u = new Vec3(d.x, 0, d.z).normalize(), w = new Vec3(-u.z, 0, u.x);
                double L = new Vec3(d.x, 0, d.z).length(), half = e.type == dev.toaru.dimmanip.net.FxType.ATLAS ? 2.5 : 5;
                java.util.Set<Long> seen = new java.util.HashSet<>();
                for (double s = -0.5; s <= L + 0.5; s += 0.5) for (double l = -half; l <= half; l += 0.5) {
                    Vec3 p = e.pos.add(u.scale(s)).add(w.scale(l));
                    int x = (int) Math.floor(p.x), z = (int) Math.floor(p.z);
                    if (!seen.add(((long) x << 32) ^ (z & 0xffffffffL))) continue;
                    double ls = (Vec3.atCenterOf(new BlockPos(x, 0, z)).subtract(e.pos)).dot(w);
                    column(level, x, z, (int) Math.floor(p.y), layers, out, ls >= 0 ? 1 : -1);
                }
            }
            case HORIZON, INVERT, SHATTER, GRAVITY, KALEIDO -> {
                int R = (int) Math.ceil(e.power);
                for (int x = -R; x <= R; x++) for (int z = -R; z <= R; z++) {
                    if (x * x + z * z > e.power * e.power) continue;
                    column(level, c.getX() + x, c.getZ() + z, c.getY(), layers, out, 0);
                }
            }
            case TESS -> {
                // The floor under the cube (it is drawn again on every wall and on the ceiling).
                int R = (int) Math.floor(e.power);
                for (int x = -R; x <= R; x++) for (int z = -R; z <= R; z++) column(level, c.getX() + x, c.getZ() + z, c.getY(), 1, out, 0);
            }
            case POCKET -> {
                // The piece of the world that is cut out.
                for (int x = -5; x <= 5; x++) for (int z = -5; z <= 5; z++) {
                    if (x * x + z * z > 27) continue;
                    column(level, c.getX() + x, c.getZ() + z, c.getY() - 1, 2, out, 0);
                }
            }
            case PERSPECTIVE -> {
                // What is round the one whose sight is bent: seen twice, out of place.
                if (e.power <= 0.05f) break;
                for (int x = -5; x <= 5; x++) for (int y = -3; y <= 4; y++) for (int z = -5; z <= 5; z++) {
                    if (x * x + y * y + z * z > 27) continue;
                    BlockPos p = BlockPos.containing(e.pos.x + x, e.pos.y + y, e.pos.z + z);
                    BlockState st = level.getBlockState(p);
                    if (st.isAir() || st.getRenderShape() != RenderShape.MODEL) continue;
                    // only blocks you could actually see a face of
                    if (!level.getBlockState(p.above()).isAir() && !level.getBlockState(p.north()).isAir() && !level.getBlockState(p.south()).isAir()
                            && !level.getBlockState(p.east()).isAir() && !level.getBlockState(p.west()).isAir()) continue;
                    out.add(new Copy(p, st, LevelRenderer.getLightColor(level, p.above()), Vec3.atCenterOf(p), 0));
                }
            }
            case REGRESS -> {
                int R = (int) Math.ceil(e.power);
                for (int x = -R; x <= R; x++) for (int y = -R; y <= R; y++) for (int z = -R; z <= R; z++) {
                    if (x * x + y * y + z * z > e.power * e.power) continue;
                    BlockPos p = BlockPos.containing(e.pos.x + x, e.pos.y + y, e.pos.z + z);
                    BlockState s = level.getBlockState(p);
                    if (s.isAir() || s.getRenderShape() != RenderShape.MODEL) continue;
                    out.add(new Copy(p, s, LevelRenderer.getLightColor(level, p.above()), Vec3.atCenterOf(p), 0));
                }
            }
            case INCEPTION -> {
                int R = (int) Math.ceil(e.power);
                boolean alongZ = e.a == 1;
                for (int x = -R; x <= R; x++) for (int z = -R; z <= R; z++) {
                    // (the land ahead swings overhead; the land behind becomes a wall)
                    if (x * x + z * z > e.power * e.power) continue;
                    double s = alongZ ? z : x;
                    if (Math.abs(s) < HINGE) continue;
                    column(level, c.getX() + x, c.getZ() + z, c.getY(), 1, out, s > 0 ? 1 : -1);
                }
                // Round the edge: pieces of the land outside it, which come loose and hang turning in the air.
                for (int x = -R - 6; x <= R + 6; x++) for (int z = -R - 6; z <= R + 6; z++) {
                    double d2 = x * x + z * z;
                    if (d2 <= (e.power + 1) * (e.power + 1) || d2 > (e.power + 6) * (e.power + 6)) continue;
                    if (Space.hash(Math.floorDiv(x, 3) * 7919L + Math.floorDiv(z, 3) * 104729L + 5) > 0.3) continue;
                    column(level, c.getX() + x, c.getZ() + z, c.getY(), 2, out, 2);
                }
            }
            default -> { }
        }
        return thin(out);
    }

    // ------------------------------------------------------------------ how far each move has bent the land
    static double foldK(double age, double fold, double slam) { return dev.toaru.dimmanip.Space.foldK(age, fold, slam); }

    /** Places one block copy: centre, turns (radians about Y, then X, then Z) and scale. */
    static void put(PoseStack s, Vec3 cam, Vec3 at, double yaw, double pitch, double roll, double sx, double sy, double sz) {
        s.translate(at.x - cam.x, at.y - cam.y, at.z - cam.z);
        if (yaw != 0) s.mulPose(Axis.YP.rotation((float) yaw));
        if (pitch != 0) s.mulPose(Axis.XP.rotation((float) pitch));
        if (roll != 0) s.mulPose(Axis.ZP.rotation((float) roll));
        if (sx != 1 || sy != 1 || sz != 1) s.scale((float) sx, (float) sy, (float) sz);
        s.translate(-0.5, -0.5, -0.5);
    }

    static Vec3 rotY(Vec3 v, double a) {
        double cs = Math.cos(a), sn = Math.sin(a);
        return new Vec3(v.x * cs - v.z * sn, v.y, v.x * sn + v.z * cs);
    }

    static void draw(PoseStack stack, Vec3 cam, long now, float pt) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        TAKEN.keySet().removeIf(k -> !ClientFx.ACTIVE.containsKey(k));
        BlockRenderDispatcher blocks = mc.getBlockRenderer();
        MultiBufferSource.BufferSource src = mc.renderBuffers().bufferSource();
        boolean any = false;
        double time = now + pt;
        for (ClientFx.Effect e : ClientFx.ACTIVE.values()) {
            if (!bends(e.type)) continue;
            if (e.pos.distanceToSqr(cam) > 200 * 200) continue;
            double age = e.age(now, pt);
            if (age < 0 || age > e.duration) continue;
            List<Copy> copies = TAKEN.computeIfAbsent(e.key, key -> take(level, e));
            int layers = switch (e.type) { case REGRESS -> 6; case TESS -> 5; case PERSPECTIVE -> 2; default -> 1; };
            for (int layer = 0; layer < layers; layer++) for (Copy cp : copies) {
                stack.pushPose();
                boolean show;
                try {
                    show = pose(e, cp, age, time, stack, cam, layer);
                } catch (RuntimeException ex) {
                    show = false;
                }
                if (show) { blocks.renderSingleBlock(cp.state(), stack, src, cp.light(), OverlayTexture.NO_OVERLAY); any = true; }
                stack.popPose();
            }
        }
        // Kaleidoscope: the esper again in each of the other five wedges (not in his own eyes - he knows which one he is).
        for (ClientFx.Effect e : ClientFx.ACTIVE.values()) {
            if (e.type != dev.toaru.dimmanip.net.FxType.KALEIDO || Fxu.own(e.a)) continue;
            double age = e.age(now, pt);
            if (age < 4 || age > e.duration - 3 || e.pos.distanceToSqr(cam) > 120 * 120) continue;
            net.minecraft.world.entity.Entity who = Fxu.entity(e.a);
            if (who == null || !who.isAlive()) continue;
            Vec3 at = who.getPosition(pt), rel = at.subtract(e.pos);
            if (rel.x * rel.x + rel.z * rel.z > e.power * e.power) continue;
            float yaw = who.yRotO + (who.getYRot() - who.yRotO) * pt;
            try {
                int light = mc.getEntityRenderDispatcher().getPackedLightCoords(who, pt);
                for (int i = 1; i < 6; i++) {
                    stack.pushPose();
                    stack.translate(e.pos.x - cam.x, e.pos.y - cam.y, e.pos.z - cam.z);
                    stack.mulPose(Axis.YP.rotation((float) (i * Math.PI / 3)));
                    try {
                        mc.getEntityRenderDispatcher().render(who, rel.x, rel.y, rel.z, yaw, pt, stack, src, light);
                    } finally {
                        stack.popPose();
                    }
                    any = true;
                }
            } catch (RuntimeException ex) {
                // a copy that can't be drawn is simply not there
            }
        }
        if (any) src.endBatch();
    }

    static boolean bends(dev.toaru.dimmanip.net.FxType t) {
        return switch (t) {
            case ATLAS, REND, HORIZON, REGRESS, INVERT, SHATTER, INCEPTION, GRAVITY, KALEIDO, TESS, POCKET, PERSPECTIVE -> true;
            default -> false;
        };
    }

    /** Sets where and how one copied block is drawn now; false = not drawn. */
    static boolean pose(ClientFx.Effect e, Copy cp, double age, double time, PoseStack s, Vec3 cam, int layer) {
        Vec3 c = cp.c();
        switch (e.type) {
            case ATLAS -> {
                // The strip between him and where he's going folds up like a paper map, then springs flat.
                double fold = Math.max(1, e.b);
                double k = age < fold ? Fxu.smooth(age / fold) : 1 - Fxu.smooth((age - fold) / 12);
                if (k < 0.01) return false;
                Vec3 d = e.aux.subtract(e.pos);
                Vec3 u = new Vec3(d.x, 0, d.z).normalize(), w = new Vec3(-u.z, 0, u.x);
                double L = Math.max(1, new Vec3(d.x, 0, d.z).length());
                Vec3 rel = c.subtract(e.pos);
                double sAl = rel.dot(u), l = rel.dot(w);
                double n = Math.max(2, Math.round(L / 4)), A = (0.8 + 0.05 * L) * k;
                double ph = Math.PI * n * sAl / L;
                double s2 = sAl * (1 - 0.85 * k), dy = A * Math.sin(ph);
                double slope = Math.atan(A * Math.cos(ph) * Math.PI * n / L / Math.max(0.15, 1 - 0.85 * k));
                Vec3 at = e.pos.add(u.scale(s2)).add(w.scale(l)).add(0, rel.y + dy, 0);
                double yawU = Math.atan2(u.x, u.z);
                put(s, cam, at, yawU, -slope, 0, 1, 1, 1);
                s.translate(0.5, 0.5, 0.5);
                s.mulPose(Axis.YP.rotation((float) -yawU));
                s.translate(-0.5, -0.5, -0.5);
                return true;
            }
            case REND -> {
                // Both halves slide away from the line, tipping toward the gap.
                double k = FxDim.opening(age, e.duration, Math.max(1, e.b), 12);
                if (k < 0.01) return false;
                Vec3 d = e.aux.subtract(e.pos);
                Vec3 u = new Vec3(d.x, 0, d.z).normalize(), w = new Vec3(-u.z, 0, u.x);
                Vec3 rel = c.subtract(e.pos);
                double l = rel.dot(w), side = cp.tag();
                double near = 1 - Math.min(1, Math.abs(l) / 5);
                Vec3 at = c.add(w.scale(side * 1.8 * k)).add(0, -0.4 * k * near - 0.08 * Math.sin(time * 0.3 + l) * k * near, 0);
                double yawU = Math.atan2(u.x, u.z);
                put(s, cam, at, yawU, 0, -side * 0.22 * k * near, 1, 1, 1);
                s.translate(0.5, 0.5, 0.5);
                s.mulPose(Axis.YP.rotation((float) -yawU));
                s.translate(-0.5, -0.5, -0.5);
                return true;
            }
            case HORIZON -> {
                // Drawn in round and round, stretched thin, sinking - then thrown back out.
                double R = Math.max(2, e.power), pull = Math.max(1, e.b);
                Vec3 rel = c.subtract(e.pos);
                double r = Math.sqrt(rel.x * rel.x + rel.z * rel.z), f = Math.max(0, 1 - r / R);
                double k, out = 0;
                if (age < pull) k = Fxu.smooth(age / pull);
                else { double u2 = (age - pull) / Math.max(1, e.duration - pull); k = 1 - Fxu.easeOut(Math.min(1, u2 * 2)); out = Math.sin(Math.PI * Math.min(1, u2)) * (1 - 0.5 * f); }
                double ang = k * (2.6 * f + 0.4), rr = r * (1 - 0.8 * k * Math.sqrt(f)) * (1 + 0.6 * out);
                double base = Math.atan2(rel.z, rel.x) + ang;
                Vec3 at = e.pos.add(Math.cos(base) * rr, rel.y - k * f * 2.5 + out * 1.5 * f, Math.sin(base) * rr);
                double stretch = 1 + 2.2 * k * f;
                put(s, cam, at, -base, 0, 0, stretch, 1 - 0.45 * k * f, 1 - 0.45 * k * f);
                return true;
            }
            case REGRESS -> {
                // The same world again and again, each one smaller and turned, falling past the victim.
                double total = Math.max(1, e.b), z = Math.min(3.2, age / total * 3);
                double sc = Math.pow(0.6, layer + 1 - z);
                if (sc > 1.0 || sc < 0.04) return false;
                double yaw = (layer - z) * 0.7 + time * 0.004;
                Vec3 at = e.pos.add(rotY(c.subtract(e.pos), yaw).scale(sc));
                put(s, cam, at, -yaw, 0, 0, sc, sc, sc);
                return true;
            }
            case GRAVITY -> {
                // The ground comes up in plates four blocks across, and every plate tips so its surface is square to
                // the new "down" - turning as the esper turns.
                float k = Fxu.env(age, e.duration, 8, 8);
                if (k < 0.01f) return false;
                int ox = (int) Math.floor(e.pos.x), oz = (int) Math.floor(e.pos.z);
                int px = Math.floorDiv(cp.pos().getX() - ox, 4), pz = Math.floorDiv(cp.pos().getZ() - oz, 4);
                long h = px * 7919L + pz * 104729L + e.key;
                if (Space.hash(h) > 0.6) return false;
                net.minecraft.world.entity.Entity who = Fxu.entity(e.a);
                Vec3 dir = who != null ? who.getViewVector(1f) : new Vec3(0, -1, 0);
                double mag = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
                Vec3 plate = new Vec3(ox + px * 4 + 2, e.pos.y, oz + pz * 4 + 2);
                double lift = (1.0 + 2.2 * Space.hash(h + 1) + 3.5 * Math.max(0, dir.y)) * k + 0.25 * Math.sin(time * 0.06 + h % 9) * k;
                double ang = Math.min(1.2, 0.95 * mag + (dir.y > 0 ? dir.y * 0.6 : 0)) * k;
                Vec3 hd = mag < 1e-4 ? new Vec3(0, 0, 1) : new Vec3(dir.x / mag, 0, dir.z / mag);
                Vec3 axis = new Vec3(hd.z, 0, -hd.x);
                Vec3 off = Limb.rot(c.subtract(plate), axis, ang);
                Vec3 at = plate.add(off).add(0, lift, 0).add(hd.scale(1.5 * mag * k));
                double yawU = Math.atan2(hd.x, hd.z);
                put(s, cam, at, yawU, ang, 0, 1, 1, 1);
                s.translate(0.5, 0.5, 0.5);
                s.mulPose(Axis.YP.rotation((float) -yawU));
                s.translate(-0.5, -0.5, -0.5);
                return true;
            }
            case KALEIDO -> {
                // The ground rises and falls in steps, in the same pattern in each of the six wedges.
                float k = Fxu.env(age, e.duration, 8, 6);
                Vec3 rel = c.subtract(e.pos);
                double r = Math.sqrt(rel.x * rel.x + rel.z * rel.z);
                double a = Math.atan2(rel.z, rel.x) - Math.PI / 6, w = Math.PI / 3;
                double fold = Math.abs(((a % w) + w) % w - w / 2) / (w / 2);
                double wave = Math.sin(time * 0.11 - r * 0.85 + fold * 2.5);
                double lift = k * (0.2 + 1.3 * fold) * Math.max(0, wave);
                if (lift < 0.06) return false;
                // quantised, so it moves like stacked steps of glass rather than a soft wave
                lift = Math.round(lift * 4) / 4.0;
                put(s, cam, c.add(0, lift, 0), 0, 0, 0, 1, 1, 1);
                return true;
            }
            case TESS -> {
                // The floor of the cage, again on each wall and on the ceiling, in pieces - a room with five floors.
                double h = Math.max(1, e.power);
                float k = Fxu.env(age, e.duration, 8, 6);
                if (k < 0.02f) return false;
                if (Math.floorMod(cp.pos().getX() + cp.pos().getZ() + layer, 2) != 0) return false;
                Vec3 C = e.pos.add(0, h * 0.5, 0);
                double rx = c.x - C.x, rz = c.z - C.z, out = h + 0.55;
                if (Math.abs(rx) > h || Math.abs(rz) > h) return false;
                Vec3 to;
                double pitch = 0, roll = 0;
                switch (layer) {
                    case 0 -> { to = new Vec3(C.x + out, C.y + rx, C.z + rz); roll = Math.PI / 2; }
                    case 1 -> { to = new Vec3(C.x - out, C.y - rx, C.z + rz); roll = -Math.PI / 2; }
                    case 2 -> { to = new Vec3(C.x + rx, C.y + rz, C.z + out); pitch = -Math.PI / 2; }
                    case 3 -> { to = new Vec3(C.x + rx, C.y - rz, C.z - out); pitch = Math.PI / 2; }
                    default -> { to = new Vec3(C.x + rx, C.y + out, C.z + rz); pitch = Math.PI; }
                }
                // each piece slides out of the floor to its wall, and hangs there breathing
                double sc = 0.72 + 0.08 * Math.sin(time * 0.07 + rx + rz + layer);
                Vec3 at = c.add(to.subtract(c).scale(k));
                put(s, cam, at, 0, pitch * k, roll * k, sc, sc, sc);
                return true;
            }
            case POCKET -> {
                // The piece of the world that was cut out shrinks into the shell and turns there in miniature; at the
                // end it swells back out into its place.
                double in = Fxu.smooth((age - 6) / 14.0), back = Fxu.smooth((e.duration - age) / 10.0);
                double t = Math.min(in, back);
                if (t < 0.01) return false;
                Vec3 orb = e.pos.add(0, Math.sin(time * 0.05) * 0.15, 0);
                Vec3 ground = new Vec3(e.pos.x, c.y, e.pos.z);
                double sc = 1 - 0.89 * t, yaw = time * 0.02 * t;
                Vec3 rel = rotY(c.subtract(ground), yaw).scale(sc);
                Vec3 centre = ground.add(orb.subtract(ground).scale(t)).add(0, -0.25 * t, 0);
                put(s, cam, centre.add(rel), -yaw, 0, 0, sc, sc, sc);
                return true;
            }
            case PERSPECTIVE -> {
                // Everything near you seen twice, the copies drifting out of place and back.
                float p2 = Fxu.env(age, e.duration, 5, 8) * Math.min(1f, e.power * 1.6f);
                if (p2 < 0.03f) return false;
                double ph = layer * 2.1 + c.y * 0.6;
                Vec3 off = new Vec3(Math.sin(time * 0.13 + ph) * 0.3, Math.sin(time * 0.09 + ph * 1.3) * 0.16, Math.cos(time * 0.11 + ph) * 0.3).scale(p2);
                double sc = 1 + 0.06 * p2 * Math.sin(time * 0.1 + layer);
                put(s, cam, c.add(off), 0, 0, 0, sc, sc, sc);
                return true;
            }
            case INVERT -> {
                // The ground's twin lowered upside down into the sky above it.
                double k = FxDim.opening(age, e.duration, 10, 10);
                if (k < 0.01) return false;
                double H = e.aux.x;
                Vec3 rel = c.subtract(e.pos);
                double y = e.pos.y + H + H * 0.6 * (1 - k) - rel.y;
                Vec3 at = new Vec3(c.x, y + 0.04 * Math.sin(time * 0.05 + c.x * 0.3 + c.z * 0.2), c.z);
                put(s, cam, at, 0, Math.PI, 0, 1, 1, 1);
                return true;
            }
            case SHATTER -> {
                // Broken into pieces of three by three, each flung up on its own arc, turning, then slammed back.
                double crack = Math.max(1, e.b), air = Math.max(1, e.c), t = (age - crack) / air;
                if (t < 0 || t > 1) return false;
                int cx = Math.floorDiv(cp.pos().getX() - (int) Math.floor(e.pos.x) + 1, 3), cz = Math.floorDiv(cp.pos().getZ() - (int) Math.floor(e.pos.z) + 1, 3);
                long h = e.a * 31L + cx * 7919L + cz * 104729L;
                Vec3 cell = new Vec3(Math.floor(e.pos.x) + cx * 3 + 0.5, c.y, Math.floor(e.pos.z) + cz * 3 + 0.5);
                double up = (3 + 6 * Space.hash(h)) * 4 * t * (1 - t);
                Vec3 out = new Vec3(cell.x - e.pos.x, 0, cell.z - e.pos.z);
                out = out.lengthSqr() < 1e-6 ? Vec3.ZERO : out.normalize().scale(1.5 * Math.sin(Math.PI * t));
                double yaw = (Space.hash(h + 1) - 0.5) * 5 * t, pitch = (Space.hash(h + 2) - 0.5) * 3 * Math.sin(Math.PI * t);
                Vec3 rel0 = c.subtract(cell);
                double cp2 = Math.cos(pitch), sp2 = Math.sin(pitch);
                Vec3 off = rotY(new Vec3(rel0.x, rel0.y * cp2 - rel0.z * sp2, rel0.y * sp2 + rel0.z * cp2), yaw);
                put(s, cam, cell.add(out).add(0, up, 0).add(off), -yaw, pitch, 0, 1, 1, 1);
                return true;
            }
            case INCEPTION -> {
                // Ahead: the land swings up on its hinge like a page turning and hangs upside down over the battlefield
                // (on the slam it comes all the way down). Behind: the land curls up into a wall at your back.
                double R = Math.max(8, e.power), k = foldK(age, Math.max(1, e.b), Math.max(e.b + 1, e.c));
                if (k < 0.005) return false;
                boolean alongZ = e.a == 1;
                Vec3 u = alongZ ? new Vec3(0, 0, 1) : new Vec3(1, 0, 0);
                Vec3 rel = c.subtract(e.pos);
                if (cp.tag() == 2) {
                    // A piece of the land outside the fold: it lifts out, hangs turning, and settles back at the end.
                    double kk = Math.min(1, k);
                    int cx = Math.floorDiv(cp.pos().getX() - (int) Math.floor(e.pos.x), 3), cz = Math.floorDiv(cp.pos().getZ() - (int) Math.floor(e.pos.z), 3);
                    long h = cx * 7919L + cz * 104729L + 5;
                    Vec3 cell = new Vec3(Math.floor(e.pos.x) + cx * 3 + 1.5, c.y, Math.floor(e.pos.z) + cz * 3 + 1.5);
                    double up = (5 + 12 * Space.hash(h + 1)) * kk + 0.5 * Math.sin(time * 0.04 + h % 11) * kk;
                    double yaw = (time * 0.012 * (Space.hash(h + 2) > 0.5 ? 1 : -1) + Space.hash(h + 3) * 3) * kk;
                    double pitch = (0.5 * Math.sin(time * 0.02 + h % 7) + (Space.hash(h + 4) - 0.5) * 1.6) * kk;
                    Vec3 r0 = c.subtract(cell);
                    double cp2 = Math.cos(pitch), sp2 = Math.sin(pitch);
                    Vec3 off = rotY(new Vec3(r0.x, r0.y * cp2 - r0.z * sp2, r0.y * sp2 + r0.z * cp2), yaw);
                    put(s, cam, cell.add(0, up, 0).add(off), -yaw, pitch, 0, 1, 1, 1);
                    return true;
                }
                double sg = cp.tag(), sAl = rel.dot(u), ex = Math.abs(sAl) - HINGE;
                boolean overhead = Math.signum(e.aux.x) == sg;
                double th, along, lift;
                if (overhead) {
                    th = Math.min(Math.PI, 0.85 * Math.PI * k) * (1 + 0.02 * Math.sin(time * 0.05));
                    along = sg * (HINGE + ex * Math.cos(th));
                    // It rises as it turns, so it hangs high over the battlefield; on the slam it drops all the way.
                    double raise = 6 * Math.min(1, k) * (k > 1 ? Math.max(0, 1 - (k - 1) / 0.45) : 1);
                    lift = ex * Math.sin(th) + raise;
                } else {
                    double Rc = (R - HINGE) / (Math.PI / 2);
                    th = (ex / Rc) * k * (1 + 0.03 * Math.sin(time * 0.05));
                    along = sg * (HINGE + Rc * Math.sin(th));
                    lift = Rc * (1 - Math.cos(th));
                }
                double dy = rel.y + 0.5;
                Vec3 nrm = u.scale(-sg * Math.sin(th)).add(0, Math.cos(th), 0);
                Vec3 lateral = rel.subtract(u.scale(sAl)).multiply(1, 0, 1);
                Vec3 at = e.pos.add(u.scale(along)).add(lateral).add(0, lift - 0.5, 0).add(nrm.scale(dy));
                if (alongZ) put(s, cam, at, 0, -th * sg, 0, 1, 1, 1);
                else put(s, cam, at, 0, 0, th * sg, 1, 1, 1);
                return true;
            }
            default -> { return false; }
        }
    }
}
