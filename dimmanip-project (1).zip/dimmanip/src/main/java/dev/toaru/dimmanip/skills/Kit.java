package dev.toaru.dimmanip.skills;

import dev.toaru.dimmanip.Cfg;
import dev.toaru.dimmanip.Common;
import dev.toaru.dimmanip.Hit;
import dev.toaru.dimmanip.Snd;
import dev.toaru.dimmanip.Status;
import dev.toaru.dimmanip.Targeting;
import dev.toaru.dimmanip.Timed;
import dev.toaru.dimmanip.net.Fx;
import dev.toaru.dimmanip.net.FxType;
import io.github.pinchan4273.reacademycraft.api.ActivationOutcome;
import io.github.pinchan4273.reacademycraft.api.mc.AbilityActor;
import io.github.pinchan4273.reacademycraft.api.mc.ActivationContext;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;

/**
 * Dimension Manipulation (Godlike): the esper uses the real world as a weapon - the land between two places folded away,
 * the world cut along a line whose ends are one place, a cube with no outside, a world nested inside itself, "down" turned at will, space split into six mirrors, the
 * ground shattered into the sky, and the whole battlefield folded shut. The terrain the players see bending is a picture
 * of the real ground (drawn by the client); the real world is never changed.
 */
public final class Kit {
    private Kit() { }

    static final Vec3 UP = new Vec3(0, 1, 0);

    static Vec3 flat(Vec3 v, Vec3 fallback) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1e-6 ? fallback : f.normalize();
    }

    static boolean foe(AbilityActor actor, LivingEntity e, String move) { return Targeting.hostile(actor, e, Common.id(move)); }

    // ================================================================== Atlas Fold
    public static final class AtlasFold extends Move {
        public AtlasFold() { super("atlas_fold"); }

        @Override
        protected ActivationOutcome use(ActivationContext c, ServerPlayer p, Cfg.Mv m) {
            ServerLevel level = p.serverLevel();
            LivingEntity t = Targeting.living(p, m.v("range"));
            Vec3 look = flat(p.getLookAngle(), new Vec3(0, 0, 1));
            // Aimed at a creature: you come out just past it. Otherwise: where you aim, on the ground.
            Vec3 want = t != null ? t.position().add(flat(t.position().subtract(p.position()), look).scale(1.4))
                    : Common.ground(level, Targeting.point(p, m.v("range")).add(0, 0.3, 0));
            if (want.distanceTo(p.position()) < 3) return refuse(p, "Aim further away.");
            Vec3 to = Common.fits(level, p, want) ? want : Common.safeNear(level, p, want);
            if (to == null) return refuse(p, "No room to unfold there.");
            if (!pay(c, m)) return broke();
            Vec3 from = p.position();
            int fold = m.ticks("fold_seconds");
            Fx.make(level, from, FxType.ATLAS, fold + 12).aux(to).b(fold).a(p.getId()).range(192).send();
            Snd.at(level, from, SoundEvents.WARDEN_SONIC_CHARGE, 1.0f, 1.4f);
            Snd.at(level, to, SoundEvents.BOOK_PAGE_TURN, 2.0f, 0.5f);
            Common.later(p, c.actor(), fold, () -> {
                if (!p.isAlive() || p.level() != level) return;
                Vec3 dir = flat(to.subtract(from), look);
                p.teleportTo(level, to.x, to.y, to.z, (float) Math.toDegrees(Math.atan2(-dir.x, dir.z)), p.getXRot());
                p.fallDistance = 0;
                Status.safeFall(p, 40);
                for (LivingEntity e : Targeting.livingWithin(level, to.add(0, 1, 0), m.v("radius"), p)) {
                    if (!foe(c.actor(), e, "atlas_fold") || !Hit.damage(c.actor(), e, id, m.f("damage"))) continue;
                    Vec3 out = flat(e.position().subtract(to), dir);
                    Targeting.setMotion(e, out.scale(1.0 * Targeting.controlFactor(e)).add(0, 0.45, 0));
                }
                Fx.make(level, to.add(0, 1, 0), FxType.SHOCK, 12).power(1.6f).c(5).range(128).send();
                Snd.at(level, to, SoundEvents.WARDEN_SONIC_BOOM, 0.6f, 1.6f);
            });
            return done(c, m);
        }
    }

    // ================================================================== Severance
    /**
     * The cut in the world. When it opens, enemies standing on it are hurt and dropped out of a tear in the sky. Then, for
     * as long as it stays open, both ends are one place: whatever goes into the cut - a creature, an arrow, the esper -
     * comes out the same distance from the other end, turned back along it.
     */
    static final class Cut extends Timed.Effect {
        final Vec3 a, b, u;
        final double len;
        final Cfg.Mv m;
        final int open;
        final Map<Integer, Long> crossed = new HashMap<>();
        Cut(ServerPlayer owner, AbilityActor actor, int ticks, Vec3 a, Vec3 b, int open, Cfg.Mv m) {
            super(owner, actor, ticks); this.a = a; this.b = b; this.open = open; this.m = m;
            this.len = Math.max(1, b.subtract(a).length()); this.u = b.subtract(a).normalize();
            crossed.put(owner.getId(), level.getGameTime() + open + 10);
        }

        boolean ready(Entity e) {
            Long until = crossed.get(e.getId());
            return until == null || level.getGameTime() >= until;
        }

        /** How far along the cut this point is, or -1 if it isn't in it. */
        double on(Vec3 p, double width) {
            Vec3 rel = p.subtract(a);
            double s = rel.dot(u);
            if (s < 0 || s > len || Math.abs(p.y - a.y) > 3.5) return -1;
            Vec3 side = Targeting.horizontal(rel.subtract(u.scale(s)));
            return side.lengthSqr() <= width * width ? s : -1;
        }

        @Override
        protected boolean tick() {
            if (age() < open) return true;
            if (age() == open) {
                for (LivingEntity e : Common.along(level, a.add(0, 1, 0), b.add(0, 1, 0), m.v("width"), owner)) {
                    if (!foe(actor, e, "severance") || Math.abs(e.getY() - a.y) > 4) continue;
                    crossed.put(e.getId(), level.getGameTime() + 30);
                    e.invulnerableTime = 0;
                    if (!Hit.damage(actor, e, Common.id("severance"), m.f("damage")) || Targeting.bossLike(e)) continue;
                    double up = e instanceof Player ? m.v("player_sky_height") : m.v("sky_height");
                    Vec3 sky = e.position().add(0, up, 0);
                    if (!Common.fits(level, e, sky)) continue;
                    Fx.make(level, sky.add(0, e.getBbHeight() + 0.6, 0), FxType.SKY_RIP, 30).range(192).send();
                    if (e instanceof ServerPlayer sp) sp.teleportTo(level, sky.x, sky.y, sky.z, sp.getYRot(), sp.getXRot());
                    else e.teleportTo(sky.x, sky.y, sky.z);
                    Targeting.setMotion(e, new Vec3(0, -0.4, 0));
                }
                Snd.at(level, a.add(b).scale(0.5), SoundEvents.WARDEN_SONIC_BOOM, 1.6f, 0.5f);
                return true;
            }
            Vec3 mid = a.add(b).scale(0.5);
            // Creatures (the esper too) stepping into the cut.
            for (LivingEntity e : Targeting.livingWithin(level, mid, len / 2 + 2, null)) {
                if (!ready(e) || Targeting.bossLike(e) || e.isPassenger()) continue;
                double s = on(e.position(), 0.9);
                if (s < 0) continue;
                Vec3 to = e.position().add(u.scale(len - 2 * s));
                if (!Common.fits(level, e, to)) { Vec3 near = Common.safeNear(level, e, to); if (near == null) continue; to = near; }
                crossed.put(e.getId(), level.getGameTime() + 25);
                Vec3 v = e.getDeltaMovement();
                Vec3 out = v.subtract(u.scale(2 * v.dot(u)));
                Fx.make(level, e.position().add(0, 1, 0), FxType.SHOCK, 8).power(0.8f).c(5).range(96).send();
                if (e instanceof ServerPlayer sp) sp.teleportTo(level, to.x, to.y, to.z, sp.getYRot(), sp.getXRot());
                else e.teleportTo(to.x, to.y, to.z);
                Targeting.setMotion(e, out);
                e.fallDistance = 0;
                Fx.make(level, to.add(0, 1, 0), FxType.SHOCK, 8).power(0.8f).c(5).range(96).send();
                Snd.at(level, to, SoundEvents.ENDERMAN_TELEPORT, 0.7f, 0.6f);
            }
            // Arrows and other shots flying into it come out of the far end, flying back along it.
            for (Projectile pr : Targeting.projectilesWithin(level, mid, len / 2 + 2, null)) {
                if (!ready(pr)) continue;
                double s = on(pr.position(), 1.1);
                if (s < 0) continue;
                crossed.put(pr.getId(), level.getGameTime() + 25);
                Vec3 to = pr.position().add(u.scale(len - 2 * s));
                Vec3 v = pr.getDeltaMovement();
                pr.teleportTo(to.x, to.y, to.z);
                Targeting.setMotion(pr, v.subtract(u.scale(2 * v.dot(u))));
            }
            return !over();
        }
    }

    public static final class Severance extends Move {
        public Severance() { super("severance"); }

        @Override
        protected ActivationOutcome use(ActivationContext c, ServerPlayer p, Cfg.Mv m) {
            if (!pay(c, m)) return broke();
            ServerLevel level = p.serverLevel();
            Vec3 dir = flat(p.getLookAngle(), new Vec3(0, 0, 1));
            Vec3 a = Common.ground(level, p.position().add(dir.scale(1.5)).add(0, 0.5, 0));
            Vec3 b = a.add(dir.scale(m.v("length")));
            int open = 12, total = open + m.ticks("seconds");
            Timed.add(new Cut(p, c.actor(), total, a, b, open, m));
            Fx.make(level, a, FxType.REND, total + 12).aux(b).b(open).range(256).send();
            Snd.at(level, a, SoundEvents.WARDEN_EMERGE, 1.4f, 1.2f);
            Snd.at(level, a.add(b).scale(0.5), SoundEvents.STONE_BREAK, 2.0f, 0.4f);
            return done(c, m);
        }
    }

    // ================================================================== Tesseract (and the singularity it collapses into)
    static final class Horizon extends Timed.Effect {
        final Vec3 at;
        final Cfg.Mv m;
        final String move;
        Horizon(ServerPlayer owner, AbilityActor actor, int ticks, Vec3 at, Cfg.Mv m, String move) { super(owner, actor, ticks); this.at = at; this.m = m; this.move = move; }

        @Override
        protected boolean tick() {
            double r = m.v("radius");
            Vec3 core = at.add(0, 1, 0);
            for (LivingEntity e : Targeting.livingWithin(level, core, r * 1.4, owner)) {
                if (!foe(actor, e, move)) continue;
                Vec3 in = core.subtract(Targeting.centre(e));
                double d = in.length();
                // Dragged in, faster the closer it gets, round and round like water down a drain.
                Vec3 swirl = new Vec3(-in.z, 0, in.x).normalize().scale(0.12);
                Vec3 pull = in.normalize().scale(Math.min(0.55, 0.12 + 0.5 / Math.max(1, d)) * Targeting.controlFactor(e));
                Targeting.setMotion(e, e.getDeltaMovement().scale(0.5).add(pull).add(swirl.scale(Targeting.controlFactor(e))));
                e.fallDistance = 0;
            }
            for (Projectile pr : Targeting.projectilesWithin(level, core, r, owner)) Targeting.setMotion(pr, core.subtract(pr.position()).scale(0.2));
            if (!over()) return true;
            Hit.blast(actor, level, core, r, Common.id(move), m.f("damage"), m.v("throw"), 0.6, owner);
            Fx.make(level, core, FxType.SHOCK, 18).power((float) r * 0.6f).c(5).range(192).send();
            Snd.at(level, core, SoundEvents.GENERIC_EXPLODE, 2.0f, 0.5f);
            Snd.at(level, core, SoundEvents.WARDEN_SONIC_BOOM, 1.6f, 0.6f);
            return false;
        }
    }

    /**
     * The cube with no outside: the victim can walk, but leaving through any side brings it back in through the opposite
     * one. It can be hit from outside and cannot hit out. When time runs out the cube collapses into a singularity that
     * drags in everyone near and then bursts.
     */
    static final class Cube extends Timed.Effect {
        final LivingEntity target;
        final Vec3 at;
        final double half;
        final Cfg.Mv m;
        Cube(ServerPlayer owner, AbilityActor actor, int ticks, LivingEntity target, Cfg.Mv m) {
            super(owner, actor, ticks); this.target = target; this.at = target.position(); this.half = m.v("size"); this.m = m;
        }

        @Override
        protected boolean tick() {
            if (!target.isAlive() || target.level() != level) return false;
            Status.set(target, "dm_tess", 5);
            Vec3 p = target.position();
            double nx = p.x, nz = p.z;
            if (p.x - at.x > half) nx = p.x - 2 * half + 0.3; else if (at.x - p.x > half) nx = p.x + 2 * half - 0.3;
            if (p.z - at.z > half) nz = p.z - 2 * half + 0.3; else if (at.z - p.z > half) nz = p.z + 2 * half - 0.3;
            if (nx != p.x || nz != p.z) {
                Vec3 to = new Vec3(nx, p.y, nz);
                if (!Common.fits(level, target, to)) { Vec3 near = Common.safeNear(level, target, to); to = near != null && Math.abs(near.x - at.x) <= half && Math.abs(near.z - at.z) <= half ? near : at; }
                Vec3 v = target.getDeltaMovement();
                if (target instanceof ServerPlayer sp) sp.teleportTo(level, to.x, to.y, to.z, sp.getYRot(), sp.getXRot());
                else target.teleportTo(to.x, to.y, to.z);
                Targeting.setMotion(target, v);
                Fx.make(level, to.add(0, 1, 0), FxType.SHOCK, 8).power(0.8f).c(5).range(96).send();
                Snd.at(level, to, SoundEvents.ENDERMAN_TELEPORT, 0.5f, 1.6f);
            }
            if (p.y - at.y > half * 1.6) Targeting.setMotion(target, new Vec3(target.getDeltaMovement().x, -0.5, target.getDeltaMovement().z));
            return !over();
        }

        @Override
        protected void end(boolean natural) {
            Status.clear(target, "dm_tess");
            if (!natural) return;
            if (target instanceof Player) Status.set(target, "ee_cc_immune", (int) Math.round(Cfg.CONTROL_IMMUNITY.get() * 20));
            // The cube folds in on itself.
            Vec3 core = Common.ground(level, at.add(0, 0.5, 0));
            int pull = m.ticks("pull_seconds");
            Timed.add(new Horizon(owner, actor, pull, core, m, "tesseract"));
            Fx.make(level, core, FxType.HORIZON, pull + 24).power(m.f("radius")).b(pull).range(256).send();
            Snd.at(level, core, SoundEvents.END_PORTAL_SPAWN, 0.8f, 1.6f);
            Snd.at(level, core, SoundEvents.WARDEN_SONIC_CHARGE, 1.6f, 0.5f);
        }
    }

    /** May this attack go ahead? Nothing reaches out of a Tesseract. (From ServerEvents.) */
    public static boolean sealedIn(Entity attacker, Entity victim) {
        return Status.has(attacker, "dm_tess") && !Status.has(victim, "dm_tess");
    }

    public static final class Tesseract extends Move {
        public Tesseract() { super("tesseract"); }

        @Override
        protected ActivationOutcome use(ActivationContext c, ServerPlayer p, Cfg.Mv m) {
            LivingEntity t = aimed(p, c, m.v("range"));
            if (t == null) return refuse(p, "Aim at an enemy.");
            if (Targeting.bossLike(t)) return refuse(p, "Too vast to close in a cube.");
            int ticks = m.ticks("seconds");
            if (t instanceof Player) ticks = Common.control(t, ticks * 2);
            if (ticks <= 0) return refuse(p, "Their space just steadied - wait a moment.");
            if (!pay(c, m)) return broke();
            Timed.add(new Cube(p, c.actor(), ticks, t, m));
            Fx.make(p.serverLevel(), t.position().add(0, m.v("size") * 0.5, 0), FxType.TESS, ticks + 6).power(m.f("size")).b(ticks).range(192).send();
            Snd.at(p.serverLevel(), t.position(), SoundEvents.BEACON_ACTIVATE, 1.6f, 0.5f);
            Snd.at(p.serverLevel(), t.position(), SoundEvents.END_PORTAL_SPAWN, 0.6f, 1.9f);
            return done(c, m);
        }
    }

    // ================================================================== Infinite Regress
    static final class Regress extends Timed.Effect {
        final LivingEntity target;
        final Vec3 at;
        final int layer;
        final Cfg.Mv m;
        int hits;
        Regress(ServerPlayer owner, AbilityActor actor, int ticks, LivingEntity target, int layer, Cfg.Mv m) {
            super(owner, actor, ticks); this.target = target; this.at = target.position(); this.layer = layer; this.m = m;
        }

        @Override
        protected boolean tick() {
            if (!target.isAlive() || target.level() != level) return false;
            // Held while the world falls away round it, layer after layer.
            if (target.position().distanceToSqr(at) > 0.04) target.teleportTo(at.x, at.y, at.z);
            Targeting.setMotion(target, Vec3.ZERO);
            target.fallDistance = 0;
            if (age() > 0 && age() % layer == 0 && hits < m.v("layers")) {
                hits++;
                target.invulnerableTime = 0;
                Hit.damage(actor, target, Common.id("infinite_regress"), m.f("damage_per_layer"));
                Fx.make(level, Targeting.centre(target), FxType.SHOCK, 10).power(1.0f + 0.3f * hits).c(5).range(128).send();
                Snd.at(level, target.position(), SoundEvents.WARDEN_SONIC_BOOM, 0.5f, 1.2f + 0.2f * hits);
            }
            return !over();
        }

        @Override
        protected void end(boolean natural) {
            if (!target.isAlive()) return;
            if (target instanceof Player) Status.set(target, "ee_cc_immune", (int) Math.round(Cfg.CONTROL_IMMUNITY.get() * 20));
            // Spat out the far side of the last layer.
            Vec3 out = flat(target.position().subtract(owner.position()), new Vec3(1, 0, 0));
            Targeting.setMotion(target, out.scale(m.v("throw") * Targeting.controlFactor(target)).add(0, 0.6, 0));
        }
    }

    public static final class InfiniteRegress extends Move {
        public InfiniteRegress() { super("infinite_regress"); }

        @Override
        protected ActivationOutcome use(ActivationContext c, ServerPlayer p, Cfg.Mv m) {
            LivingEntity t = aimed(p, c, m.v("range"));
            if (t == null) return refuse(p, "Aim at an enemy.");
            if (Targeting.bossLike(t)) return refuse(p, "Too vast to fold into itself.");
            int layer = m.ticks("layer_seconds");
            int ticks = layer * (int) m.v("layers") + 4;
            if (t instanceof Player) ticks = Common.control(t, ticks * 2);
            if (ticks <= 0) return refuse(p, "Their space just steadied - wait a moment.");
            if (!pay(c, m)) return broke();
            Timed.add(new Regress(p, c.actor(), ticks, t, layer, m));
            Fx.make(p.serverLevel(), Targeting.centre(t), FxType.REGRESS, ticks + 8).a(t.getId()).b(ticks).power(4.5f).range(192).send();
            Snd.at(p.serverLevel(), t.position(), SoundEvents.END_PORTAL_SPAWN, 0.7f, 1.8f);
            return done(c, m);
        }
    }

    // ================================================================== Gravity Well
    /**
     * For a few seconds "down", for every enemy in the area, is wherever the esper is looking - steered live. They fall
     * that way and are hurt each time they hit something (a wall, the ground, the ceiling), a few times at most.
     */
    static final class Well extends Timed.Effect {
        final Vec3 at;
        final Cfg.Mv m;
        final Map<Integer, Integer> hits = new HashMap<>(), falling = new HashMap<>();
        final Set<LivingEntity> held = new HashSet<>();
        Well(ServerPlayer owner, AbilityActor actor, int ticks, Vec3 at, Cfg.Mv m) { super(owner, actor, ticks); this.at = at; this.m = m; }

        @Override
        protected boolean tick() {
            if (age() < 6) return true;
            double r = m.v("radius");
            Vec3 dir = owner.getLookAngle();
            for (LivingEntity e : Targeting.livingWithin(level, at.add(0, 2, 0), r * 1.3, owner)) {
                if (!foe(actor, e, "gravity_well") || Targeting.bossLike(e)) continue;
                held.add(e);
                double k = Targeting.controlFactor(e) * (e instanceof Player ? Math.max(0.5, Cfg.PLAYER_CONTROL.get()) : 1);
                int fell = falling.getOrDefault(e.getId(), 0);
                // Has it hit something that way?
                boolean blocked = !Common.fits(level, e, e.position().add(dir.scale(0.7)));
                if (blocked && fell >= 6 && hits.getOrDefault(e.getId(), 0) < (int) m.v("max_hits")) {
                    hits.merge(e.getId(), 1, Integer::sum);
                    falling.put(e.getId(), -6);
                    e.invulnerableTime = 0;
                    Hit.damage(actor, e, Common.id("gravity_well"), m.f("damage"));
                    Fx.make(level, Targeting.centre(e), FxType.SHOCK, 12).power(1.4f).c(5).range(128).send();
                    Snd.at(level, e.position(), SoundEvents.PLAYER_BIG_FALL, 1.4f, 0.7f);
                    Targeting.setMotion(e, dir.scale(-0.35));
                    continue;
                }
                falling.put(e.getId(), blocked ? Math.min(fell, 0) : fell + 1);
                Vec3 v = e.getDeltaMovement().scale(0.9).add(dir.scale(m.v("pull") * k)).add(0, 0.08, 0);
                Targeting.setMotion(e, Targeting.capLength(v, m.v("max_speed")));
                e.fallDistance = 0;
                if (e instanceof ServerPlayer sp && age() % 10 == 0) Fx.make(level, sp.position(), FxType.PERSPECTIVE, 14).a(-1).power(0.35f).b(1).sendTo(sp);
            }
            return !over();
        }

        @Override
        protected void end(boolean natural) {
            for (LivingEntity e : held) if (e.isAlive()) { Status.safeFall(e, 80); e.fallDistance = 0; }
        }
    }

    public static final class GravityWell extends Move {
        public GravityWell() { super("gravity_well"); }

        @Override
        protected ActivationOutcome use(ActivationContext c, ServerPlayer p, Cfg.Mv m) {
            Vec3 at = Common.ground(p.serverLevel(), Targeting.point(p, m.v("range")).add(0, 0.3, 0));
            if (!pay(c, m)) return broke();
            int t = m.ticks("seconds");
            Timed.add(new Well(p, c.actor(), t, at, m));
            Fx.make(p.serverLevel(), at, FxType.GRAVITY, t + 10).a(p.getId()).power(m.f("radius")).b(t).range(256).send();
            Snd.at(p.serverLevel(), at, SoundEvents.BEACON_DEACTIVATE, 2.0f, 0.4f);
            Snd.at(p.serverLevel(), at, SoundEvents.WARDEN_HEARTBEAT, 2.0f, 0.6f);
            Fx.hint(p, "Down is where you look.");
            return done(c, m);
        }
    }

    // ================================================================== Kaleidoscope (and the shattering it ends in)
    static final class ShatterFx extends Timed.Effect {
        final Vec3 at;
        final Cfg.Mv m;
        final int crack, air;
        final String move;
        final Set<LivingEntity> flung = new HashSet<>();
        ShatterFx(ServerPlayer owner, AbilityActor actor, Vec3 at, Cfg.Mv m, int crack, int air, String move) {
            super(owner, actor, crack + air); this.at = at; this.m = m; this.crack = crack; this.air = air; this.move = move;
        }

        @Override
        protected boolean tick() {
            double r = m.v("radius");
            if (age() == crack) {
                // The ground breaks: everyone standing on it goes up with the pieces.
                for (LivingEntity e : Targeting.livingWithin(level, at.add(0, 1, 0), r, owner)) {
                    if (!foe(actor, e, move) || Targeting.bossLike(e)) continue;
                    if (Math.abs(e.getY() - at.y) > 3) continue;
                    flung.add(e);
                    Vec3 out = flat(e.position().subtract(at), new Vec3(1, 0, 0)).scale(0.25);
                    Targeting.setMotion(e, out.add(0, m.v("launch") * Targeting.controlFactor(e), 0));
                    Status.safeFall(e, air + 10);
                }
                Snd.at(level, at, SoundEvents.GLASS_BREAK, 2.0f, 0.4f);
                Snd.at(level, at, SoundEvents.GENERIC_EXPLODE, 1.4f, 0.6f);
            }
            if (age() == crack + air - 8) {
                // Everything comes back down at once.
                for (LivingEntity e : flung) if (e.isAlive()) Targeting.setMotion(e, new Vec3(e.getDeltaMovement().x * 0.3, -1.6, e.getDeltaMovement().z * 0.3));
            }
            return !over();
        }

        @Override
        protected void end(boolean natural) {
            if (!natural) return;
            for (LivingEntity e : flung) {
                if (!e.isAlive()) continue;
                e.invulnerableTime = 0;
                Hit.damage(actor, e, Common.id(move), m.f("damage"));
                Fx.make(level, e.position(), FxType.SHOCK, 12).power(1.4f).c(5).range(128).send();
            }
            Snd.at(level, at, SoundEvents.ANVIL_LAND, 2.0f, 0.4f);
            Snd.at(level, at, SoundEvents.GENERIC_EXPLODE, 1.6f, 0.5f);
        }
    }

    /**
     * Space round the esper cut into six mirrored wedges. Everyone else sees six of him and cannot tell which is real:
     * hits aimed at him often land on a reflection, monsters keep losing him, and every hit he lands on one enemy inside
     * lands on all the others too. When it ends the mirror breaks - and so does the ground under it.
     */
    static final class Mirror extends Timed.Effect {
        final Vec3 at;
        final Cfg.Mv m;
        long fx;
        Mirror(ServerPlayer owner, AbilityActor actor, int ticks, Vec3 at, Cfg.Mv m) { super(owner, actor, ticks); this.at = at; this.m = m; }

        boolean inside(Entity e) { return Targeting.horizontal(e.position().subtract(at)).lengthSqr() <= m.v("radius") * m.v("radius") && Math.abs(e.getY() - at.y) < 12; }

        @Override
        protected boolean tick() {
            if (age() % 10 == 0) {
                for (LivingEntity e : Targeting.livingWithin(level, at.add(0, 2, 0), m.v("radius") * 1.3, owner)) {
                    if (!foe(actor, e, "kaleidoscope") || !inside(e)) continue;
                    if (e instanceof net.minecraft.world.entity.Mob mob && mob.getTarget() == owner && level.random.nextFloat() < 0.6f) mob.setTarget(null);
                    if (e instanceof ServerPlayer sp) Fx.make(level, sp.position(), FxType.PERSPECTIVE, 14).a(-1).power(0.3f).b(1).sendTo(sp);
                }
            }
            return !over();
        }

        @Override
        protected void end(boolean natural) {
            if (!natural) { Fx.cancel(level, fx); return; }
            int crack = m.ticks("crack_seconds"), air = m.ticks("air_seconds");
            Timed.add(new ShatterFx(owner, actor, at, m, crack, air, "kaleidoscope"));
            Fx.make(level, at, FxType.SHATTER, crack + air + 24).power(m.f("radius")).a(level.random.nextInt(1 << 20)).b(crack).c(air).range(256).send();
            Snd.at(level, at, SoundEvents.GLASS_BREAK, 2.0f, 0.6f);
            Snd.at(level, at, SoundEvents.AMETHYST_BLOCK_BREAK, 2.0f, 0.4f);
        }
    }

    /** A hit about to land on an esper inside his own Kaleidoscope: it may only break a reflection. (From ServerEvents.) */
    public static boolean reflection(ServerPlayer victim, @javax.annotation.Nullable Entity attacker) {
        if (attacker == null || attacker == victim || Hit.busy()) return false;
        Mirror mr = Timed.ownedBy(Mirror.class, victim.getUUID());
        if (mr == null || mr.ended() || !mr.inside(victim) || !mr.inside(attacker)) return false;
        if (victim.getRandom().nextDouble() >= mr.m.v("miss_chance")) return false;
        Fx.make(mr.level, victim.position(), FxType.SHIFT, 12).a(victim.getId()).aux(victim.position().add(0, 0.01, 0)).power(victim.getYRot()).range(96).send();
        Snd.at(mr.level, victim.position(), SoundEvents.GLASS_BREAK, 0.8f, 1.6f);
        return true;
    }

    /** A hit the esper landed inside his Kaleidoscope: every other enemy in it takes a share. (From ServerEvents.) */
    public static void mirrored(ServerPlayer att, LivingEntity victim, float amount) {
        if (Hit.busy() || amount <= 0) return;
        Mirror mr = Timed.ownedBy(Mirror.class, att.getUUID());
        if (mr == null || mr.ended() || !mr.inside(victim) || !foe(mr.actor, victim, "kaleidoscope")) return;
        float dmg = (float) (amount * mr.m.v("mirror_share"));
        ServerLevel level = mr.level;
        Common.later(att, mr.actor, 2, () -> {
            for (LivingEntity e : Targeting.livingWithin(level, mr.at.add(0, 2, 0), mr.m.v("radius") * 1.3, att)) {
                if (e == victim || !e.isAlive() || !mr.inside(e) || !foe(mr.actor, e, "kaleidoscope")) continue;
                e.invulnerableTime = 0;
                Hit.damage(mr.actor, e, Common.id("kaleidoscope"), dmg);
                Fx.make(level, Targeting.centre(e), FxType.SHOCK, 8).power(0.9f).c(5).range(96).send();
            }
        });
    }

    public static final class Kaleidoscope extends Move {
        public Kaleidoscope() { super("kaleidoscope"); }

        @Override
        protected ActivationOutcome use(ActivationContext c, ServerPlayer p, Cfg.Mv m) {
            if (Timed.ownedBy(Mirror.class, p.getUUID()) != null) return refuse(p, "The mirror is already up.");
            if (!pay(c, m)) return broke();
            ServerLevel level = p.serverLevel();
            Vec3 at = Common.ground(level, p.position().add(0, 0.5, 0));
            int t = m.ticks("seconds");
            Mirror mr = Timed.add(new Mirror(p, c.actor(), t, at, m));
            mr.fx = Fx.make(level, at, FxType.KALEIDO, t + 8).a(p.getId()).power(m.f("radius")).b(t).range(256).send();
            Snd.at(level, at, SoundEvents.AMETHYST_BLOCK_CHIME, 2.0f, 0.5f);
            Snd.at(level, at, SoundEvents.BEACON_ACTIVATE, 1.6f, 1.6f);
            Fx.hint(p, "Six of you. Every hit you land strikes them all.");
            return done(c, m);
        }
    }

    // ================================================================== Inception (ultimate)
    static final class Fold extends Timed.Effect {
        final Vec3 at;
        final Cfg.Mv m;
        final int foldEnd, slamAt;
        long fx;
        Fold(ServerPlayer owner, AbilityActor actor, Vec3 at, Cfg.Mv m) {
            super(owner, actor, m.ticks("fold_seconds") + m.ticks("hold_seconds") + m.ticks("slam_seconds"));
            this.at = at; this.m = m;
            foldEnd = m.ticks("fold_seconds");
            slamAt = foldEnd + m.ticks("hold_seconds");
        }

        boolean inside(Entity e) { return Targeting.horizontal(e.position().subtract(at)).lengthSqr() <= m.v("radius") * m.v("radius"); }

        @Override
        protected boolean tick() {
            long a = age();
            if (a > foldEnd && a < slamAt && a % 20 == 0) {
                for (LivingEntity e : Targeting.livingWithin(level, at, m.v("radius"), owner))
                    if (e instanceof ServerPlayer sp && foe(actor, sp, "inception"))
                        Fx.make(level, sp.position(), FxType.PERSPECTIVE, 26).a(-1).power(0.45f).b(1).sendTo(sp);
            }
            if (a == slamAt) {
                Snd.at(level, at, SoundEvents.WARDEN_SONIC_CHARGE, 2.0f, 0.4f);
                Snd.at(level, at, SoundEvents.ELDER_GUARDIAN_CURSE, 1.4f, 0.5f);
            }
            return !over();
        }

        @Override
        protected void end(boolean natural) {
            Status.set(owner, "dm_burnout", m.ticks("burnout_seconds"));
            if (!natural) { Fx.cancel(level, fx); return; }
            // The fold slams shut on everyone inside.
            for (LivingEntity e : Targeting.livingWithin(level, at, m.v("radius"), owner)) {
                if (!foe(actor, e, "inception")) continue;
                e.invulnerableTime = 0;
                Hit.damage(actor, e, Common.id("inception"), m.f("final_damage"));
                Vec3 out = flat(e.position().subtract(at), new Vec3(1, 0, 0));
                Targeting.setMotion(e, out.scale(m.v("throw") * Targeting.controlFactor(e)).add(0, 0.6, 0));
            }
            Snd.at(level, at, SoundEvents.GENERIC_EXPLODE, 2.0f, 0.4f);
            Snd.at(level, at, SoundEvents.WARDEN_SONIC_BOOM, 2.0f, 0.4f);
            Snd.at(level, at, SoundEvents.ANVIL_LAND, 2.0f, 0.3f);
        }
    }

    /** A hit by the esper inside his Inception (from ServerEvents): a moment later it lands again, from the folded sky. */
    public static void echo(ServerPlayer att, LivingEntity victim, float amount) {
        if (Hit.busy() || amount <= 0) return;
        for (Fold f : Timed.of(Fold.class)) {
            if (f.owner != att || f.ended() || !f.inside(victim) || f.age() < f.foldEnd || f.age() >= f.slamAt) continue;
            if (!foe(f.actor, victim, "inception")) return;
            float dmg = (float) (amount * f.m.v("echo_share"));
            ServerLevel level = f.level;
            Vec3 from = victim.position().add((level.random.nextDouble() - 0.5) * 6, 9, (level.random.nextDouble() - 0.5) * 6);
            Common.later(att, f.actor, 6, () -> {
                if (!victim.isAlive()) return;
                Fx.make(level, from, FxType.ECHO, 10).aux(Targeting.centre(victim)).range(160).send();
                victim.invulnerableTime = 0;
                Hit.damage(f.actor, victim, Common.id("inception"), dmg);
                Snd.at(level, victim.position(), SoundEvents.PLAYER_ATTACK_CRIT, 1.2f, 0.5f);
            });
            return;
        }
    }

    public static final class Inception extends Move {
        public Inception() { super("inception"); }

        @Override
        protected ActivationOutcome use(ActivationContext c, ServerPlayer p, Cfg.Mv m) {
            if (Timed.ownedBy(Fold.class, p.getUUID()) != null) return refuse(p, "It is already folded.");
            if (!pay(c, m)) return broke();
            ServerLevel level = p.serverLevel();
            Vec3 at = Common.ground(level, p.position().add(0, 0.5, 0));
            Fold f = Timed.add(new Fold(p, c.actor(), at, m));
            Vec3 look = p.getLookAngle();
            // The land ahead of you swings up over the battlefield; the land behind rises into a wall.
            int axis = Math.abs(look.x) > Math.abs(look.z) ? 0 : 1;
            double ahead = Math.signum(axis == 0 ? look.x : look.z);
            f.fx = Fx.make(level, at, FxType.INCEPTION, (int) (f.end - f.started) + 24).power(m.f("radius")).a(axis).aux(new Vec3(ahead == 0 ? 1 : ahead, 0, 0)).b(f.foldEnd).c(f.slamAt).range(320).send();
            Snd.at(level, at, SoundEvents.END_PORTAL_SPAWN, 1.0f, 0.5f);
            Snd.at(level, at, SoundEvents.WARDEN_EMERGE, 1.6f, 0.6f);
            Fx.hint(p, "Every hit you land echoes from the folded sky.");
            return done(c, m);
        }
    }
}
