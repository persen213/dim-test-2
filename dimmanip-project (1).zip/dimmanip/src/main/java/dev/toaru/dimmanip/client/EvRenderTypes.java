package dev.toaru.dimmanip.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;

/**
 * Render types for the add-on geometry (the same ones the Kazakiri and Level 4 add-ons use) (RenderType.create is public in
 * Forge 1.20.1). GLOW is the vanilla additive lightning type.
 */
public final class EvRenderTypes extends RenderType {
    private EvRenderTypes(String name, VertexFormat format, VertexFormat.Mode mode, int size, boolean crumbling, boolean sort,
                          Runnable setup, Runnable clear) {
        super(name, format, mode, size, crumbling, sort, setup, clear);
        throw new IllegalStateException("not meant to be constructed");
    }

    /** Translucent, normally blended, both sides: feathers, crystals, the barrier dome. */
    public static final RenderType CRYSTAL = create("dimmanip_crystal", DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 16384, false, true,
            RenderType.CompositeState.builder()
                    .setShaderState(RenderStateShard.POSITION_COLOR_SHADER)
                    .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
                    .setCullState(RenderStateShard.NO_CULL)
                    .setWriteMaskState(RenderStateShard.COLOR_WRITE)
                    .createCompositeState(false));

    /**
     * Solid (opaque, depth-written, both sides): the dragon models. Depth writing is what makes a model read as a solid
     * body; the translucent type showed the inside and back of every model through its front (a cloud of smoke).
     */
    public static final RenderType SOLID = create("dimmanip_solid", DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 1 << 18, false, false,
            RenderType.CompositeState.builder()
                    .setShaderState(RenderStateShard.POSITION_COLOR_SHADER)
                    .setTransparencyState(RenderStateShard.NO_TRANSPARENCY)
                    .setCullState(RenderStateShard.NO_CULL)
                    .setWriteMaskState(RenderStateShard.COLOR_DEPTH_WRITE)
                    .createCompositeState(false));

    private static final java.util.Map<net.minecraft.resources.ResourceLocation, RenderType> SKINS = new java.util.HashMap<>();

    /** A player's skin on the add-on's own arm: solid, depth-written, both sides, sharp pixels; clear pixels left out. */
    public static RenderType skin(net.minecraft.resources.ResourceLocation texture) {
        return SKINS.computeIfAbsent(texture, t -> create("dimmanip_skin", DefaultVertexFormat.POSITION_COLOR_TEX, VertexFormat.Mode.QUADS, 1024, false, false,
                RenderType.CompositeState.builder()
                        .setShaderState(RenderStateShard.POSITION_COLOR_TEX_SHADER)
                        .setTextureState(new RenderStateShard.TextureStateShard(t, false, false))
                        .setTransparencyState(RenderStateShard.NO_TRANSPARENCY)
                        .setCullState(RenderStateShard.NO_CULL)
                        .setWriteMaskState(RenderStateShard.COLOR_DEPTH_WRITE)
                        .createCompositeState(false)));
    }

    /** Drawn on top of walls: scan markers (only on the scanning player's screen). */
    public static final RenderType XRAY = create("dimmanip_xray", DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 4096, false, true,
            RenderType.CompositeState.builder()
                    .setShaderState(RenderStateShard.POSITION_COLOR_SHADER)
                    .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
                    .setCullState(RenderStateShard.NO_CULL)
                    .setDepthTestState(RenderStateShard.NO_DEPTH_TEST)
                    .setWriteMaskState(RenderStateShard.COLOR_WRITE)
                    .createCompositeState(false));

    /** Additive glow: rings, halos, edges, beams. */
    public static final RenderType GLOW = RenderType.lightning();
}
