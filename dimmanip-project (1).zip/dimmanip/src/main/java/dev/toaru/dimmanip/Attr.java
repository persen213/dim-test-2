package dev.toaru.dimmanip;

import java.util.UUID;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;

/**
 * Temporary attribute changes (speed, melee damage, knockback resistance). They are "transient" modifiers: never saved,
 * so a crash or restart cannot leave a player permanently changed; each move removes its own when it ends.
 */
public final class Attr {
    private Attr() { }

    public static UUID id(String name) { return UUID.nameUUIDFromBytes(("dimmanip:" + name).getBytes(java.nio.charset.StandardCharsets.UTF_8)); }

    public static void set(LivingEntity e, Attribute attribute, String name, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = e.getAttribute(attribute);
        if (inst == null) return;
        UUID id = id(name);
        inst.removeModifier(id);
        if (amount != 0) inst.addTransientModifier(new AttributeModifier(id, "dimmanip " + name, amount, op));
    }

    public static void remove(LivingEntity e, Attribute attribute, String name) {
        AttributeInstance inst = e.getAttribute(attribute);
        if (inst != null) inst.removeModifier(id(name));
    }
}
