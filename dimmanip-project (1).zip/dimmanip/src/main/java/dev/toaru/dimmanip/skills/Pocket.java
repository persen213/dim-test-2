package dev.toaru.dimmanip.skills;

import dev.toaru.dimmanip.Cfg;
import dev.toaru.dimmanip.Common;
import dev.toaru.dimmanip.DimManip;
import dev.toaru.dimmanip.Snd;
import dev.toaru.dimmanip.Status;
import dev.toaru.dimmanip.Targeting;
import dev.toaru.dimmanip.Timed;
import dev.toaru.dimmanip.net.Fx;
import dev.toaru.dimmanip.net.FxType;
import io.github.pinchan4273.reacademycraft.api.ActivationOutcome;
import io.github.pinchan4273.reacademycraft.api.mc.AbilityActor;
import io.github.pinchan4273.reacademycraft.api.mc.ActivationContext;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.portal.PortalInfo;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.ITeleporter;

/**
 * Pocket Universe: the esper and one enemy are cut out of space into a corridor with no end - invisible barrier walls
 * the client fills with an impossible, endlessly repeating tunnel (in this mod's own empty dimension) - a duel where the
 * esper is quicker and stronger and the enemy can't use abilities, then both are put back exactly where they were. Rooms are built far apart, one per
 * pocket open at the same time, and rebuilt every use. Everyone is always sent back: when time runs out, when either
 * of them dies or leaves, or when the server stops; a player who logs in inside a pocket with none open is sent home.
 */
public final class Pocket {
    private Pocket() { }

    public static final ResourceKey<Level> LEVEL = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(DimManip.MOD_ID, "pocket"));

    /** Where a player was taken from (kept until they are back, also across a logout). */
    record Home(ResourceKey<Level> level, Vec3 pos, float yaw, float pitch) { }
    static final Map<UUID, Home> HOMES = new HashMap<>();

    public static boolean isPocket(@Nullable Level level) { return level != null && level.dimension() == LEVEL; }

    /** How much harder the esper hits inside his own pocket (from ServerEvents). */
    public static float power(Entity attacker) {
        return Status.has(attacker, "dm_pocket_power") ? (float) (1 + Cfg.of("pocket_universe").v("damage_bonus")) : 1f;
    }

    /** Moves an entity to another dimension (players stay the same object; anything else is recreated there). */
    static @Nullable Entity send(Entity e, ServerLevel to, Vec3 pos, float yaw, float pitch) {
        if (e instanceof ServerPlayer sp) {
            sp.teleportTo(to, pos.x, pos.y, pos.z, yaw, pitch);
            sp.fallDistance = 0;
            return sp;
        }
        if (e.level() == to) { e.teleportTo(pos.x, pos.y, pos.z); return e; }
        return e.changeDimension(to, new ITeleporter() {
            @Override
            public @Nullable PortalInfo getPortalInfo(Entity entity, ServerLevel dest, Function<ServerLevel, PortalInfo> defaultPortalInfo) {
                return new PortalInfo(pos, Vec3.ZERO, yaw, pitch);
            }

            @Override
            public Entity placeEntity(Entity entity, ServerLevel current, ServerLevel dest, float y, Function<Boolean, Entity> repositionEntity) {
                return repositionEntity.apply(false);
            }

            @Override
            public boolean playTeleportSound(ServerPlayer player, ServerLevel from, ServerLevel to2) { return false; }
        });
    }

    /** The corridor's size: walkable from -HALF to +HALF along x; walking past an end brings you back in at the other. */
    public static final int HALF = 15, WIDE = 4, HIGH = 6;

    /**
     * Builds the corridor out of barrier blocks: solid to walk and fight on, but invisible - what you see in there is the
     * tunnel the client draws round it. Both ends are sealed a little past where the corridor loops.
     */
    static void build(ServerLevel level, BlockPos o) {
        BlockState wall = Blocks.BARRIER.defaultBlockState(), air = Blocks.AIR.defaultBlockState();
        for (int x = -HALF - 3; x <= HALF + 3; x++) for (int z = -WIDE - 1; z <= WIDE + 1; z++) for (int y = -1; y <= HIGH + 1; y++) {
            boolean shell = Math.abs(x) == HALF + 3 || Math.abs(z) == WIDE + 1 || y == -1 || y == HIGH + 1;
            level.setBlock(o.offset(x, y, z), shell ? wall : air, 2);
        }
    }

    static int slots;

    static final class Room extends Timed.Effect {
        final ServerLevel home, pocket;
        final Vec3 where;
        final BlockPos origin;
        @Nullable Entity target;
        final UUID targetId;
        final Home ownerHome, targetHome;
        long fxOut;

        Room(ServerPlayer owner, AbilityActor actor, int ticks, ServerLevel pocket, Entity target) {
            super(owner, actor, ticks);
            this.home = owner.serverLevel(); this.pocket = pocket; this.target = target; this.targetId = target.getUUID();
            this.where = target.position().add(owner.position()).scale(0.5).add(0, 1, 0);
            this.origin = new BlockPos((slots++ % 64) * 96, 100, 0);
            ownerHome = new Home(home.dimension(), owner.position(), owner.getYRot(), owner.getXRot());
            targetHome = new Home(home.dimension(), target.position(), target.getYRot(), target.getXRot());
            HOMES.put(owner.getUUID(), ownerHome);
            if (target instanceof ServerPlayer) HOMES.put(targetId, targetHome);
            build(pocket, origin);
            Vec3 a = Vec3.atBottomCenterOf(origin).add(-6, 0, 0), b = Vec3.atBottomCenterOf(origin).add(6, 0, 0);
            Fx.make(pocket, Vec3.atBottomCenterOf(origin), FxType.PSY, ticks + 20).power(HALF).range(200).send();
            fxOut = Fx.make(home, where, FxType.POCKET, ticks).power(1.6f).range(160).send();
            this.target = send(target, pocket, b, 90, 0);
            send(owner, pocket, a, -90, 0);
            // Inside his own space the esper is quicker and hits harder; an enemy esper can't use abilities at all.
            Cfg.Mv m = Cfg.of("pocket_universe");
            Status.set(owner, "dm_pocket_power", ticks + 5);
            dev.toaru.dimmanip.Attr.set(owner, net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, "pocket", m.v("speed"), net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.MULTIPLY_TOTAL);
            if (this.target instanceof ServerPlayer tp) {
                Common.silence(tp, "pocket", ticks);
                Fx.make(pocket, b, FxType.POCKET_VIEW, ticks).power(0.7f).sendTo(tp);
            }
            Fx.make(pocket, a, FxType.POCKET_VIEW, ticks).power(0.25f).sendTo(owner);
            Snd.at(home, where, SoundEvents.RESPAWN_ANCHOR_DEPLETE.get(), 1.4f, 0.5f);
            Snd.at(home, where, SoundEvents.WARDEN_SONIC_CHARGE, 1.0f, 0.5f);
        }

        @Override protected boolean ownerBound() { return false; }

        @Override
        protected boolean tick() {
            if (age() < 2) return true;
            if (target == null || !target.isAlive()) return false;
            // The corridor has no end: walk off one side and you come back in from the other.
            for (Entity e : new Entity[] {owner, target}) {
                if (e == null || e.level() != pocket) continue;
                double dx = e.getX() - (origin.getX() + 0.5);
                if (Math.abs(dx) > HALF) {
                    // Exactly one tunnel-length back, so the endless tunnel looks the same: you never notice the jump.
                    double nx = e.getX() - Math.signum(dx) * 2 * HALF;
                    if (e instanceof ServerPlayer sp) sp.teleportTo(pocket, nx, e.getY(), e.getZ(), sp.getYRot(), sp.getXRot());
                    else e.teleportTo(nx, e.getY(), e.getZ());
                }
            }
            return !over();
        }

        /** Sends someone home from the pocket (if they are still in it). */
        void back(@Nullable Entity e, Home h) {
            if (e == null || !e.isAlive() || e.level() != pocket) return;
            if (e instanceof ServerPlayer sp && sp.hasDisconnected()) return; // sent home when they log in again
            MinecraftServer server = pocket.getServer();
            ServerLevel to = server.getLevel(h.level());
            if (to == null) to = server.overworld();
            Vec3 at = h.pos();
            if (!Common.fits(to, e, at)) { Vec3 near = Common.safeNear(to, e, at); if (near != null) at = near; }
            send(e, to, at, h.yaw(), h.pitch());
            e.fallDistance = 0;
            Status.safeFall(e, 40);
            HOMES.remove(e.getUUID());
        }

        @Override
        protected void end(boolean natural) {
            Status.clear(owner, "dm_pocket_power");
            dev.toaru.dimmanip.Attr.remove(owner, net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, "pocket");
            back(target, targetHome);
            back(owner, ownerHome);
            Fx.cancel(home, fxOut);
            Fx.make(home, where, FxType.SHOCK, 14).power(1.6f).c(5).range(128).send();
            Snd.at(home, where, SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.4f, 1.2f);
        }
    }

    /** A player logging in: if they are inside a pocket that is no longer open, send them home. */
    public static void loggedIn(ServerPlayer p) {
        if (!isPocket(p.level())) return;
        for (Room r : Timed.of(Room.class)) if (r.owner == p || (r.target != null && r.target.getUUID().equals(p.getUUID()))) return;
        Home h = HOMES.remove(p.getUUID());
        MinecraftServer server = p.getServer();
        if (server == null) return;
        ServerLevel to = h != null ? server.getLevel(h.level()) : null;
        if (to == null) to = server.overworld();
        Vec3 at = h != null ? h.pos() : Vec3.atBottomCenterOf(to.getSharedSpawnPos());
        send(p, to, at, h != null ? h.yaw() : 0, 0);
        Status.safeFall(p, 60);
    }

    public static final class PocketUniverse extends Move {
        public PocketUniverse() { super("pocket_universe"); }

        @Override
        protected ActivationOutcome use(ActivationContext c, ServerPlayer p, Cfg.Mv m) {
            if (isPocket(p.level())) return refuse(p, "You are already inside a pocket.");
            LivingEntity t = aimed(p, c, m.v("range"));
            if (t == null) return refuse(p, "Aim at an enemy.");
            if (Targeting.bossLike(t)) return refuse(p, "Too big to cut out of space.");
            if (t instanceof Player && !Cfg.POCKET_PLAYERS.get()) return refuse(p, "This server doesn't allow taking players.");
            if (Status.has(t, "dm_pocketed")) return refuse(p, "Their space was just cut - wait a moment.");
            ServerLevel pocket = p.getServer() == null ? null : p.getServer().getLevel(LEVEL);
            if (pocket == null) return refuse(p, "The pocket dimension isn't loaded on this server.");
            int ticks = t instanceof Player ? m.ticks("player_seconds") : m.ticks("seconds");
            if (!pay(c, m)) return broke();
            Status.set(t, "dm_pocketed", ticks + m.ticks("repeat_seconds"));
            Timed.add(new Room(p, c.actor(), ticks, pocket, t));
            return done(c, m);
        }
    }
}
