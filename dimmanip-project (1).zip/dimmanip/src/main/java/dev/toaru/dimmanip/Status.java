package dev.toaru.dimmanip;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.world.entity.Entity;

/**
 * Small timed flags kept on the server by game time, per entity and name: no fall damage after a boost, exhaustion and
 * fatigue after signature moves (the moves that check them refuse while they last). Nothing is saved; a restart clears them.
 */
public final class Status {
    private Status() { }

    private static final Map<String, Long> UNTIL = new HashMap<>();

    private static String key(UUID id, String name) { return id + "/" + name; }

    public static void set(Entity e, String name, int ticks) {
        UNTIL.merge(key(e.getUUID(), name), e.level().getGameTime() + ticks, Math::max);
    }

    /** Seconds left (0 = not set). */
    public static double left(Entity e, String name) {
        String k = key(e.getUUID(), name);
        Long until = UNTIL.get(k);
        if (until == null) return 0;
        long left = until - e.level().getGameTime();
        if (left <= 0) { UNTIL.remove(k); return 0; }
        return left / 20.0;
    }

    public static boolean has(Entity e, String name) { return left(e, name) > 0; }

    public static void clear(Entity e, String name) { UNTIL.remove(key(e.getUUID(), name)); }

    public static void safeFall(Entity e, int ticks) { set(e, "safe_fall", ticks); }

    public static void clearAll() { UNTIL.clear(); }
}
