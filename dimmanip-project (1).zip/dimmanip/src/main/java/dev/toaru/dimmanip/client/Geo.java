package dev.toaru.dimmanip.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Procedural geometry from plain coloured quads (both sides). Base methods are the ones the Kazakiri add-on uses. */
public final class Geo {
    private final VertexConsumer out;
    private final Matrix4f pose;
    private final double cx, cy, cz;
    private float r = 1f, g = 1f, b = 1f, a = 1f;

    public Geo(VertexConsumer out, Matrix4f pose, Vec3 camera) {
        this.out = out; this.pose = pose; this.cx = camera.x; this.cy = camera.y; this.cz = camera.z;
    }

    /** Multiplies every alpha drawn (other players' effects can be toned down; set per caster). */
    static float alphaScale = 1f;
    /** Quads closer to the camera than this fade out so nothing blocks the view (0 = off). */
    static double nearFade = 2.5;
    /** Segment multiplier from the visual-quality setting (1 high, 0.65 medium, 0.4 low). */
    static double detail = 1.0;

    static int seg(int segments) { return detail >= 0.999 ? segments : Math.max(6, (int) Math.round(segments * detail)); }

    public Geo color(float r, float g, float b, float a) { this.r = r; this.g = g; this.b = b; this.a = a * alphaScale; return this; }

    private void v(Vec3 p) {
        out.vertex(pose, (float) (p.x - cx), (float) (p.y - cy), (float) (p.z - cz)).color(r, g, b, a).endVertex();
    }

    public void quad(Vec3 p1, Vec3 p2, Vec3 p3, Vec3 p4) {
        float keep = a;
        if (nearFade > 0) {
            double mx = (p1.x + p3.x) * 0.5 - cx, my = (p1.y + p3.y) * 0.5 - cy, mz = (p1.z + p3.z) * 0.5 - cz;
            double d2 = mx * mx + my * my + mz * mz;
            if (d2 < nearFade * nearFade) {
                double f = Math.sqrt(d2) / nearFade;
                a *= (float) (f * f);
                if (a < 0.004f) { a = keep; return; }
            }
        }
        v(p1); v(p2); v(p3); v(p4);
        v(p4); v(p3); v(p2); v(p1);
        a = keep;
    }

    /** Two perpendicular unit vectors that are perpendicular to {@code n}. */
    static Vec3[] basis(Vec3 n) {
        Vec3 nn = n.normalize();
        Vec3 helper = Math.abs(nn.y) < 0.99 ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        Vec3 u = nn.cross(helper).normalize();
        Vec3 v = nn.cross(u).normalize();
        return new Vec3[] {u, v};
    }

    /** A thin straight beam: two crossed ribbons, so it has width from every side. */
    public Geo ribbon(Vec3 from, Vec3 to, double width) {
        Vec3 d = to.subtract(from);
        if (d.lengthSqr() < 1e-10) return this;
        Vec3[] uv = basis(d);
        Vec3 n1 = uv[0].scale(width), n2 = uv[1].scale(width);
        quad(from.subtract(n1), from.add(n1), to.add(n1), to.subtract(n1));
        quad(from.subtract(n2), from.add(n2), to.add(n2), to.subtract(n2));
        return this;
    }

    /** A ring around {@code centre} lying in the plane with normal {@code normal}. */
    public Geo ring(Vec3 centre, Vec3 normal, double radius, double halfWidth, int segments, double phase, boolean dashed) {
        Vec3 nn = normal.normalize();
        Vec3[] uv = basis(nn);
        double inner = Math.max(1e-4, radius - halfWidth), outer = radius + halfWidth;
        Vec3 lift = nn.scale(halfWidth * 0.6);
        if (segments > 8) segments = seg(segments);
        for (int i = 0; i < segments; i++) {
            if (dashed && (i & 3) == 3) continue;
            double a0 = phase + Math.PI * 2.0 * i / segments, a1 = phase + Math.PI * 2.0 * (i + 1) / segments;
            Vec3 d0 = uv[0].scale(Math.cos(a0)).add(uv[1].scale(Math.sin(a0)));
            Vec3 d1 = uv[0].scale(Math.cos(a1)).add(uv[1].scale(Math.sin(a1)));
            quad(centre.add(d0.scale(inner)), centre.add(d1.scale(inner)), centre.add(d1.scale(outer)), centre.add(d0.scale(outer)));
            Vec3 m0 = centre.add(d0.scale(radius)), m1 = centre.add(d1.scale(radius));
            quad(m0.add(lift), m1.add(lift), m1.subtract(lift), m0.subtract(lift));
        }
        return this;
    }

    /** A flat filled disc (no vertical band, unlike a wide ring). */
    public Geo disc(Vec3 centre, Vec3 normal, double radius, int segments) {
        Vec3[] uv = basis(normal);
        segments = seg(segments) & ~1;
        for (int i = 0; i < segments; i += 2) {
            double a0 = Math.PI * 2.0 * i / segments, a1 = Math.PI * 2.0 * (i + 1) / segments, a2 = Math.PI * 2.0 * (i + 2) / segments;
            quad(centre,
                    centre.add(uv[0].scale(Math.cos(a0) * radius)).add(uv[1].scale(Math.sin(a0) * radius)),
                    centre.add(uv[0].scale(Math.cos(a1) * radius)).add(uv[1].scale(Math.sin(a1) * radius)),
                    centre.add(uv[0].scale(Math.cos(a2) * radius)).add(uv[1].scale(Math.sin(a2) * radius)));
        }
        return this;
    }

    /** A UV sphere made of {@code lat} x {@code lon} quads. */
    public Geo sphere(Vec3 centre, double radius, int lat, int lon) {
        for (int i = 0; i < lat; i++) {
            double t0 = Math.PI * i / lat, t1 = Math.PI * (i + 1) / lat;
            for (int j = 0; j < lon; j++) {
                double p0 = Math.PI * 2.0 * j / lon, p1 = Math.PI * 2.0 * (j + 1) / lon;
                quad(point(centre, radius, t0, p0), point(centre, radius, t0, p1), point(centre, radius, t1, p1), point(centre, radius, t1, p0));
            }
        }
        return this;
    }

    /** A triangle (a quad with its last corner repeated). */
    public Geo tri(Vec3 a, Vec3 b, Vec3 c) { quad(a, b, c, c); return this; }

    /** A filled regular hexagon in the plane with normal {@code normal}. */
    public Geo hexagon(Vec3 centre, Vec3 normal, double radius, double phase) {
        Vec3[] uv = basis(normal);
        Vec3 prev = null;
        for (int i = 0; i <= 6; i++) {
            double a = phase + Math.PI / 3.0 * i;
            Vec3 pnt = centre.add(uv[0].scale(Math.cos(a) * radius)).add(uv[1].scale(Math.sin(a) * radius));
            if (prev != null) tri(centre, prev, pnt);
            prev = pnt;
        }
        return this;
    }

    /** A hexagonal outline (a 6-segment ring). */
    public Geo hexRing(Vec3 centre, Vec3 normal, double radius, double halfWidth, double phase) {
        return ring(centre, normal, radius, halfWidth, 6, phase, false);
    }

    /** A hexagonal crystal: two six-sided pyramids joined at the middle, pointing along {@code axis}. */
    public Geo crystal(Vec3 centre, Vec3 axis, double radius, double halfLength, double phase) {
        Vec3 ax = axis.lengthSqr() < 1e-9 ? new Vec3(0, 1, 0) : axis.normalize();
        Vec3[] uv = basis(ax);
        Vec3 top = centre.add(ax.scale(halfLength)), bottom = centre.subtract(ax.scale(halfLength));
        Vec3[] ring = new Vec3[6];
        for (int i = 0; i < 6; i++) {
            double a = phase + Math.PI / 3.0 * i;
            ring[i] = centre.add(uv[0].scale(Math.cos(a) * radius)).add(uv[1].scale(Math.sin(a) * radius));
        }
        for (int i = 0; i < 6; i++) {
            Vec3 p0 = ring[i], p1 = ring[(i + 1) % 6];
            tri(top, p0, p1);
            tri(bottom, p1, p0);
        }
        return this;
    }

    /** A feather-shaped kite: from {@code base} to {@code tip}, widest at 35% of its length. */
    public Geo kite(Vec3 base, Vec3 tip, Vec3 side, double width) {
        Vec3 d = tip.subtract(base);
        Vec3 mid = base.add(d.scale(0.35));
        quad(base, mid.add(side.scale(width)), tip, mid.subtract(side.scale(width)));
        return this;
    }

    private static Vec3 point(Vec3 c, double radius, double theta, double phi) {
        return c.add(radius * Math.sin(theta) * Math.cos(phi), radius * Math.cos(theta), radius * Math.sin(theta) * Math.sin(phi));
    }

    // ------------------------------------------------------------------ extra shapes

    /** Rotates (x, z) around the vertical axis by {@code yaw} (radians) and adds it to {@code at}. */
    static Vec3 yawed(Vec3 at, double x, double y, double z, double yaw) {
        double c = Math.cos(yaw), s = Math.sin(yaw);
        return at.add(x * c - z * s, y, x * s + z * c);
    }

    /** A solid box (6 faces), turned by {@code yaw} around its vertical centre line. */
    public Geo cuboid(Vec3 centre, double hx, double hy, double hz, double yaw) {
        Vec3[] p = new Vec3[8];
        for (int i = 0; i < 8; i++) p[i] = yawed(centre, (i & 1) == 0 ? -hx : hx, (i & 2) == 0 ? -hy : hy, (i & 4) == 0 ? -hz : hz, yaw);
        quad(p[0], p[1], p[3], p[2]); quad(p[4], p[5], p[7], p[6]);
        quad(p[0], p[1], p[5], p[4]); quad(p[2], p[3], p[7], p[6]);
        quad(p[0], p[2], p[6], p[4]); quad(p[1], p[3], p[7], p[5]);
        return this;
    }

    /** The edges of an axis-aligned box as thin beams (a wireframe). */
    public Geo wireBox(Vec3 min, Vec3 max, double width) {
        double[] xs = {min.x, max.x}, ys = {min.y, max.y}, zs = {min.z, max.z};
        for (double y : ys) for (double z : zs) ribbon(new Vec3(xs[0], y, z), new Vec3(xs[1], y, z), width);
        for (double x : xs) for (double z : zs) ribbon(new Vec3(x, ys[0], z), new Vec3(x, ys[1], z), width);
        for (double x : xs) for (double y : ys) ribbon(new Vec3(x, y, zs[0]), new Vec3(x, y, zs[1]), width);
        return this;
    }

    /**
     * A person-shaped silhouette of boxes (legs, body, arms, head) standing at {@code feet}, facing Minecraft yaw
     * {@code yawDeg} - used for afterimages and future images.
     */
    public Geo humanoid(Vec3 feet, double yawDeg, double scale) {
        double yaw = Math.toRadians(-yawDeg);
        double s = scale;
        cuboid(yawed(feet, -0.12 * s, 0.375 * s, 0, yaw), 0.12 * s, 0.375 * s, 0.12 * s, yaw);
        cuboid(yawed(feet, 0.12 * s, 0.375 * s, 0, yaw), 0.12 * s, 0.375 * s, 0.12 * s, yaw);
        cuboid(yawed(feet, 0, 1.12 * s, 0, yaw), 0.24 * s, 0.37 * s, 0.13 * s, yaw);
        cuboid(yawed(feet, -0.36 * s, 1.12 * s, 0, yaw), 0.11 * s, 0.36 * s, 0.11 * s, yaw);
        cuboid(yawed(feet, 0.36 * s, 1.12 * s, 0, yaw), 0.11 * s, 0.36 * s, 0.11 * s, yaw);
        cuboid(yawed(feet, 0, 1.73 * s, 0, yaw), 0.23 * s, 0.23 * s, 0.23 * s, yaw);
        return this;
    }

    /** An upright tongue of flame: a crossed pair of kites from {@code base} up to {@code height}, leaning by {@code lean}. */
    public Geo flame(Vec3 base, double height, double width, Vec3 lean, double phase) {
        Vec3 tip = base.add(lean.x, height, lean.z);
        double sway = Math.sin(phase) * 0.18 * height;
        tip = tip.add(sway, 0, Math.cos(phase * 1.3) * 0.12 * height);
        kite(base, tip, new Vec3(1, 0, 0), width);
        kite(base, tip, new Vec3(0, 0, 1), width);
        return this;
    }

    /** A line made of dashes (data links), the dashes sliding along with {@code phase}. */
    public Geo dashed(Vec3 from, Vec3 to, double width, double dash, double phase) {
        Vec3 d = to.subtract(from);
        double len = d.length();
        if (len < 1e-6) return this;
        Vec3 u = d.scale(1 / len);
        double start = -((phase % (dash * 2) + dash * 2) % (dash * 2));
        for (double s = start; s < len; s += dash * 2) {
            double a = Math.max(0, s), b = Math.min(len, s + dash);
            if (b > a) ribbon(from.add(u.scale(a)), from.add(u.scale(b)), width);
        }
        return this;
    }

    /** The camera position this Geo draws for (to turn shapes towards the viewer). */
    public Vec3 cam() { return new Vec3(cx, cy, cz); }

    /** A flat disc that always faces the camera (glows, smoke puffs, embers). */
    public Geo facing(Vec3 centre, double radius, int segments) {
        Vec3 n = cam().subtract(centre);
        return disc(centre, n.lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : n, radius, segments);
    }

    // ------------------------------------------------------------------ smooth colour (one colour per corner)

    private void cv(Vec3 p, int argb, float fade) {
        float al = ((argb >>> 24) & 255) / 255f * alphaScale * fade;
        out.vertex(pose, (float) (p.x - cx), (float) (p.y - cy), (float) (p.z - cz))
                .color(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, al).endVertex();
    }

    /** A four-cornered shape with its own ARGB colour per corner (colours blend smoothly across it), both sides. */
    public Geo gquad(Vec3 p1, int c1, Vec3 p2, int c2, Vec3 p3, int c3, Vec3 p4, int c4) {
        float fade = 1f;
        if (nearFade > 0) {
            double mx = (p1.x + p3.x) * 0.5 - cx, my = (p1.y + p3.y) * 0.5 - cy, mz = (p1.z + p3.z) * 0.5 - cz;
            double d2 = mx * mx + my * my + mz * mz;
            if (d2 < nearFade * nearFade) {
                double f = Math.sqrt(d2) / nearFade;
                fade = (float) (f * f);
                if (fade < 0.004f) return this;
            }
        }
        cv(p1, c1, fade); cv(p2, c2, fade); cv(p3, c3, fade); cv(p4, c4, fade);
        cv(p4, c4, fade); cv(p3, c3, fade); cv(p2, c2, fade); cv(p1, c1, fade);
        return this;
    }

    /** A soft round glow: {@code inner} colour at the centre fading to {@code outer} at the rim (use alpha 0 there). */
    public Geo softDisc(Vec3 centre, Vec3 normal, double radius, int segments, int inner, int outer) {
        Vec3[] uv = basis(normal);
        segments = seg(segments);
        for (int i = 0; i < segments; i++) {
            double a0 = Math.PI * 2.0 * i / segments, a1 = Math.PI * 2.0 * (i + 1) / segments;
            Vec3 e0 = centre.add(uv[0].scale(Math.cos(a0) * radius)).add(uv[1].scale(Math.sin(a0) * radius));
            Vec3 e1 = centre.add(uv[0].scale(Math.cos(a1) * radius)).add(uv[1].scale(Math.sin(a1) * radius));
            gquad(centre, inner, centre, inner, e1, outer, e0, outer);
        }
        return this;
    }

    /** A soft glow that always faces the camera. */
    public Geo softFacing(Vec3 centre, double radius, int segments, int inner, int outer) {
        Vec3 n = cam().subtract(centre);
        return softDisc(centre, n.lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : n, radius, segments, inner, outer);
    }
}
