package dev.toaru.dimmanip.client;

import dev.toaru.dimmanip.DimManip;
import dev.toaru.dimmanip.net.FxType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The film frame: black bars slide in while Inception's land rises and again as it slams down (for everyone inside it), and
 * the edges of sight darken and bleed red, with a slow heartbeat, inside Inception or with a bent view.
 */
@Mod.EventBusSubscriber(modid = DimManip.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class Cinema {
    private Cinema() { }

    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || ClientFx.ACTIVE.isEmpty()) return;
        long now = mc.level.getGameTime();
        float pt = event.getPartialTick();
        GuiGraphics g = event.getGuiGraphics();
        int w = event.getWindow().getGuiScaledWidth(), h = event.getWindow().getGuiScaledHeight();
        // Letterbox: how far in the bars are (0..1).
        double bars = 0;
        for (ClientFx.Effect e : ClientFx.ACTIVE.values()) {
            if (e.type != FxType.INCEPTION || mc.player.position().distanceTo(e.pos) > e.power + 10) continue;
            double age = e.age(now, pt), slam = e.c + 30;
            // As the land rises, and again as it comes down.
            bars = Math.max(bars, Fxu.smooth(age / 8) * Fxu.smooth((e.b + 30 - age) / 15));
            bars = Math.max(bars, Fxu.smooth((age - e.c + 10) / 10) * Fxu.smooth((slam + 30 - age) / 15));
        }
        if (bars > 0.01) {
            int bh = (int) Math.round(h * 0.11 * bars);
            g.fill(0, 0, w, bh, 0xFF000000);
            g.fill(0, h - bh, w, h, 0xFF000000);
        }
        // Inside Inception or with a bent view: the edges of sight darken and bleed red, breathing slowly.
        double dread = 0;
        for (ClientFx.Effect e : ClientFx.ACTIVE.values()) {
            if (e.type != FxType.INCEPTION || mc.player.position().distanceTo(e.pos) > e.power + 2) continue;
            double age = e.age(now, pt);
            dread = Math.max(dread, Fxu.env(age, e.c + 40, 20, 20) * 0.75);
        }
        ClientFx.Effect p = ClientEvents.stolen();
        double wob = 0;
        if (p != null) {
            double age = p.age(now, pt);
            dread = Math.max(dread, Fxu.env(age, p.duration, 6, 10) * Math.max(0.3f, p.power));
            wob = age;
        }
        if (dread > 0.01) {
            double beat = 0.85 + 0.15 * Math.pow(Math.abs(Math.sin((now + pt) * 0.08)), 6);
            int steps = 10, ew = (int) (w * 0.16), eh = (int) (h * 0.16);
            for (int i = 0; i < steps; i++) {
                double f = 1 - i / (double) steps;
                int a = (int) (dread * beat * 150 * f * f);
                int color = (a << 24) | (i < steps / 2 ? 0x000000 : 0x2A0006);
                int x = i * ew / steps, y = i * eh / steps, sx = (int) (3 * Math.sin(wob * 0.2));
                g.fill(0, y, w, y + eh / steps, color);
                g.fill(0, h - y - eh / steps, w, h - y, color);
                g.fill(x + sx, 0, x + sx + ew / steps, h, color);
                g.fill(w - x - ew / steps - sx, 0, w - x - sx, h, color);
            }
        }
    }
}
