package dev.toaru.dimmanip.net;

/**
 * Every visual effect, as small numbers sent to clients (pos, aux, a, b, c, power, duration). The client draws each one
 * as geometry (no particles) and lets it expire. a is usually the entity it belongs to.
 */
public enum FxType {
    // shared
    SHOCK, RING, SCREEN,
    // Spatial Registration: an enemy outlined for the esper; the step through space that dodges a hit
    SENSE, SHIFT,
    // the moves (the ones that bend the ground use copies of the real terrain)
    ATLAS, REND, SKY_RIP, HORIZON, REGRESS, INVERT, SHATTER, INCEPTION, ECHO,
    // Pocket Universe: the cube left behind, the tunnel inside, the swaying view inside (sent to each of them)
    POCKET, PSY, POCKET_VIEW,
    // a view bent out of true (sent to the one player)
    PERSPECTIVE,
    // the esper's own body while a move is cast (a = who, b = which movement)
    CAST,
    // Tesseract's cube; Gravity Well (a = whose look is 'down'); Kaleidoscope (a = who is mirrored)
    TESS, GRAVITY, KALEIDO
}
