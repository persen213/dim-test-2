package dev.toaru.dimmanip;


import java.lang.reflect.Method;
import java.util.function.BooleanSupplier;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.common.capabilities.Capability;

/**
 * The few things this add-on needs that Re:AcademyCraft's public add-on API does not offer: whether a player has an
 * ability (an AIM field), their level, and Re:AcademyCraft's own interference (the mechanism its Ability Interferer
 * block uses: while it lasts, Re:AcademyCraft itself refuses and stops that player's abilities and shows it on their
 * screen). Reached by name through reflection, the same way Esper Roll reads the ability list. Checked once; if a future
 * Re:AcademyCraft version renames anything, every call here simply reports "unknown" and the moves fall back to
 * ordinary slowness and weakness instead (logged once, never a crash).
 */
public final class AcBridge {
    private AcBridge() { }

    private static boolean tried, ok;
    private static Object cap;
    private static Method hasAbility, getLevel, addInterference, getAbility, getProficiency;

    private static synchronized void init() {
        if (tried) return;
        tried = true;
        try {
            Class<?> caps = Class.forName("io.github.pinchan4273.reacademycraft.capability.AbilityCapabilities");
            cap = caps.getField("PLAYER_ABILITY").get(null);
            Class<?> data = Class.forName("io.github.pinchan4273.reacademycraft.skill.PlayerAbilityData");
            hasAbility = data.getMethod("hasAbility");
            getLevel = data.getMethod("getLevel");
            addInterference = data.getMethod("addInterference", String.class, BooleanSupplier.class);
            try { getAbility = data.getMethod("getAbility"); } catch (Throwable t) { getAbility = null; }
            try { getProficiency = data.getMethod("getProficiency", net.minecraft.resources.ResourceLocation.class); } catch (Throwable t) { getProficiency = null; }
            ok = cap instanceof Capability<?>;
        } catch (Throwable t) {
            DimManip.LOGGER.warn("Dimension Manipulation: Re:AcademyCraft's ability data could not be read; the category check and ability blocking are unavailable ({})", t.toString());
        }
    }

    @SuppressWarnings("unchecked")
    private static @Nullable Object data(ServerPlayer p) {
        init();
        if (!ok) return null;
        try {
            return p.getCapability((Capability<Object>) cap).resolve().orElse(null);
        } catch (Throwable t) {
            return null;
        }
    }

    /** True / false if known; null if it cannot be read. */
    public static @Nullable Boolean esper(ServerPlayer p) {
        Object d = data(p);
        if (d == null) return null;
        try { return (Boolean) hasAbility.invoke(d); } catch (Throwable t) { return null; }
    }

    /** The player's ability level 1..5, or 0 if unknown. */
    public static int level(ServerPlayer p) {
        Object d = data(p);
        if (d == null) return 0;
        try { return (Integer) getLevel.invoke(d); } catch (Throwable t) { return 0; }
    }

    /** Re:AcademyCraft interference on {@code p} while {@code lasts} is true. False if it could not be applied. */
    public static boolean interfere(ServerPlayer p, String id, BooleanSupplier lasts) {
        Object d = data(p);
        if (d == null) return false;
        try { addInterference.invoke(d, id, lasts); return true; } catch (Throwable t) { return false; }
    }

    /** The player's Re:AcademyCraft category id ("modid:path"), or null if unknown. */
    public static @Nullable String category(ServerPlayer p) {
        Object d = data(p);
        if (d == null || getAbility == null) return null;
        try { Object id = getAbility.invoke(d); return id == null ? null : id.toString(); } catch (Throwable t) { return null; }
    }

    /** How well the player has mastered a skill (0..1), or -1 if it can't be read. Read only. */
    public static float proficiency(ServerPlayer p, String skillId) {
        Object d = data(p);
        if (d == null || getProficiency == null) return -1;
        try {
            Object v = getProficiency.invoke(d, new net.minecraft.resources.ResourceLocation(skillId));
            return v instanceof Float f ? f : -1;
        } catch (Throwable t) { return -1; }
    }

    private static long skillsReadAt = -1;
    private static java.util.Map<String, java.util.Set<String>> skillsByCategory = java.util.Map.of();

    /**
     * Every skill of every category, as Re:AcademyCraft lists them (its skill catalog and the add-on registry), read once
     * a minute. Read only; empty if neither can be read.
     */
    public static synchronized java.util.Map<String, java.util.Set<String>> skills() {
        long now = System.currentTimeMillis();
        if (skillsReadAt >= 0 && now - skillsReadAt < 60_000) return skillsByCategory;
        skillsReadAt = now;
        java.util.Map<String, java.util.Set<String>> out = new java.util.HashMap<>();
        try {
            Class<?> cat = Class.forName("io.github.pinchan4273.reacademycraft.skill.SkillCatalog");
            for (Object def : (java.util.List<?>) cat.getField("IMPLEMENTED").get(null)) {
                Object id = def.getClass().getMethod("id").invoke(def), c = def.getClass().getMethod("category").invoke(def);
                if (id != null && c != null) out.computeIfAbsent(c.toString(), k -> new java.util.TreeSet<>()).add(id.toString());
            }
        } catch (Throwable t) {
            DimManip.LOGGER.debug("Dimension Manipulation: skill catalog not readable ({})", t.toString());
        }
        try {
            Class<?> reg = Class.forName("io.github.pinchan4273.reacademycraft.ability.AbilityRegistry");
            Object inst = reg.getField("INSTANCE").get(null);
            for (Object def : (java.util.List<?>) reg.getMethod("skills").invoke(inst)) {
                Object id = def.getClass().getMethod("id").invoke(def), c = def.getClass().getMethod("category").invoke(def);
                if (id != null && c != null) out.computeIfAbsent(c.toString(), k -> new java.util.TreeSet<>()).add(id.toString());
            }
        } catch (Throwable t) {
            DimManip.LOGGER.debug("Dimension Manipulation: add-on skill registry not readable ({})", t.toString());
        }
        skillsByCategory = out;
        return out;
    }
}
