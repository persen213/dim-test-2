package dev.toaru.dimmanip.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.toaru.dimmanip.DimManip;
import dev.toaru.dimmanip.net.FxType;
import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The client side: effects expire, and what Dimension Manipulation does to one player's own view - Perspective Theft's
 * tilt, warped depth, wrong sizes and the esper drawn where they aren't, and Upside Down's turned world. Only the view
 * changes; every real position and hitbox stays where the server has it.
 */
@Mod.EventBusSubscriber(modid = DimManip.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() { }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) ClientFx.tick();
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) { ClientFx.clear(); roll = 0; }

    /** This player's running Perspective Theft (sent to them only), or null. */
    static ClientFx.Effect stolen() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return null;
        ClientFx.Effect e = ClientFx.any(FxType.PERSPECTIVE);
        return e != null && e.live(mc.level.getGameTime()) ? e : null;
    }

    // ------------------------------------------------------------------ the view: tilt, roll and shake
    private static double roll;

    /** How hard each big effect shakes the view when it lands near you. */
    static double shakeOf(FxType t) {
        return switch (t) {
            case INCEPTION -> 2.6;
            case SHATTER -> 1.6;
            case HORIZON -> 1.4;
            case REND -> 1.0;
            case ATLAS -> 0.5;
            default -> 0;
        };
    }

    static double landOf(ClientFx.Effect e) {
        return switch (e.type) {
            case INCEPTION -> e.c + 30;
            case SHATTER -> e.b + e.c;
            case HORIZON, REND, ATLAS -> e.b;
            default -> 0;
        };
    }

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer me = mc.player;
        if (mc.level == null || me == null) return;
        long now = mc.level.getGameTime();
        float pt = (float) event.getPartialTick();
        double t = now + pt;
        double target = 0;
        // Pocket Universe: inside the tunnel the world sways and rolls slowly, never quite level.
        ClientFx.Effect pv = ClientFx.any(FxType.POCKET_VIEW);
        if (pv != null && pv.live(now)) {
            double age = pv.age(now, pt);
            float k = Fxu.env(age, pv.duration, 10, 10) * Math.max(0.1f, pv.power);
            target += k * (30 * Math.sin(age * 0.045) + 8 * Math.sin(age * 0.13));
        }
        // Perspective Theft: the horizon will not stay level.
        ClientFx.Effect p = stolen();
        if (p != null) {
            double age = p.age(now, pt);
            float k = Fxu.env(age, p.duration, 6, 10) * Math.max(0.2f, p.power);
            target += k * (24 * Math.sin(age * 0.11) * (p.b < 0 ? -1 : 1) + 6 * Math.sin(age * 0.37));
        }
        roll += (target - roll) * 0.12;
        if (Math.abs(roll) < 0.01 && target == 0) roll = 0;
        double shake = 0;
        for (ClientFx.Effect e : ClientFx.ACTIVE.values()) {
            double s = shakeOf(e.type);
            if (s <= 0) continue;
            double since = e.age(now, pt) - landOf(e);
            if (since < 0 || since > 14) continue;
            double dist = me.position().distanceTo(e.pos), reach = 12 + 6 * s;
            if (dist > reach) continue;
            shake = Math.max(shake, s * (1 - since / 14) * (1 - dist / reach));
        }
        event.setRoll((float) (event.getRoll() + roll + Math.sin(t * 1.9) * shake * 0.6));
        if (shake > 0.01) {
            event.setYaw((float) (event.getYaw() + Math.sin(t * 2.7) * shake));
            event.setPitch((float) (event.getPitch() + Math.cos(t * 3.3) * shake * 0.8));
        }
    }

    /** Perspective Theft: near things look far and far things near - the field of view breathing in and out. */
    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        long now = mc.level.getGameTime();
        float pt = (float) event.getPartialTick();
        double fov = event.getFOV();
        ClientFx.Effect p = stolen();
        if (p != null) {
            double age = p.age(now, pt);
            float k = Fxu.env(age, p.duration, 6, 10) * Math.max(0.2f, p.power);
            fov *= 1 + 0.38 * k * Math.sin(age * 0.09);
        }
        ClientFx.Effect pv = ClientFx.any(FxType.POCKET_VIEW);
        if (pv != null && pv.live(now)) {
            double age = pv.age(now, pt);
            float k = Fxu.env(age, pv.duration, 10, 10) * Math.max(0.1f, pv.power);
            fov *= 1 + 0.3 * k * Math.sin(age * 0.06);
        }
        // Inception: the view draws in as the land rises, and is thrown wide when it slams shut.
        for (ClientFx.Effect e : ClientFx.ACTIVE.values()) {
            if (e.type != FxType.INCEPTION || mc.player.position().distanceTo(e.pos) > e.power + 10) continue;
            double age = e.age(now, pt), slam = e.c + 30;
            if (age < e.b + 10) fov *= 1 + 0.12 * Math.sin(Math.PI * Math.min(1, age / (e.b + 10)));
            if (age > e.c && age < slam) fov *= 1 - 0.12 * Fxu.smooth((age - e.c) / 30);
            if (age >= slam && age < slam + 16) fov *= 1 + 0.3 * Math.exp(-(age - slam) * 0.25);
        }
        event.setFOV(fov);
    }

    // ------------------------------------------------------------------ bodies drawn in the wrong place or size
    private static final Deque<Boolean> PUSHED = new ArrayDeque<>();

    /** The cast movement running for this entity, or null. */
    static ClientFx.Effect casting(LivingEntity e, long now) {
        for (ClientFx.Effect c : ClientFx.ACTIVE.values()) if (c.type == FxType.CAST && c.a == e.getId() && c.live(now)) return c;
        return null;
    }

    private static final java.util.Set<Long> SWUNG = new java.util.HashSet<>();

    /** The esper's arms while a move is cast: thrust out, thrown up, held out - then brought down. */
    @SubscribeEvent
    public static void onPlayerPre(net.minecraftforge.client.event.RenderPlayerEvent.Pre event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || !(event.getEntity() instanceof LivingEntity e)) return;
        ClientFx.Effect c = casting(e, mc.level.getGameTime());
        if (c == null) return;
        double t = c.age(mc.level.getGameTime(), event.getPartialTick()) / Math.max(1, c.duration);
        net.minecraft.client.model.HumanoidModel<?> m = event.getRenderer().getModel();
        net.minecraft.client.model.HumanoidModel.ArmPose up = net.minecraft.client.model.HumanoidModel.ArmPose.THROW_SPEAR;
        net.minecraft.client.model.HumanoidModel.ArmPose out = net.minecraft.client.model.HumanoidModel.ArmPose.BOW_AND_ARROW;
        net.minecraft.client.model.HumanoidModel.ArmPose hold = net.minecraft.client.model.HumanoidModel.ArmPose.BLOCK;
        double strike = c.b == 1 ? 0.55 : c.b == 4 ? 0.6 : c.b == 6 ? 0.88 : 2;
        switch (c.b) {
            case 0 -> { m.rightArmPose = out; m.leftArmPose = out; }
            case 1 -> { if (t < strike) m.rightArmPose = up; }
            case 2 -> { m.rightArmPose = hold; if (t > 0.5) m.leftArmPose = hold; }
            case 3 -> { if (t < 0.85) { m.rightArmPose = up; m.leftArmPose = up; } }
            case 4, 6 -> { if (t < strike) { m.rightArmPose = up; m.leftArmPose = up; } }
            default -> { }
        }
        // The arm comes down as the move lands.
        if (t >= strike && SWUNG.add(c.key)) {
            if (SWUNG.size() > 256) { SWUNG.clear(); SWUNG.add(c.key); }
            e.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
        }
    }

    /** How the whole body moves with the cast: leaning into it, lifting off the ground, turning. */
    static void castBody(PoseStack s, LivingEntity e, ClientFx.Effect c, double age, float pt) {
        double t = age / Math.max(1, c.duration);
        double env = Fxu.env(age, c.duration, 4, 6);
        double lift = 0, lean = 0, spin = 0;
        switch (c.b) {
            case 0 -> lean = 0.32 * env;
            case 1 -> lean = t < 0.55 ? -0.28 * Fxu.smooth(t / 0.3) : -0.28 + 0.75 * Fxu.smooth((t - 0.55) / 0.15) * env;
            case 2 -> { lift = 0.3 * env + 0.05 * Math.sin(age * 0.25) * env; lean = -0.08 * env; }
            case 3 -> { lift = 0.55 * env; lean = -0.2 * env; }
            case 4 -> {
                lift = t < 0.6 ? 0.7 * Fxu.smooth(t / 0.4) : 0.7 * (1 - Fxu.smooth((t - 0.6) / 0.12));
                lean = t < 0.6 ? -0.25 * Fxu.smooth(t / 0.4) : (-0.25 + 0.8 * Fxu.smooth((t - 0.6) / 0.12)) * env;
            }
            case 6 -> { lift = 1.5 * env + 0.08 * Math.sin(age * 0.2) * env; lean = -0.22 * env; spin = Math.PI * 2 * Fxu.smooth(t); }
            default -> { }
        }
        float yaw = (float) Math.toRadians(e.yBodyRotO + (e.yBodyRot - e.yBodyRotO) * pt);
        s.translate(0, lift, 0);
        s.mulPose(com.mojang.math.Axis.YP.rotation((float) spin - yaw));
        s.translate(0, 0.9, 0);
        s.mulPose(com.mojang.math.Axis.XP.rotation((float) lean));
        s.translate(0, -0.9, 0);
        s.mulPose(com.mojang.math.Axis.YP.rotation(yaw));
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingPre(RenderLivingEvent.Pre<?, ?> event) {
        if (event.isCanceled()) return;
        ClientFx.Effect p = stolen();
        Minecraft mc = Minecraft.getInstance();
        LivingEntity e = event.getEntity();
        ClientFx.Effect cast = mc.level == null ? null : casting(e, mc.level.getGameTime());
        boolean bent = p != null && mc.level != null && e != mc.player;
        if (!bent && cast == null) { PUSHED.push(false); return; }
        PoseStack s = event.getPoseStack();
        s.pushPose();
        if (cast != null) castBody(s, e, cast, cast.age(mc.level.getGameTime(), event.getPartialTick()), event.getPartialTick());
        if (bent) {
            double age = p.age(mc.level.getGameTime(), event.getPartialTick());
            float k = Fxu.env(age, p.duration, 6, 10) * Math.max(0.2f, p.power);
            if (p.a >= 0 && e.getId() == p.a) {
                // The esper is shown where they aren't.
                s.translate(p.aux.x * k, p.aux.y * k, p.aux.z * k);
            } else {
                // Everything else the wrong size.
                float sc = (float) (1 + k * 0.45 * (Fxu.hash(e.getId() * 31L) * 2 - 1) * (0.7 + 0.3 * Math.sin(age * 0.07 + e.getId())));
                s.scale(sc, sc, sc);
            }
        }
        PUSHED.push(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLivingPost(RenderLivingEvent.Post<?, ?> event) {
        if (PUSHED.isEmpty()) return;
        if (PUSHED.pop()) event.getPoseStack().popPose();
    }
}
