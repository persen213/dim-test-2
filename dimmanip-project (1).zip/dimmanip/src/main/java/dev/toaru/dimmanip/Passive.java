package dev.toaru.dimmanip;

import dev.toaru.dimmanip.net.Fx;
import dev.toaru.dimmanip.net.FxType;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;

/**
 * Spatial Registration, the passive: once a second every creature within range is outlined for the esper alone, through
 * walls. Nothing is drawn on the esper themselves (it would only get in the way in first person).
 */
public final class Passive {
    private Passive() { }

    private static final Map<UUID, Long> READ_AT = new HashMap<>();
    private static final Map<UUID, Boolean> IS = new HashMap<>();

    /** Is this player a Dimension Manipulation esper (read from Re:AcademyCraft every two seconds)? */
    public static boolean is(ServerPlayer p) {
        long now = p.level().getGameTime();
        Long at = READ_AT.get(p.getUUID());
        if (at == null || now - at >= 40 || now < at) {
            READ_AT.put(p.getUUID(), now);
            IS.put(p.getUUID(), (DimManip.MOD_ID + ":" + DimManip.CATEGORY).equals(AcBridge.category(p)));
        }
        return IS.getOrDefault(p.getUUID(), false);
    }

    public static void tick(ServerPlayer p) {
        if (p.tickCount % 20 != 0 || !is(p)) return;
        double r = Cfg.of("spatial_registration").v("range");
        int n = 0;
        for (LivingEntity e : Targeting.livingWithin(p.serverLevel(), p.position(), r, p)) {
            if (e instanceof ArmorStand) continue;
            Fx.make(p.serverLevel(), e.position(), FxType.SENSE, 26).a(e.getId()).sendTo(p);
            if (++n >= 16) break;
        }
    }

    /**
     * A hit about to land on the esper: once every few seconds it slides off as they shift a step through space, sideways
     * to the blow. Returns true if the hit is dodged.
     */
    public static boolean dodge(ServerPlayer p, net.minecraft.world.damagesource.DamageSource src) {
        if (!(src.getEntity() instanceof LivingEntity att) || att == p || Hit.busy() || !is(p) || Status.has(p, "dm_shift_cd")) return false;
        Cfg.Mv m = Cfg.of("spatial_registration");
        net.minecraft.world.phys.Vec3 from = p.position(), d = p.position().subtract(att.position());
        net.minecraft.world.phys.Vec3 side = new net.minecraft.world.phys.Vec3(-d.z, 0, d.x);
        side = side.lengthSqr() < 1e-6 ? new net.minecraft.world.phys.Vec3(1, 0, 0) : side.normalize();
        if (p.getRandom().nextBoolean()) side = side.scale(-1);
        net.minecraft.world.phys.Vec3 to = Common.safeAlong(p.serverLevel(), p, side, m.v("shift_distance"));
        if (to == null) return false;
        Status.set(p, "dm_shift_cd", m.ticks("dodge_cooldown_seconds"));
        p.teleportTo(p.serverLevel(), to.x, to.y, to.z, p.getYRot(), p.getXRot());
        Fx.make(p.serverLevel(), from, FxType.SHIFT, 16).a(p.getId()).aux(to).power(p.getYRot()).range(96).send();
        Snd.at(p.serverLevel(), from, net.minecraft.sounds.SoundEvents.ENDERMAN_TELEPORT, 0.6f, 1.8f);
        return true;
    }

    private static final Map<UUID, Boolean> SNEAKING = new HashMap<>();
    private static final Map<UUID, Long> TAPPED = new HashMap<>();

    /** Folded Step: tap sneak twice quickly and the esper steps through a fold in space, a few blocks the way they look. */
    public static void step(ServerPlayer p) {
        boolean down = p.isShiftKeyDown();
        boolean was = SNEAKING.getOrDefault(p.getUUID(), false);
        SNEAKING.put(p.getUUID(), down);
        if (!down || was) return;
        long now = p.level().getGameTime();
        Long last = TAPPED.put(p.getUUID(), now);
        if (last == null || now - last > 8 || now < last) return;
        TAPPED.remove(p.getUUID());
        if (!is(p) || Status.has(p, "dm_step_cd") || Status.has(p, "dm_burnout") || p.isPassenger()) return;
        Cfg.Mv m = Cfg.of("spatial_registration");
        net.minecraft.world.phys.Vec3 look = p.getLookAngle();
        net.minecraft.world.phys.Vec3 dir = new net.minecraft.world.phys.Vec3(look.x, 0, look.z);
        if (dir.lengthSqr() < 1e-6) return;
        net.minecraft.world.phys.Vec3 from = p.position(), to = Common.safeAlong(p.serverLevel(), p, dir.normalize(), m.v("step_distance"));
        if (to == null || to.distanceToSqr(from) < 1) return;
        Status.set(p, "dm_step_cd", m.ticks("step_cooldown_seconds"));
        p.teleportTo(p.serverLevel(), to.x, to.y, to.z, p.getYRot(), p.getXRot());
        p.fallDistance = 0;
        Fx.make(p.serverLevel(), from, FxType.SHIFT, 16).a(p.getId()).aux(to).power(p.getYRot()).range(96).send();
        Snd.at(p.serverLevel(), from, net.minecraft.sounds.SoundEvents.ENDERMAN_TELEPORT, 0.6f, 1.5f);
    }

    public static void forget(UUID id) { READ_AT.remove(id); IS.remove(id); SNEAKING.remove(id); TAPPED.remove(id); }
}
