package dev.toaru.dimmanip.client;

import dev.toaru.dimmanip.net.FxStartMsg;
import dev.toaru.dimmanip.net.FxType;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/**
 * Running visual effects on this client: plain data, drawn by WorldRenderer, the HUD and the body layer, removed when
 * their time is up (capped), plus what this player's evolution bar shows.
 */
public final class ClientFx {
    private ClientFx() { }

    private static final int MAX = 200;
    static final Map<Long, Effect> ACTIVE = new LinkedHashMap<>();

    public static final class Effect {
        public final long key;
        public final FxType type;
        public final long start;
        public final int duration;
        public final Vec3 pos, aux;
        public final int a, b, c;
        public final float power;

        Effect(FxStartMsg m, long start) {
            this.key = m.key; this.type = m.type; this.start = start; this.duration = m.duration;
            this.pos = new Vec3(m.x, m.y, m.z); this.aux = new Vec3(m.ax, m.ay, m.az);
            this.a = m.a; this.b = m.b; this.c = m.c; this.power = m.power;
        }

        public double age(long now, float partial) { return (now - start) + partial; }
        public boolean live(long now) { return now - start <= duration; }
    }

    static void start(FxStartMsg msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        ACTIVE.put(msg.key, new Effect(msg, mc.level.getGameTime()));
        if (ACTIVE.size() > MAX) {
            Iterator<Long> it = ACTIVE.keySet().iterator();
            it.next();
            it.remove();
        }
    }

    static void cancel(long key) { ACTIVE.remove(key); }

    /** The newest running effect of this type whose field a is this entity, or null. */
    static @Nullable Effect of(int entity, FxType type) {
        Effect best = null;
        for (Effect e : ACTIVE.values()) if (e.type == type && e.a == entity && (best == null || e.start >= best.start)) best = e;
        return best;
    }

    /** The newest running effect of this type, or null. */
    static @Nullable Effect any(FxType type) {
        Effect best = null;
        for (Effect e : ACTIVE.values()) if (e.type == type && (best == null || e.start >= best.start)) best = e;
        return best;
    }

    static void clear() { ACTIVE.clear(); }

    static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) { clear(); return; }
        long now = mc.level.getGameTime();
        if (!ACTIVE.isEmpty()) ACTIVE.values().removeIf(e -> now - e.start > e.duration + 2 || now < e.start - 40);
    }
}
