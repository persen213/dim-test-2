package dev.toaru.dimmanip;

import net.minecraft.world.phys.Vec3;

/**
 * Pure geometry shared by the server (which moves things) and the client (which draws them), so both always agree:
 * flat rectangles of space (Room 404's surfaces, Hall of Doors' doors) and the pieces of Space Jigsaw.
 */
public final class Space {
    private Space() { }

    public static final Vec3 UP = new Vec3(0, 1, 0);

    /** A flat rectangle: centre c, outward normal n, width axis u, height axis v, half sizes. */
    public record Rect(Vec3 c, Vec3 n, Vec3 u, Vec3 v, double hw, double hh) {
        public Vec3 local(Vec3 p) { Vec3 d = p.subtract(c); return new Vec3(d.dot(u), d.dot(v), d.dot(n)); }
        public Vec3 world(Vec3 l) { return c.add(u.scale(l.x)).add(v.scale(l.y)).add(n.scale(l.z)); }
        public Vec3 dirLocal(Vec3 w) { return new Vec3(w.dot(u), w.dot(v), w.dot(n)); }
        public Vec3 dirWorld(Vec3 l) { return u.scale(l.x).add(v.scale(l.y)).add(n.scale(l.z)); }
        public boolean inside(Vec3 l, double margin) { return Math.abs(l.x) <= hw + margin && Math.abs(l.y) <= hh + margin; }

        /** A rectangle facing n, with v as its "up" (kept square to n). */
        public static Rect of(Vec3 c, Vec3 n, Vec3 up, double hw, double hh) {
            Vec3 nn = n.normalize();
            Vec3 v = up.subtract(nn.scale(up.dot(nn)));
            if (v.lengthSqr() < 1e-6) v = Math.abs(nn.y) > 0.9 ? new Vec3(0, 0, 1) : UP;
            v = v.normalize();
            Vec3 u = v.cross(nn).normalize();
            return new Rect(c, nn, u, v, hw, hh);
        }
    }

    // ------------------------------------------------------------------ Space Jigsaw
    public static double hash(long i) {
        long x = i * 0x9E3779B97F4A7C15L;
        x ^= x >>> 31; x *= 0xBF58476D1CE4E5B9L; x ^= x >>> 29;
        return (x >>> 11) * 0x1.0p-53;
    }

    /** Which piece a point belongs to (pieces are slices round the centre). */
    public static int piece(Vec3 centre, Vec3 p, int pieces, int seed) {
        double a = Math.atan2(p.z - centre.z, p.x - centre.x) - hash(seed) * Math.PI * 2;
        double slice = Math.PI * 2 / pieces;
        return Math.floorMod((int) Math.floor(a / slice), pieces);
    }

    /** How far apart the pieces are at a moment: 0 together, 1 fully apart (rise, hold, snap back). */
    public static double apart(double age, double total) {
        double rise = Math.min(20, total * 0.25), back = Math.min(10, total * 0.15);
        if (age < rise) { double t = age / rise; return t * t * (3 - 2 * t); }
        if (age > total - back) { double t = Math.max(0, (total - age) / back); return t * t; }
        return 1;
    }

    /** Where a point of piece i is when the pieces are {@code k} apart (0..1). */
    public static Vec3 moved(Vec3 centre, double radius, int i, int pieces, int seed, double lift, double k, Vec3 p) {
        double slice = Math.PI * 2 / pieces, mid = hash(seed) * Math.PI * 2 + (i + 0.5) * slice;
        Vec3 dir = new Vec3(Math.cos(mid), 0, Math.sin(mid));
        Vec3 pivot = centre.add(dir.scale(radius * 0.55));
        double yaw = (hash(seed * 31L + i) - 0.5) * Math.toRadians(70) * k;
        double h = lift * (0.45 + 0.55 * hash(seed * 17L + i)) * k, out = (1.0 + 1.5 * hash(seed * 7L + i)) * k;
        Vec3 d = p.subtract(pivot);
        double cs = Math.cos(yaw), sn = Math.sin(yaw);
        Vec3 r = new Vec3(d.x * cs - d.z * sn, d.y, d.x * sn + d.z * cs);
        return pivot.add(r).add(dir.scale(out)).add(0, h, 0);
    }

    /** The turn of piece i at {@code k} apart (radians about the vertical). */
    public static double turn(int i, int seed, double k) { return (hash(seed * 31L + i) - 0.5) * Math.toRadians(70) * k; }

    // ------------------------------------------------------------------ Inception
    /** How far from the middle the land starts to fold up. */
    public static final double HINGE = 7;

    /** How far Inception has folded the land at a moment: rises (0..1), hangs, slams (to 1.45), then flattens again. */
    public static double foldK(double age, double fold, double slam) {
        if (age < fold) { double t = age / fold; return t * t * (3 - 2 * t); }
        if (age < slam) return 1;
        if (age < slam + 30) { double t = (age - slam) / 30; return 1 + 0.45 * t * t * (3 - 2 * t); }
        double t = Math.min(1, (age - slam - 30) / 20);
        return 1.45 * (1 - t * t * (3 - 2 * t));
    }
}
