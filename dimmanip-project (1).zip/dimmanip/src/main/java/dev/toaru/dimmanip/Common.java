package dev.toaru.dimmanip;

import dev.toaru.dimmanip.net.Fx;
import dev.toaru.dimmanip.net.FxType;
import io.github.pinchan4273.reacademycraft.api.AbilityId;
import io.github.pinchan4273.reacademycraft.api.mc.AbilityActor;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Shared server helpers: holds that obey the player rules, wear, buffs, the ground, lines, delayed actions. */
public final class Common {
    private Common() { }

    public static AbilityId id(String path) { return DimManip.id(path); }

    /**
     * How long a hold, root or stun of {@code ticks} (written for monsters) lasts on this creature: players get the
     * configured share, and none at all while their short immunity after the last one lasts (no chaining).
     */
    public static int control(LivingEntity e, int ticks) {
        if (!(e instanceof Player)) return Targeting.bossLike(e) ? (int) Math.round(ticks * Cfg.BOSS_SHARE.get()) : ticks;
        if (Status.has(e, "ee_cc_immune")) return 0;
        return (int) Math.round(ticks * Cfg.PLAYER_CONTROL.get());
    }

    /** A creature held where it is: no walking (and no falling if {@code still}), optionally its abilities blocked. */
    public static final class Pin extends Timed.Effect {
        public final LivingEntity target;
        final Vec3 at;
        final boolean still, jam;
        long fx = -1;

        Pin(ServerPlayer owner, AbilityActor actor, LivingEntity target, int ticks, boolean still, boolean jam) {
            super(owner, actor, ticks);
            this.target = target; this.at = target.position(); this.still = still; this.jam = jam;
        }

        @Override
        protected boolean tick() {
            if (!target.isAlive() || target.level() != level) return false;
            Vec3 v = target.getDeltaMovement();
            if (still) {
                Targeting.setMotion(target, Vec3.ZERO);
                target.fallDistance = 0;
                if (target.position().distanceToSqr(at) > 0.04) target.teleportTo(at.x, at.y, at.z);
            } else {
                Targeting.setMotion(target, new Vec3(0, Math.min(0, v.y), 0));
                Vec3 p = target.position();
                if ((p.x - at.x) * (p.x - at.x) + (p.z - at.z) * (p.z - at.z) > 0.09) target.teleportTo(at.x, p.y, at.z);
            }
            if (target instanceof Mob mob) mob.getNavigation().stop();
            return !over();
        }

        @Override
        protected void end(boolean natural) {
            Fx.cancel(level, fx);
            if (target instanceof Player) Status.set(target, "ee_cc_immune", (int) Math.round(Cfg.CONTROL_IMMUNITY.get() * 20));
        }
    }

    /**
     * Holds {@code target} for {@code ticks} (monster time; players get their share). Returns the hold, or null if it
     * could not land (a player still immune). {@code fx} (if not null) is drawn on the target meanwhile.
     */
    public static @Nullable Pin pin(ServerPlayer owner, AbilityActor actor, LivingEntity target, int ticks, boolean still, boolean jam, @Nullable FxType fx) {
        int t = control(target, ticks);
        if (t <= 0) return null;
        for (Pin old : Timed.of(Pin.class)) if (old.target == target) Timed.stop(old, false);
        Pin p = Timed.add(new Pin(owner, actor, target, t, still, jam));
        if (jam && target instanceof ServerPlayer sp) {
            long until = owner.level().getGameTime() + t;
            AcBridge.interfere(sp, DimManip.MOD_ID + ":hold", () -> sp.isAlive() && sp.level().getGameTime() < until && !p.ended());
        }
        if (fx != null) p.fx = Fx.make(owner.serverLevel(), target.position(), fx, t).a(target.getId()).range(128).send();
        return p;
    }

    /** Blocks a player's Re:AcademyCraft abilities for {@code ticks} (its own interference, shown on their screen). */
    public static void silence(ServerPlayer target, String why, int ticks) {
        long until = target.level().getGameTime() + ticks;
        AcBridge.interfere(target, DimManip.MOD_ID + ":" + why, () -> target.isAlive() && target.level().getGameTime() < until);
    }

    /** Armour pieces and the held item lose {@code share} of their full durability. */
    public static void wear(LivingEntity e, double share) {
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot == EquipmentSlot.OFFHAND) continue;
            ItemStack s = e.getItemBySlot(slot);
            if (s.isEmpty() || !s.isDamageableItem()) continue;
            int amount = Math.max(1, (int) Math.round(s.getMaxDamage() * share));
            s.hurtAndBreak(amount, e, x -> x.broadcastBreakEvent(slot));
        }
    }

    /** Removes every good effect (buffs) from it; how many. */
    public static int stripGood(LivingEntity e) {
        List<MobEffectInstance> good = new ArrayList<>();
        for (MobEffectInstance i : e.getActiveEffects()) if (i.getEffect().isBeneficial()) good.add(i);
        for (MobEffectInstance i : good) e.removeEffect(i.getEffect());
        return good.size();
    }

    /** The first solid ground at or below {@code p} (up to 24 blocks down), its top surface. */
    public static Vec3 ground(ServerLevel level, Vec3 p) {
        BlockPos b = BlockPos.containing(p.x, p.y + 0.01, p.z);
        for (int i = 0; i < 24; i++) {
            BlockPos below = b.below();
            if (!level.getBlockState(below).getCollisionShape(level, below).isEmpty() && level.getBlockState(b).getCollisionShape(level, b).isEmpty())
                return new Vec3(p.x, b.getY(), p.z);
            b = below;
        }
        return p;
    }

    /** Creatures within {@code width} of the line from {@code a} to {@code b}. */
    public static List<LivingEntity> along(ServerLevel level, Vec3 a, Vec3 b, double width, @Nullable Entity exclude) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        List<LivingEntity> out = new ArrayList<>();
        if (len < 1e-6) return out;
        Vec3 u = d.scale(1 / len);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(a, b).inflate(width + 1),
                x -> x != exclude && x.isAlive() && !x.isSpectator())) {
            Vec3 c = Targeting.centre(e).subtract(a);
            double t = Math.max(0, Math.min(len, c.dot(u)));
            if (c.subtract(u.scale(t)).length() <= width + e.getBbWidth() / 2) out.add(e);
        }
        return out;
    }

    /** Runs {@code then} after {@code ticks} (dropped if the player leaves, dies or changes dimension first). */
    public static void later(ServerPlayer owner, AbilityActor actor, int ticks, Runnable then) {
        Timed.add(new Timed.Effect(owner, actor, Math.max(1, ticks)) {
            @Override protected boolean tick() { return !over(); }
            @Override protected void end(boolean natural) { if (natural) then.run(); }
        });
    }

    /**
     * Interrupts what a creature is doing: an enemy esper's Re:AcademyCraft abilities stop for {@code ticks} (its share),
     * a monster loses its target and stands dazed.
     */
    public static void interrupt(ServerPlayer owner, AbilityActor actor, LivingEntity e, int ticks, String why) {
        int t = control(e, ticks);
        if (t <= 0) return;
        if (e instanceof ServerPlayer sp) silence(sp, why, t);
        if (e instanceof Mob mob) {
            mob.setTarget(null);
            mob.getNavigation().stop();
        }
        e.addEffect(new MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, t, 3, false, false, true), owner);
    }

    /** Creatures in a cone from {@code from} along {@code dir} (unit), out to {@code range}, within {@code degrees} total width. */
    public static List<LivingEntity> cone(ServerLevel level, Vec3 from, Vec3 dir, double range, double degrees, @Nullable Entity exclude) {
        double cos = Math.cos(Math.toRadians(degrees / 2));
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : Targeting.livingWithin(level, from, range, exclude)) {
            Vec3 to = Targeting.centre(e).subtract(from);
            double d = to.length();
            if (d < 1.2 || to.scale(1 / d).dot(dir) >= cos) out.add(e);
        }
        return out;
    }

    /** Would this entity fit standing at {@code p} (no blocks in the way)? */
    public static boolean fits(ServerLevel level, Entity e, Vec3 p) {
        AABB box = e.getBoundingBox().move(p.subtract(e.position()));
        return level.noCollision(e, box);
    }

    /**
     * The farthest safe spot up to {@code dist} along {@code dir} from the entity (stopping before walls), or null if it
     * can't move at all.
     */
    public static @Nullable Vec3 safeAlong(ServerLevel level, Entity e, Vec3 dir, double dist) {
        Vec3 start = e.position();
        Vec3 best = null;
        for (double d = 0.5; d <= dist + 1e-6; d += 0.5) {
            Vec3 p = start.add(dir.scale(d));
            if (!fits(level, e, p)) break;
            best = p;
        }
        return best;
    }

    /** A safe spot for the entity at or just above {@code p} (up to 3 blocks), or null. */
    public static @Nullable Vec3 safeNear(ServerLevel level, Entity e, Vec3 p) {
        for (int i = 0; i <= 6; i++) {
            Vec3 q = p.add(0, i * 0.5, 0);
            if (fits(level, e, q)) return q;
        }
        return null;
    }
}
