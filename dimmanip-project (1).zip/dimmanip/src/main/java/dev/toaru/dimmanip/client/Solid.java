package dev.toaru.dimmanip.client;

import static dev.toaru.dimmanip.client.Fxu.*;

import net.minecraft.world.phys.Vec3;

/**
 * Solid things, not lines: every face is lit by where it points and where you stand, so bars, frames, bands, slabs of
 * dark glass and faceted crystals read as real three-dimensional objects with weight. Faces turned edge-on to you catch
 * the light (so glass looks like glass). Used for the structure of every Dimension Manipulation effect.
 */
final class Solid {
    private Solid() { }

    private static final Vec3 SUN = new Vec3(0.35, 0.85, 0.4).normalize();

    /** One flat face. {@code glass} 0 = a solid material, 1 = glass (clear face-on, bright edge-on). */
    static void face(Geo g, Vec3 a, Vec3 b, Vec3 c, Vec3 d, int rgb, float alpha, double glass) {
        if (alpha <= 0.01f) return;
        Vec3 n = b.subtract(a).cross(d.subtract(a));
        if (n.lengthSqr() < 1e-12) n = c.subtract(a).cross(d.subtract(a));
        if (n.lengthSqr() < 1e-12) return;
        n = n.normalize();
        Vec3 mid = a.add(b).add(c).add(d).scale(0.25);
        Vec3 view = g.cam().subtract(mid);
        view = view.lengthSqr() < 1e-9 ? n : view.normalize();
        double facing = Math.abs(n.dot(view)), rim = (1 - facing) * (1 - facing);
        float lit = (float) (0.3 + 0.7 * Math.abs(n.dot(SUN)));
        int col = mix(shade(rgb, lit), 0xFFFFFF, 0.45 * rim);
        float al = (float) (alpha * (1 - glass * 0.7 * facing * facing) + glass * 0.25 * rim * alpha);
        int cc = argb(Math.min(1f, al), col);
        g.gquad(a, cc, b, cc, c, cc, d, cc);
    }

    static void tri(Geo g, Vec3 a, Vec3 b, Vec3 c, int rgb, float alpha, double glass) { face(g, a, b, c, c, rgb, alpha, glass); }

    /** A box given by its centre and three half-edges (any orientation). */
    static void box(Geo g, Vec3 c, Vec3 x, Vec3 y, Vec3 z, int rgb, float alpha, double glass) {
        Vec3[] p = new Vec3[8];
        for (int i = 0; i < 8; i++) p[i] = c.add(x.scale((i & 1) == 0 ? -1 : 1)).add(y.scale((i & 2) == 0 ? -1 : 1)).add(z.scale((i & 4) == 0 ? -1 : 1));
        face(g, p[0], p[1], p[3], p[2], rgb, alpha, glass);
        face(g, p[4], p[5], p[7], p[6], rgb, alpha, glass);
        face(g, p[0], p[1], p[5], p[4], rgb, alpha, glass);
        face(g, p[2], p[3], p[7], p[6], rgb, alpha, glass);
        face(g, p[0], p[2], p[6], p[4], rgb, alpha, glass);
        face(g, p[1], p[3], p[7], p[5], rgb, alpha, glass);
    }

    /** Two unit vectors square to {@code d} and to each other. */
    static Vec3[] square(Vec3 d) {
        Vec3 up = Math.abs(d.y) > 0.92 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 s = d.cross(up).normalize();
        return new Vec3[] {s, s.cross(d).normalize()};
    }

    /** A square bar from a to b, {@code w} thick, twisted by {@code roll} about its length. */
    static void bar(Geo g, Vec3 a, Vec3 b, double w, double roll, int rgb, float alpha, double glass) {
        Vec3 d = b.subtract(a);
        if (d.lengthSqr() < 1e-9) return;
        Vec3[] q = square(d.normalize());
        Vec3 s = q[0].scale(Math.cos(roll)).add(q[1].scale(Math.sin(roll))).scale(w / 2), t = q[1].scale(Math.cos(roll)).subtract(q[0].scale(Math.sin(roll))).scale(w / 2);
        Vec3[] ra = {a.add(s).add(t), a.subtract(s).add(t), a.subtract(s).subtract(t), a.add(s).subtract(t)};
        Vec3[] rb = {b.add(s).add(t), b.subtract(s).add(t), b.subtract(s).subtract(t), b.add(s).subtract(t)};
        for (int i = 0; i < 4; i++) face(g, ra[i], ra[(i + 1) % 4], rb[(i + 1) % 4], rb[i], rgb, alpha, glass);
    }

    /** A pointed crystal: a bar that narrows to a point at both ends. */
    static void spike(Geo g, Vec3 a, Vec3 b, double w, double roll, int rgb, float alpha, double glass) {
        Vec3 d = b.subtract(a);
        if (d.lengthSqr() < 1e-9) return;
        Vec3[] q = square(d.normalize());
        Vec3 m = a.add(d.scale(0.35));
        Vec3[] r = new Vec3[4];
        for (int i = 0; i < 4; i++) { double an = roll + i * Math.PI / 2; r[i] = m.add(q[0].scale(Math.cos(an) * w / 2)).add(q[1].scale(Math.sin(an) * w / 2)); }
        for (int i = 0; i < 4; i++) { tri(g, a, r[i], r[(i + 1) % 4], rgb, alpha, glass); tri(g, b, r[i], r[(i + 1) % 4], rgb, alpha, glass); }
    }

    /** An eight-faced crystal, turned by {@code spin}; {@code tall} stretches it along its axis. */
    static void octa(Geo g, Vec3 c, double r, double tall, double spin, double tilt, int rgb, float alpha, double glass) {
        Vec3 axis = new Vec3(Math.sin(tilt) * Math.cos(spin * 0.7), Math.cos(tilt), Math.sin(tilt) * Math.sin(spin * 0.7)).normalize();
        Vec3[] q = square(axis);
        Vec3 top = c.add(axis.scale(r * tall)), bot = c.subtract(axis.scale(r * tall));
        Vec3[] e = new Vec3[4];
        for (int i = 0; i < 4; i++) { double an = spin + i * Math.PI / 2; e[i] = c.add(q[0].scale(Math.cos(an) * r)).add(q[1].scale(Math.sin(an) * r)); }
        for (int i = 0; i < 4; i++) { tri(g, top, e[i], e[(i + 1) % 4], rgb, alpha, glass); tri(g, bot, e[i], e[(i + 1) % 4], rgb, alpha, glass); }
    }

    /**
     * A solid band round a circle (a machined ring, not a line): {@code wide} across, {@code thick} deep, cut into
     * {@code segs} blocks with a gap of {@code gap} (0..1 of each block) between them.
     */
    static void band(Geo g, Vec3 c, Vec3 n, double r, double wide, double thick, int segs, double rot, double gap, int rgb, int rgb2, float alpha, double glass) {
        n = n.lengthSqr() < 1e-9 ? new Vec3(0, 1, 0) : n.normalize();
        Vec3[] q = square(n);
        segs = Math.max(6, Geo.seg(segs));
        double step = Math.PI * 2 / segs;
        for (int i = 0; i < segs; i++) {
            double a0 = rot + i * step, a1 = a0 + step * (1 - gap);
            Vec3 d0 = q[0].scale(Math.cos(a0)).add(q[1].scale(Math.sin(a0))), d1 = q[0].scale(Math.cos(a1)).add(q[1].scale(Math.sin(a1)));
            Vec3 h = n.scale(thick / 2);
            Vec3 i0 = c.add(d0.scale(r - wide / 2)), o0 = c.add(d0.scale(r + wide / 2)), i1 = c.add(d1.scale(r - wide / 2)), o1 = c.add(d1.scale(r + wide / 2));
            int col = i % 2 == 0 ? rgb : rgb2;
            face(g, i0.add(h), o0.add(h), o1.add(h), i1.add(h), col, alpha, glass);
            face(g, i0.subtract(h), o0.subtract(h), o1.subtract(h), i1.subtract(h), col, alpha, glass);
            face(g, o0.subtract(h), o0.add(h), o1.add(h), o1.subtract(h), col, alpha, glass);
            face(g, i0.subtract(h), i0.add(h), i1.add(h), i1.subtract(h), col, alpha, glass);
            if (gap > 0.02) {
                face(g, i0.subtract(h), o0.subtract(h), o0.add(h), i0.add(h), col, alpha, glass);
                face(g, i1.subtract(h), o1.subtract(h), o1.add(h), i1.add(h), col, alpha, glass);
            }
        }
    }

    /** A thick pane (four corners of its middle sheet, and how thick it is): two big faces and four edges. */
    static void slab(Geo g, Vec3 a, Vec3 b, Vec3 c, Vec3 d, double thick, int rgb, float alpha, double glass) {
        Vec3 n = b.subtract(a).cross(d.subtract(a));
        if (n.lengthSqr() < 1e-12) return;
        n = n.normalize().scale(thick / 2);
        Vec3[] f = {a.add(n), b.add(n), c.add(n), d.add(n)}, k = {a.subtract(n), b.subtract(n), c.subtract(n), d.subtract(n)};
        face(g, f[0], f[1], f[2], f[3], rgb, alpha, glass);
        face(g, k[0], k[1], k[2], k[3], rgb, alpha, glass);
        for (int i = 0; i < 4; i++) face(g, f[i], f[(i + 1) % 4], k[(i + 1) % 4], k[i], mix(rgb, 0xFFFFFF, 0.5), Math.min(1f, alpha * 2.2f), 0);
    }

    /** A twenty-faced shell round a point (an icosahedron), turned by yaw and pitch; faces can be pushed apart. */
    static void shell(Geo g, Vec3 c, double r, double yaw, double pitch, double apart, int rgb, int rgb2, float alpha, double glass) {
        double t = (1 + Math.sqrt(5)) / 2;
        double[][] raw = {{-1, t, 0}, {1, t, 0}, {-1, -t, 0}, {1, -t, 0}, {0, -1, t}, {0, 1, t}, {0, -1, -t}, {0, 1, -t}, {t, 0, -1}, {t, 0, 1}, {-t, 0, -1}, {-t, 0, 1}};
        int[][] faces = {{0, 11, 5}, {0, 5, 1}, {0, 1, 7}, {0, 7, 10}, {0, 10, 11}, {1, 5, 9}, {5, 11, 4}, {11, 10, 2}, {10, 7, 6}, {7, 1, 8},
                {3, 9, 4}, {3, 4, 2}, {3, 2, 6}, {3, 6, 8}, {3, 8, 9}, {4, 9, 5}, {2, 4, 11}, {6, 2, 10}, {8, 6, 7}, {9, 8, 1}};
        Vec3[] v = new Vec3[12];
        double len = Math.sqrt(1 + t * t), cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
        for (int i = 0; i < 12; i++) {
            double x = raw[i][0] / len, y = raw[i][1] / len, z = raw[i][2] / len;
            double y2 = y * cp - z * sp, z2 = y * sp + z * cp;
            v[i] = new Vec3(x * cy - z2 * sy, y2, x * sy + z2 * cy).scale(r);
        }
        for (int i = 0; i < faces.length; i++) {
            Vec3 a = v[faces[i][0]], b = v[faces[i][1]], d = v[faces[i][2]];
            Vec3 out = a.add(b).add(d).scale(apart / 3);
            tri(g, c.add(a).add(out), c.add(b).add(out), c.add(d).add(out), i % 3 == 0 ? rgb2 : rgb, alpha, glass);
        }
    }
}
