package dev.toaru.dimmanip.client;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Small shared helpers for the effect drawing: easing, colours, entity lookup and in-world text labels. */
final class Fxu {
    private Fxu() { }

    static float smooth(double x) { double t = Math.max(0, Math.min(1, x)); return (float) (t * t * (3 - 2 * t)); }

    /** Fades in over {@code in} ticks and out over the last {@code out} ticks of {@code dur}. */
    static float env(double age, double dur, double in, double out) { return smooth(age / in) * smooth((dur - age) / out); }

    static double easeOut(double t) { t = Math.max(0, Math.min(1, t)); return 1 - (1 - t) * (1 - t) * (1 - t); }

    static double easeOutBack(double t) {
        t = Math.max(0, Math.min(1, t));
        double c1 = 1.70158, c3 = c1 + 1;
        return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
    }

    static int argb(float a, int rgb) { return ((int) (Math.max(0f, Math.min(1f, a)) * 255) << 24) | (rgb & 0xFFFFFF); }

    /** Multiplies a colour's brightness by {@code k}. */
    static int shade(int rgb, float k) {
        k = Math.max(0f, Math.min(1.2f, k));
        int r = Math.min(255, Math.round(((rgb >> 16) & 255) * k)), g = Math.min(255, Math.round(((rgb >> 8) & 255) * k)), b = Math.min(255, Math.round((rgb & 255) * k));
        return (r << 16) | (g << 8) | b;
    }

    /** How lit a spot of the world is right now, 0.22 (pitch dark) .. 1 (full light), so matter does not glow at night. */
    static float light(Vec3 p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return 1f;
        try {
            int l = mc.level.getMaxLocalRawBrightness(BlockPos.containing(p.x, p.y, p.z));
            return 0.22f + 0.78f * Math.max(0, Math.min(15, l)) / 15f;
        } catch (RuntimeException ex) {
            return 1f;
        }
    }

    /** The height of the first non-air block top at or below {@code p} (up to {@code down} blocks), for things that fall. */
    static double ground(Vec3 p, int down) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return p.y - 1;
        for (int i = 0; i <= down; i++) {
            BlockPos b = BlockPos.containing(p.x, p.y - i, p.z);
            if (!mc.level.getBlockState(b).isAir()) return Math.min(p.y, b.getY() + 1.0);
        }
        return p.y - down;
    }

    static Geo col(Geo g, int rgb, float a) {
        return g.color(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, Math.max(0f, Math.min(1f, a)));
    }

    static int mix(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    static @Nullable Entity entity(int id) {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null || id < 0 ? null : mc.level.getEntity(id);
    }

    /** A repeatable pseudo-random number 0..1 for index {@code i} (so shapes keep their place between frames). */
    static double hash(long i) {
        long z = i * 0x9E3779B97F4A7C15L;
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return ((z ^ (z >>> 31)) >>> 11) * 0x1.0p-53;
    }

    static boolean own(int entityId) {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && mc.player.getId() == entityId;
    }

    /** Text shown in the world this frame (drawn after the geometry, facing the camera). */
    record Label(Vec3 pos, String text, int argb, float scale) { }
    static final List<Label> LABELS = new ArrayList<>();

    static void label(Vec3 pos, String text, int rgb, float alpha, float scale) {
        int a = (int) (Math.max(0f, Math.min(1f, alpha)) * 255);
        if (a < 8) return;
        LABELS.add(new Label(pos, text, (a << 24) | (rgb & 0xFFFFFF), scale));
    }

    private static final Vec3 SUN = new Vec3(0.35, 0.85, 0.4).normalize();

    /** How lit a face pointing along {@code n} is (light from above, soft shadows). */
    static float facing(Vec3 n) {
        double d = n.dot(SUN);
        return (float) Math.min(1.0, 0.44 + 0.62 * Math.max(0, d) + 0.1 * Math.max(0, n.y));
    }

    /** A direction square to both {@code a} and {@code b} (unit length; a fallback if they line up). */
    static Vec3 normal(Vec3 a, Vec3 b) {
        Vec3 n = a.cross(b);
        return n.lengthSqr() < 1e-9 ? new Vec3(0, 1, 0) : n.normalize();
    }
}
