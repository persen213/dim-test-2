package dev.toaru.dimmanip.client;

import static dev.toaru.dimmanip.client.Fxu.*;

import javax.annotation.Nullable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * His right arm drawn by the add-on, wherever it has to point somewhere the game's own arm cannot (thrown up at a spell,
 * held out before it is cut, lying on the ground after): a box from the shoulder end ({@code top}) along {@code d}, its
 * front face toward {@code f}. In the game it wears the player's own skin (SkinArm); if that is not available it is a
 * plain skin-coloured box.
 */
final class Limb {
    private Limb() { }

    /** One pixel of the player model, in blocks. */
    static final double PX = 0.0586;
    /** The arm's length (12 pixels). */
    static final double LEN = 12 * PX;

    interface Skin {
        /**
         * Draws {@code len} pixels of limb {@code part} (0 right arm, 1 left arm, 2 right leg, 3 left leg), starting
         * {@code from} pixels down it, in {@code owner}'s skin; false if it could not (then the plain box is drawn).
         */
        boolean draw(Entity owner, int part, Vec3 top, Vec3 d, Vec3 f, double scale, int from, int len);
    }

    /** Set by the world renderer while it draws (null in the preview and whenever skins are not available). */
    static @Nullable Skin skin;

    /** {@code v} turned by {@code angle} about the unit {@code axis}. */
    static Vec3 rot(Vec3 v, Vec3 axis, double angle) {
        double c = Math.cos(angle), s = Math.sin(angle);
        return v.scale(c).add(axis.cross(v).scale(s)).add(axis.scale(axis.dot(v) * (1 - c)));
    }

    /**
     * Which way the arm's front face looks when the arm, hanging down with its front toward {@code fwd}, is swung by
     * the shortest way to point along {@code d}.
     */
    static Vec3 front(Vec3 d, Vec3 fwd) {
        Vec3 down = new Vec3(0, -1, 0);
        Vec3 axis = down.cross(d);
        if (axis.lengthSqr() < 1e-8) return d.y < 0 ? fwd : fwd.scale(-1);
        double ang = Math.acos(Math.max(-1, Math.min(1, down.dot(d))));
        Vec3 f = rot(fwd, axis.normalize(), ang);
        f = f.subtract(d.scale(f.dot(d)));
        return f.lengthSqr() < 1e-8 ? fwd : f.normalize();
    }

    /** The direction a fraction {@code k} of the way from {@code a} to {@code b} (both unit), swinging out past {@code via}. */
    static Vec3 swing(Vec3 a, Vec3 b, Vec3 via, double k) {
        Vec3 v = a.scale(1 - k).add(b.scale(k)).add(via.scale(Math.sin(Math.PI * k) * 0.5));
        return v.lengthSqr() < 1e-8 ? b : v.normalize();
    }

    static void arm(@Nullable Entity owner, Geo plain, Vec3 top, Vec3 d, Vec3 f, double scale) {
        if (scale <= 0.01) return;
        if (owner != null && skin != null) {
            try {
                if (skin.draw(owner, 0, top, d, f, scale, 0, 12)) return;
            } catch (RuntimeException ignored) { }
        }
        // The plain arm: a short sleeve, skin below it.
        float l = light(top);
        double h = 2 * PX * scale;
        box(plain, top, d, f, 4 * PX * scale, h * 1.08, h * 1.08, shade(0xE8E8EC, l), 0.98f);
        box(plain, top.add(d.scale(4 * PX * scale)), d, f, 8 * PX * scale, h, h, shade(0xD9B08C, l), 0.98f);
    }

    /** A piece of a limb (see {@link Skin#draw}): {@code len} pixels from {@code top} along {@code d}. */
    static void part(@Nullable Entity owner, Geo plain, int part, Vec3 top, Vec3 d, Vec3 f, int from, int len) {
        if (owner != null && skin != null) {
            try {
                if (skin.draw(owner, part, top, d, f, 1, from, len)) return;
            } catch (RuntimeException ignored) { }
        }
        int rgb = part >= 2 ? 0x3B3F8F : from < 4 ? 0xE8E8EC : 0xD9B08C;
        box(plain, top, d, f, len * PX, 2 * PX, 2 * PX, shade(rgb, light(top)), 0.98f);
    }

    /** A box from {@code top} along {@code d}, {@code hs} to each side and {@code hf} front and back, faces shaded. */
    static void box(Geo g, Vec3 top, Vec3 d, Vec3 f, double len, double hs, double hf, int rgb, float alpha) {
        Vec3 s = d.cross(f);
        Vec3 a = top.add(s.scale(hs)).add(f.scale(hf)), b = top.subtract(s.scale(hs)).add(f.scale(hf));
        Vec3 c = top.subtract(s.scale(hs)).subtract(f.scale(hf)), e = top.add(s.scale(hs)).subtract(f.scale(hf));
        Vec3 dl = d.scale(len);
        face(g, a, b, b.add(dl), a.add(dl), f, rgb, alpha);
        face(g, c, e, e.add(dl), c.add(dl), f.scale(-1), rgb, alpha);
        face(g, e, a, a.add(dl), e.add(dl), s, rgb, alpha);
        face(g, b, c, c.add(dl), b.add(dl), s.scale(-1), rgb, alpha);
        face(g, a, b, c, e, d.scale(-1), rgb, alpha);
        face(g, a.add(dl), b.add(dl), c.add(dl), e.add(dl), d, rgb, alpha);
    }

    private static void face(Geo g, Vec3 p1, Vec3 p2, Vec3 p3, Vec3 p4, Vec3 n, int rgb, float alpha) {
        col(g, shade(rgb, Fxu.facing(n)), alpha).quad(p1, p2, p3, p4);
    }
}
