package dev.toaru.dimmanip.client;

import static dev.toaru.dimmanip.client.Fxu.*;

import javax.annotation.Nullable;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Every Dimension Manipulation effect in the world, all geometry (no particles). Solid things (rock, the arm) go in the solid
 * buffer, see-through things (air, sound, rubber) in "crystal", light in the additive "glow" buffer.
 */
final class FxRenderer {
    private FxRenderer() { }

    static final Vec3 UP = new Vec3(0, 1, 0);

    /** {bright, mid, dark} of a colour index: 0 white, 5 dimension (others kept for the shared effects). */
    static int[] pal(int c) {
        return switch (c) {
            case 1 -> new int[] {0xFFFBD0, 0x8FD8FF, 0x1A2A50};
            case 2 -> new int[] {0xF0E4FF, 0xB58CFF, 0x2A1450};
            case 3 -> new int[] {0xFFF4D0, 0xFFC94A, 0x3A2A08};
            case 4 -> new int[] {0xFFE0F6, 0xFF5AD2, 0x2A0830};
            case 5 -> new int[] {0xFFFFFF, 0x8A6CFF, 0x08061A};
            default -> new int[] {0xFFFFFF, 0xD0E4FF, 0x202838};
        };
    }

    static void draw(Geo crystal, Geo glow, Geo solid, Geo xray, Vec3 cam, long now, float pt, double time) {
        for (ClientFx.Effect e : ClientFx.ACTIVE.values()) {
            double age = e.age(now, pt);
            if (age < 0 || age > e.duration + 1) continue;
            Entity src = e.a >= 0 ? entity(e.a) : null;
            Vec3 where = src != null ? src.position() : e.pos;
            if (where.distanceToSqr(cam) > 160 * 160) continue;
            try {
                switch (e.type) {
                    case SHOCK -> shock(e, crystal, glow, age);
                    case RING -> ring(e, crystal, glow, age);
                    case SCREEN -> { }
                    default -> FxDim.draw(e, src, crystal, glow, solid, xray, age, time, pt);
                }
            } catch (RuntimeException ex) {
                // A drawing problem must never crash the game.
            } finally {
                Geo.nearFade = 2.5;
            }
        }
    }

    // ================================================================== shared pieces
    static Vec3 lerp(Vec3 a, Vec3 b, double t) { return a.add(b.subtract(a).scale(t)); }

    static double bodyYaw(LivingEntity p, float pt) { return Math.toRadians(Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot)); }

    static Vec3 right(LivingEntity p, float pt) { double y = bodyYaw(p, pt); return new Vec3(-Math.cos(y), 0, -Math.sin(y)); }

    static Vec3 fwd(LivingEntity p, float pt) { double y = bodyYaw(p, pt); return new Vec3(-Math.sin(y), 0, Math.cos(y)); }

    /** The joint of the right shoulder. */
    static Vec3 shoulder(LivingEntity p, float pt) { return p.getPosition(pt).add(right(p, pt).scale(0.33)).add(0, 1.29, 0); }

    /** The centre of an entity now (or {@code fallback} if it is gone). */
    static Vec3 centre(@Nullable Entity e, float pt, Vec3 fallback) {
        return e == null ? fallback : e.getPosition(pt).add(0, e.getBbHeight() / 2, 0);
    }

    /** The ground height near a point (or the point's own height when the ground is far). */
    static double ground(double x, double y, double z) {
        var level = net.minecraft.client.Minecraft.getInstance().level;
        if (level == null) return y;
        int h = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(x), (int) Math.floor(z));
        return Math.abs(h - y) > 6 ? y : h + 0.04;
    }

    /** A jagged bolt of electricity from a to b. */
    static void bolt(Geo glow, Vec3 a, Vec3 b, long seed, float alpha, int rgb) {
        Vec3 d = b.subtract(a);
        double L = d.length();
        if (L < 0.05 || alpha < 0.01f) return;
        Vec3[] uv = Geo.basis(d);
        int n = Math.max(3, Math.min(14, (int) (L / 0.5)));
        Vec3 prev = a;
        for (int i = 1; i <= n; i++) {
            double t = i / (double) n, j = i == n ? 0 : Math.min(0.5, L * 0.08);
            Vec3 p = a.add(d.scale(t)).add(uv[0].scale((hash(seed * 5 + i) - 0.5) * j * 2)).add(uv[1].scale((hash(seed * 9 + i) - 0.5) * j * 2));
            col(glow, rgb, 0.45f * alpha).ribbon(prev, p, 0.09);
            col(glow, 0xFFFFFF, 0.95f * alpha).ribbon(prev, p, 0.025);
            prev = p;
        }
    }

    /** A burst where something hits: a white-hot flash, a coloured bloom, a shock ring, a second slower ring, and shards thrown out. */
    static void shock(ClientFx.Effect e, Geo crystal, Geo glow, double age) {
        int[] c = pal(e.c);
        double k = age / Math.max(1, e.duration), R = Math.max(0.3, e.power);
        float a = (float) (1 - k);
        if (age < 3) glow.softFacing(e.pos, R * (0.35 + 0.2 * age), 14, argb((float) (1 - age / 3), 0xFFFFFF), argb(0f, c[0]));
        glow.softFacing(e.pos, R * (0.6 + 0.9 * easeOut(k)), 18, argb(0.55f * a, c[0]), argb(0f, c[1]));
        Vec3 n = new Vec3(hash(e.key) - 0.5, 1, hash(e.key + 1) - 0.5).normalize();
        col(glow, c[1], 0.9f * a).ring(e.pos, n, R * (0.4 + 1.3 * easeOut(k)), 0.05 * R * a + 0.01, 32, 0, false);
        col(glow, c[0], 0.5f * a).ring(e.pos, n.add(0.4, 0, 0.3).normalize(), R * (0.3 + 0.8 * easeOut(k * 0.7)), 0.03 * R * a + 0.01, 28, 0, false);
        for (int i = 0; i < 12; i++) {
            Vec3 d = new Vec3(hash(e.key * 3 + i) - 0.5, hash(e.key * 7 + i) - 0.25, hash(e.key * 11 + i) - 0.5).normalize();
            double go = R * (0.3 + 2.2 * easeOut(k)) * (0.6 + 0.6 * hash(e.key + i));
            Vec3 p0 = e.pos.add(d.scale(go)).add(0, -k * k * R * 0.6, 0), p1 = p0.add(d.scale(R * 0.4 * a));
            Vfx.band(glow, p0, p1, 0.04 * R + 0.01, i % 3 == 0 ? 0xFFFFFF : c[0], 0.9f * a);
        }
    }

    /** A ring opening along a direction (aux). */
    static void ring(ClientFx.Effect e, Geo crystal, Geo glow, double age) {
        int[] c = pal(e.c);
        double k = age / Math.max(1, e.duration);
        float a = (float) (1 - k);
        Vec3 n = e.aux.lengthSqr() < 1e-6 ? UP : e.aux.normalize();
        for (int i = 0; i < 3; i++) {
            double kk = Math.max(0, k - i * 0.12);
            col(crystal, c[1], 0.5f * a).ring(e.pos.add(n.scale(i * 0.3 * kk)), n, Math.max(0.3, e.power) * (0.3 + easeOut(kk)), 0.04, 30, 0, false);
        }
    }

    /** A spark leaping from pos to aux (or to the entity a). */
    static void zap(ClientFx.Effect e, @Nullable Entity src, Geo glow, double age, float pt) {
        float a = 1f - (float) (age / Math.max(1, e.duration));
        if (e.aux.lengthSqr() > 1e-6) {
            bolt(glow, e.pos, e.aux, e.key + (long) age, a, pal(e.c >= 0 ? e.c : 1)[1]);
            return;
        }
        if (src == null) return;
        // Stunned: little arcs crawling over its body.
        Vec3 c = centre(src, pt, e.pos);
        double h = src.getBbHeight(), w = src.getBbWidth();
        for (int i = 0; i < 3; i++) {
            long s = e.key * 13 + i + (long) (age / 2);
            Vec3 p0 = c.add((hash(s) - 0.5) * w, (hash(s + 1) - 0.5) * h, (hash(s + 2) - 0.5) * w);
            Vec3 p1 = c.add((hash(s + 3) - 0.5) * w, (hash(s + 4) - 0.5) * h, (hash(s + 5) - 0.5) * w);
            bolt(glow, p0, p1, s, 0.8f, 0x8FD8FF);
        }
    }

    /** Ripples across the ground: a few rings spreading from a point. */
    static void ripples(Geo g, Vec3 at, double R, double k, int rgb, float a, int n) {
        for (int i = 0; i < n; i++) {
            double kk = (k + i / (double) n) % 1.0;
            col(g, rgb, a * (float) (1 - kk)).ring(at, UP, R * kk, 0.03 + 0.03 * R * (1 - kk), 36, 0, false);
        }
    }
}
