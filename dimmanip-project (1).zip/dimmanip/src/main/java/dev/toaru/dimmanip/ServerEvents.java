package dev.toaru.dimmanip;

import dev.toaru.dimmanip.skills.Kit;
import dev.toaru.dimmanip.skills.Pocket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Server hooks: the effect clock, safe landings, and clean-up when players die, leave or change dimension. */
@Mod.EventBusSubscriber(modid = DimManip.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ServerEvents {
    private ServerEvents() { }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (Status.has(event.getEntity(), "safe_fall")) { event.setDistance(0); event.setCanceled(true); }
    }

    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        var src = event.getSource().getEntity();
        // Nothing reaches through the wall of a pocket.
        if (src != null && src.level() != event.getEntity().level()) { event.setCanceled(true); return; }
        // Nothing reaches out of a Tesseract; a hit on an esper in his Kaleidoscope may only break a reflection.
        if (src != null && Kit.sealedIn(src, event.getEntity())) { event.setCanceled(true); return; }
        if (event.getEntity() instanceof ServerPlayer p && (Kit.reflection(p, src) || Passive.dodge(p, event.getSource()))) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onHurt(LivingHurtEvent event) {
        if (event.getEntity().level().isClientSide() || event.isCanceled()) return;
        var src = event.getSource().getEntity();
        if (src == null || src == event.getEntity()) return;
        event.setAmount(event.getAmount() * Pocket.power(src));
        if (src instanceof ServerPlayer att) { Kit.echo(att, event.getEntity(), event.getAmount()); Kit.mirrored(att, event.getEntity(), event.getAmount()); }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) Timed.tick();
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.player instanceof ServerPlayer p && p.isAlive()) { Passive.tick(p); Passive.step(p); }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) Timed.removeOwner(p.getUUID());
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        // Going into or out of a pocket is part of Pocket Universe, not a reason to end things.
        if (event.getTo() == Pocket.LEVEL || event.getFrom() == Pocket.LEVEL) return;
        Timed.removeOwner(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) Pocket.loggedIn(p);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        Timed.removeOwner(event.getEntity().getUUID());
        Passive.forget(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        Timed.clear();
        Status.clearAll();
    }
}
