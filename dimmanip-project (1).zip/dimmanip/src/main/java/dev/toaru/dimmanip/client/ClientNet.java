package dev.toaru.dimmanip.client;

import dev.toaru.dimmanip.net.FxStartMsg;

/** Entry points for packets (only called on the client, through DistExecutor). */
public final class ClientNet {
    private ClientNet() { }
    public static void start(FxStartMsg msg) { ClientFx.start(msg); }
    public static void cancel(long key) { ClientFx.cancel(key); }
}
