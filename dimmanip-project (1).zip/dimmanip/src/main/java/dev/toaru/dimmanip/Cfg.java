package dev.toaru.dimmanip;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.ForgeConfigSpec.BooleanValue;
import net.minecraftforge.common.ForgeConfigSpec.DoubleValue;

/**
 * Every number of Dimension Manipulation (config/dimmanip-common.toml), one section per move. Seconds are real seconds, ranges
 * are blocks, damage is health points (2 = one heart; a player has 20), cp and overload are Re:AcademyCraft's own (a
 * Level 1 player has about 1500 CP). Holds and stuns are written for monsters; players get half (one rule for all moves).
 * Write numbers with a decimal point. Delete the file to get the defaults back.
 */
public final class Cfg {
    private Cfg() { }
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    /** One move's numbers, read by name (a wrong name is reported in the log and reads as 0). */
    public static final class Mv {
        public final String id;
        private final Map<String, DoubleValue> values = new LinkedHashMap<>();
        private Mv(String id) { this.id = id; }

        public double v(String name) {
            DoubleValue x = values.get(name);
            if (x == null) { DimManip.LOGGER.error("Dimension Manipulation: no config value '{}' for {}", name, id); return 0; }
            try { return x.get(); } catch (RuntimeException e) { return x.getDefault(); }
        }
        public float f(String name) { return (float) v(name); }
        public int ticks(String name) { return Math.max(1, (int) Math.round(v(name) * 20)); }
        public double cooldown() { return v("cooldown_seconds"); }
    }

    private static final Map<String, Mv> MOVES = new HashMap<>();

    public static Mv of(String id) {
        Mv m = MOVES.get(id);
        if (m == null) throw new IllegalStateException("Dimension Manipulation: no settings for " + id);
        return m;
    }

    private static void mv(String id, String comment, Object... pairs) {
        Mv m = new Mv(id);
        B.comment(comment).push(id);
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            String name = (String) pairs[i];
            m.values.put(name, B.defineInRange(name, ((Number) pairs[i + 1]).doubleValue(), 0, 100000));
        }
        B.pop();
        MOVES.put(id, m);
    }

    private static void tier(String name, String comment) { B.comment(comment).push(name); }

    static { B.comment("Rules for the whole mod.").push("general"); }
    public static final DoubleValue PLAYER_CONTROL = B.comment("How long holds, tilts and other control effects last on players compared with monsters (0.5 = half).")
            .defineInRange("player_control_share", 0.5, 0.0, 1.0);
    public static final DoubleValue CONTROL_IMMUNITY = B.comment("After a hold ends on a player, seconds during which a new one can't land on them (no chaining).")
            .defineInRange("control_immunity_seconds", 1.0, 0.0, 10.0);
    public static final DoubleValue BOSS_SHARE = B.comment("How strongly pulls and holds work on bosses (Ender Dragon, Wither, Warden, anything with 200+ health).")
            .defineInRange("boss_control_share", 0.25, 0.0, 1.0);
    public static final BooleanValue POCKET_PLAYERS = B.comment("Pocket Universe may take other players (off = only monsters and animals).")
            .define("pocket_universe_takes_players", true);
    static { B.pop(); }

    static { B.comment("Dimension Manipulation (Godlike). Re:AcademyCraft level of each move in brackets.").push("dimension_manipulation"); }
    static {
        mv("spatial_registration", "[Passive] Spatial Registration: every enemy within range is outlined for you through walls; once every dodge_cooldown_seconds a hit on you slides off as you shift a step through space; and tapping sneak twice quickly steps you through a fold in space (Folded Step).",
                "range", 14, "dodge_cooldown_seconds", 8, "shift_distance", 1.6, "step_distance", 5, "step_cooldown_seconds", 3);
        mv("atlas_fold", "[Level 1] Atlas Fold: the land between you and where you aim folds up like a paper map; you step across in one stride and hit whoever is standing there.",
                "cp", 380, "overload", 26, "cooldown_seconds", 8, "range", 30, "fold_seconds", 0.4, "radius", 2.5, "damage", 8);
        mv("severance", "[Level 1] Severance: the world is cut open along a line in front of you and the two halves slide apart. Enemies on the line are hurt and dropped out of a tear in the sky. Then, while the cut stays open, its two ends are one place: creatures, arrows and you yourself going into it come out the same distance from the other end, turned back along it.",
                "cp", 450, "overload", 30, "cooldown_seconds", 14, "length", 40, "width", 1.3, "damage", 12, "sky_height", 10, "player_sky_height", 6, "seconds", 6);
        mv("tesseract", "[Level 2] Tesseract: the enemy you aim at is shut in a cube with no outside - leaving through any side brings it back in through the opposite one. It can be hit and cannot hit out. Then the cube collapses into a singularity that drags in everyone near and bursts.",
                "cp", 520, "overload", 34, "cooldown_seconds", 18, "range", 22, "size", 3, "seconds", 4, "radius", 7, "pull_seconds", 1, "damage", 12, "throw", 1.5);
        mv("infinite_regress", "[Level 2] Infinite Regress: the world round the target is nested inside itself, smaller and smaller; the target is held while it falls through the layers, hurt at each one, then thrown out.",
                "cp", 560, "overload", 36, "cooldown_seconds", 18, "range", 20, "layers", 3, "layer_seconds", 0.6, "damage_per_layer", 4, "throw", 1.4);
        mv("gravity_well", "[Level 3] Gravity Well: for every enemy in the aimed area, 'down' becomes wherever you are looking, and you can keep turning it. They fall that way and are hurt each time they hit something.",
                "cp", 620, "overload", 40, "cooldown_seconds", 22, "range", 26, "radius", 9, "seconds", 5, "pull", 0.14, "max_speed", 1.3, "damage", 7, "max_hits", 3);
        mv("kaleidoscope", "[Level 3] Kaleidoscope: space round you splits into six mirrored wedges. Enemies see six of you: hits on you often break a reflection instead, monsters lose track of you, and each hit you land on one enemy inside lands on the others too. Then the mirror breaks, and the ground with it: enemies are flung into the sky and slammed down.",
                "cp", 700, "overload", 46, "cooldown_seconds", 26, "radius", 9, "seconds", 5, "mirror_share", 0.6, "miss_chance", 0.5, "crack_seconds", 0.5, "air_seconds", 1.6, "damage", 10, "launch", 1.15);
        mv("pocket_universe", "[Level 4] Pocket Universe: you and the enemy you aim at are pulled into an endless impossible tunnel - a duel where you are faster and hit harder, and an enemy esper can't use abilities - then put back exactly where you were.",
                "cp", 750, "overload", 50, "cooldown_seconds", 45, "range", 12, "seconds", 8, "player_seconds", 6, "speed", 0.3, "damage_bonus", 0.35, "repeat_seconds", 20);
        mv("inception", "[Level 5, ultimate] Inception: the battlefield folds up over your head. While it hangs there every hit you land echoes from the folded sky; then it slams shut on everyone inside. Afterwards no Dimension Manipulation moves for burnout_seconds.",
                "cp", 1700, "overload", 115, "cooldown_seconds", 180, "radius", 24, "fold_seconds", 2, "hold_seconds", 13, "slam_seconds", 1.5, "echo_share", 0.5, "final_damage", 14, "throw", 1.4, "burnout_seconds", 20);
    }
    static { B.pop(); }

    public static final ForgeConfigSpec SPEC = B.build();
}
