package dev.toaru.dimmanip;

import com.mojang.logging.LogUtils;
import dev.toaru.dimmanip.net.Net;
import dev.toaru.dimmanip.skills.*;
import io.github.pinchan4273.reacademycraft.api.AbilityId;
import io.github.pinchan4273.reacademycraft.api.ActivationKind;
import io.github.pinchan4273.reacademycraft.api.CategoryDefinition;
import io.github.pinchan4273.reacademycraft.api.Presentation;
import io.github.pinchan4273.reacademycraft.api.SkillDefinition;
import io.github.pinchan4273.reacademycraft.api.SkillRequirement;
import io.github.pinchan4273.reacademycraft.api.TreePosition;
import io.github.pinchan4273.reacademycraft.api.forge.RegisterAbilitiesEvent;
import io.github.pinchan4273.reacademycraft.api.mc.SkillBehavior;
import java.util.List;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Dimension Manipulation: one Godlike esper ability for Re:AcademyCraft, registered through its public add-on API. The
 * esper calculates the structure of space and bends the real world with it - folding, tearing, draining, nesting,
 * inverting, shattering and finally folding the battlefield shut. Every move is one press. All visuals are geometry
 * drawn by this mod (no particles); the terrain seen bending is a picture of the real ground, never the ground itself.
 */
@Mod(DimManip.MOD_ID)
public final class DimManip {
    public static final String MOD_ID = "dimmanip";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static AbilityId id(String path) { return AbilityId.parse(MOD_ID + ":" + path); }

    public static final String CATEGORY = "dimension_manipulation";
    /** The moves in tree order and the Re:AcademyCraft level that unlocks each. */
    public static final String PASSIVE = "spatial_registration";
    public static final String[] SKILLS = {"atlas_fold", "severance", "tesseract", "infinite_regress", "gravity_well", "kaleidoscope", "pocket_universe", "inception"};
    public static final int[] LEVELS = {1, 1, 2, 2, 3, 3, 4, 5};

    public DimManip() {
        var bus = FMLJavaModLoadingContext.get().getModEventBus();
        bus.addListener(this::commonSetup);
        bus.addListener(this::registerAbilities);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Cfg.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientCfg.SPEC);
    }

    private void commonSetup(FMLCommonSetupEvent event) { event.enqueueWork(Net::register); }

    /** Skill-tree icon: assets/dimmanip/textures/abilities/dimmanip/<name>.png */
    private static AbilityId icon(String name) { return AbilityId.parse(MOD_ID + ":textures/abilities/dimmanip/" + name + ".png"); }

    private static Presentation shown(String path) {
        return new Presentation(MOD_ID + ".skill." + path, MOD_ID + ".skill." + path + ".desc", icon(path));
    }

    /** Re:AcademyCraft fires this once during common setup; registration is only possible here. */
    private void registerAbilities(RegisterAbilitiesEvent event) {
        var r = event.registrar(MOD_ID);
        var b = event.behaviors(MOD_ID);
        AbilityId cat = id(CATEGORY);
        r.category(new CategoryDefinition(cat, null, List.of(1, 1, 1, 1, 1), new Presentation(MOD_ID + ".ability." + CATEGORY, null, icon(CATEGORY))));
        // The passive: learned with the category, works by itself (Passive).
        r.skill(new SkillDefinition(id(PASSIVE), cat, 1, List.of(), ActivationKind.PASSIVE, shown(PASSIVE), new TreePosition(10, 10, null)));
        // The tree: one column per level, the moves of a level stacked; each needs some practice of the one before.
        int[] perLevel = new int[6], placed = new int[6];
        for (int lv : LEVELS) perLevel[lv]++;
        AbilityId prev = null;
        for (int i = 0; i < SKILLS.length; i++) {
            int lv = LEVELS[i], n = perLevel[lv], k = placed[lv]++;
            float x = 30 + (lv - 1) * 46, y = n == 1 ? 62 : 36 + k * (52f / Math.max(1, n - 1));
            AbilityId id = id(SKILLS[i]);
            List<SkillRequirement> req = prev == null ? List.of() : List.of(new SkillRequirement(prev, 0.3f));
            r.skill(new SkillDefinition(id, cat, lv, req, ActivationKind.INSTANT, shown(SKILLS[i]), new TreePosition(x, y, prev)));
            SkillBehavior beh = Skills.behavior(SKILLS[i]);
            if (beh == null) LOGGER.error("Dimension Manipulation: no behaviour for {}", id);
            else b.behavior(id, beh);
            prev = id;
        }
    }
}
