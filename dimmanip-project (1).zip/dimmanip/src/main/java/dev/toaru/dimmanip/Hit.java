package dev.toaru.dimmanip;

import io.github.pinchan4273.reacademycraft.api.AbilityId;
import io.github.pinchan4273.reacademycraft.api.mc.AbilityActor;
import io.github.pinchan4273.reacademycraft.api.mc.AcademySafety;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;

/** Every hit and debuff goes through Re:AcademyCraft's safety check (teams, protection, PvP rules, interference). */
public final class Hit {
    private Hit() { }

    /** Damages {@code e} as {@code skill}; true if the hit was allowed and landed. */
    public static boolean damage(AbilityActor actor, LivingEntity e, AbilityId skill, float amount) {
        if (amount <= 0f || !actor.valid()) return false;
        busy++;
        try {
            return AcademySafety.attack(actor, e, skill, amount);
        } finally {
            busy--;
        }
    }

    private static int busy;

    /** Is one of this mod's ability hits being dealt right now (so melee-only effects leave it alone)? */
    public static boolean busy() { return busy > 0; }

    /** Sets a target on fire for a while (the creature only: blocks are never set alight). */
    public static void burn(LivingEntity e, double seconds) {
        int s = (int) Math.round(seconds);
        if (s > 0 && !e.fireImmune()) e.setSecondsOnFire(s);
    }

    /** A short slowness on a creature that may be attacked by this skill. */
    public static void slow(AbilityActor actor, LivingEntity e, AbilityId skill, int ticks, int amplifier) {
        if (ticks <= 0 || !actor.valid() || !Targeting.hostile(actor, e, skill)) return;
        e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, amplifier, false, true, true), actor.entity());
    }

    /**
     * Damages everything this skill may attack within {@code radius} of {@code centre}: full damage at the centre down to
     * half at the edge, and a push straight away from the centre (bosses are pushed much less). Returns how many were hit.
     */
    public static int blast(AbilityActor actor, net.minecraft.server.level.ServerLevel level, net.minecraft.world.phys.Vec3 centre,
                            double radius, AbilityId skill, float amount, double push, double lift, @javax.annotation.Nullable net.minecraft.world.entity.Entity exclude) {
        int hits = 0;
        for (LivingEntity e : Targeting.livingWithin(level, centre, radius, exclude)) {
            if (!Targeting.hostile(actor, e, skill)) continue;
            double d = Targeting.centre(e).distanceTo(centre);
            float dmg = (float) (amount * (1.0 - 0.5 * Math.min(1.0, d / radius)));
            if (!damage(actor, e, skill, dmg)) continue;
            hits++;
            if (push > 0 || lift > 0) {
                net.minecraft.world.phys.Vec3 dir = Targeting.flatDir(centre, e.position(), net.minecraft.world.phys.Vec3.ZERO);
                double k = push * Targeting.controlFactor(e) * (1.0 - 0.4 * Math.min(1.0, d / radius));
                Targeting.setMotion(e, e.getDeltaMovement().add(dir.x * k, lift * Targeting.controlFactor(e), dir.z * k));
            }
        }
        return hits;
    }
}
