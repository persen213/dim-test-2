package dev.toaru.dimmanip.skills;

import dev.toaru.dimmanip.Cfg;
import dev.toaru.dimmanip.DimManip;
import dev.toaru.dimmanip.Targeting;
import dev.toaru.dimmanip.net.Fx;
import io.github.pinchan4273.reacademycraft.api.AbilityId;
import io.github.pinchan4273.reacademycraft.api.ActivationOutcome;
import io.github.pinchan4273.reacademycraft.api.mc.ActivationContext;
import io.github.pinchan4273.reacademycraft.api.mc.SkillBehavior;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

/**
 * Shared steps of every move. Re:AcademyCraft has already checked that the move is learned, the cooldown and that the
 * player can act; a move then checks its target, pays (CP and overload), works and sets its own cooldown. A move that
 * refuses (no target, not enough CP) changes nothing and costs nothing.
 */
public abstract class Move implements SkillBehavior {
    public final String name;
    public final AbilityId id;

    protected Move(String name) { this.name = name; this.id = DimManip.id(name); }

    protected Cfg.Mv m() { return Cfg.of(name); }

    @Override
    public final ActivationOutcome start(ActivationContext c) {
        ServerPlayer p = c.naturalUser();
        if (p == null) return ActivationOutcome.REFUSED_INVALID;
        // After Inception the esper's calculations need time: no Dimension Manipulation moves at all.
        double burnt = dev.toaru.dimmanip.Status.left(p, "dm_burnout");
        if (burnt > 0) return refuse(p, "Your calculations are spent - " + (int) Math.ceil(burnt) + " s.");
        try {
            ActivationOutcome out = use(c, p, m());
            if (out == ActivationOutcome.PERFORMED) cast(p);
            return out;
        } catch (RuntimeException ex) {
            DimManip.LOGGER.error("Dimension Manipulation: {} failed", name, ex);
            return ActivationOutcome.REFUSED_INVALID;
        }
    }

    /**
     * The esper's body as the move goes off, for everyone watching: a thrust, a cleave, a held-out hand, both arms thrown
     * up, a slam, or rising off the ground and turning (Inception). Only how the player is drawn changes.
     */
    private void cast(ServerPlayer p) {
        int kind, ticks;
        switch (name) {
            case "atlas_fold", "pocket_universe" -> { kind = 0; ticks = 14; }
            case "severance" -> { kind = 1; ticks = 18; }
            case "tesseract", "infinite_regress" -> { kind = 2; ticks = 34; }
            case "gravity_well" -> { kind = 3; ticks = 40; }
            case "kaleidoscope" -> { kind = 6; ticks = 30; }
            case "inception" -> { kind = 6; ticks = 56; }
            default -> { return; }
        }
        Fx.make(p.serverLevel(), p.position(), dev.toaru.dimmanip.net.FxType.CAST, ticks).a(p.getId()).b(kind).range(96).send();
        p.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
    }

    protected abstract ActivationOutcome use(ActivationContext c, ServerPlayer p, Cfg.Mv m);

    protected static boolean pay(ActivationContext c, Cfg.Mv m) { return c.pay(m.f("cp"), m.f("overload")); }

    /** After a successful use: the cooldown and some practice (which also counts towards the next level). */
    protected static ActivationOutcome done(ActivationContext c, Cfg.Mv m) {
        c.setCooldown(Math.max(1, (int) Math.round(m.cooldown() * 20)));
        c.addProficiency(0.012f);
        return ActivationOutcome.PERFORMED;
    }

    protected static ActivationOutcome refuse(ServerPlayer p, String why) {
        Fx.hint(p, why);
        return ActivationOutcome.REFUSED_INVALID;
    }

    protected static ActivationOutcome broke() { return ActivationOutcome.REFUSED_RESOURCE; }

    /** The enemy along the crosshair that this move may hit, or null. */
    protected @Nullable LivingEntity aimed(ServerPlayer p, ActivationContext c, double range) {
        LivingEntity t = Targeting.living(p, range);
        return t != null && Targeting.hostile(c.actor(), t, id) ? t : null;
    }
}
