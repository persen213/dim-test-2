package dev.toaru.dimmanip;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.ForgeConfigSpec.IntValue;

/** Each player's own visual settings (config/dimmanip-client.toml). Purely visual; the server never reads them. */
public final class ClientCfg {
    private ClientCfg() { }
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    static { B.comment("How Dimension Manipulation is drawn on this game.").push("visuals"); }
    public static final IntValue QUALITY = B.comment("Visual quality: 0 = low, 1 = medium, 2 = high.").defineInRange("quality", 2, 0, 2);
    static { B.pop(); }

    public static final ForgeConfigSpec SPEC = B.build();

    public static int quality() { try { return QUALITY.get(); } catch (RuntimeException e) { return 2; } }
}
