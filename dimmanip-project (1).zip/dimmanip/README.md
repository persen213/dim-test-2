# Dimension Manipulation (Re:AcademyCraft 1.5.0 add-on, Minecraft 1.20.1 Forge)

A Godlike esper who calculates the structure of space and rewrites it. The real world is the weapon: the mod draws
copies of the real blocks round you, with their real textures, and folds, tears, drains and shatters them, with dark
tears in reality underneath. Your actual blocks are never changed. All visuals are geometry (no particles). Needs only
Re:AcademyCraft 1.5.0.

Category id: `dimmanip:dimension_manipulation`

| Re:AC level | Move | What it does |
|---|---|---|
| (passive) | Spatial Registration | Enemies outlined through walls; every 8 s one hit slides off; tap sneak twice to step 5 blocks through a fold. |
| 1 | Atlas Fold | The land folds like a map; you cross 30 blocks at once and hit for 4 hearts. |
| 1 | Severance | A 40-block cut; enemies on it take 6 hearts and drop from the sky; for 6 s its two ends are one place for creatures, arrows and you. |
| 2 | Tesseract | An enemy shut in a cube with no outside (walk out one side, come in the other), then it collapses into a singularity. |
| 2 | Infinite Regress | The world nested in itself; the target falls through 3 layers, 2 hearts each. |
| 3 | Gravity Well | "Down" is wherever you look, live, for every enemy in the area; 3.5 hearts per crash. |
| 3 | Kaleidoscope | Six of you; hits on you break reflections; your hits strike every enemy inside; then the ground shatters. |
| 4 | Pocket Universe | A duel in an endless tunnel: you are faster and stronger, the enemy can't use abilities. |
| 5 | Inception (ultimate) | The battlefield folds overhead; your hits echo from the sky for 15 s; then it slams shut (7 hearts). |

After Inception ends, no Dimension Manipulation moves for 20 s.

Every move has a cast animation other players see (and you see in third person): arms thrust out, thrown up or held
out, the body leaning into it or lifting off the ground; for Inception the esper rises and turns in the air.

## Safe for your world
- Nothing changes your real blocks. All the folding, tearing and shattering terrain is a picture of the real ground.
- Pocket Universe uses its own empty dimension (`dimmanip:pocket`). Everyone is always sent back: when time runs out,
  if either fighter dies or leaves, or when the server stops. A player who logs in inside a pocket is sent home.
- Nobody is ever placed inside blocks; bosses can't be pulled, carried or pocketed.

## Settings
`config/dimmanip-common.toml`: every move's numbers, plus `player_control_share`, `control_immunity_seconds`,
`boss_control_share` and `pocket_universe_takes_players`. `config/dimmanip-client.toml`: `quality` 0-2.

## Testing in game (creative, as an operator)
```
/aim cheats_on
/aim cat dimmanip:dimension_manipulation
/aim maxout
/aim learn_all
/aim fullcp
/aim cd_clear
```

## Adding it to Esper Roll
In `config/esperroll-common.toml`, add `"dimmanip:dimension_manipulation"` to the `godlike` tier's `abilities` list.

## How it is drawn
- `client/TerrainFx`: copies of the real blocks near a move, drawn with their own textures and lighting, folded, tiled
  onto walls, tipped in plates, rippled, shrunk into the pocket shell, hung in the air. The real world is not changed.
- `client/Solid`: lit solid geometry (bars, machined rings, slabs of glass, crystals, a twenty-faced shell). The main
  structure of every effect is made of these, not of lines.
- `client/FxDim`, `client/PsyTunnel`: the effects themselves. No particles, no custom shaders.

## Status
Written and compile-checked against stand-in Minecraft/Forge classes. The drawn geometry was crash-tested in an offline
preview. Everything that uses the game's own drawing (the bent terrain, the mirrored player copies, the cast poses)
could not be previewed offline. Not yet built by GitHub and not yet tested in game.
